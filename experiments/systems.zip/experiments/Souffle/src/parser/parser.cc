// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "parser.hh"


// Unqualified %code blocks.
#line 119 "/home/lun/workspace/souffle/src/parser/parser.yy"

    #include "parser/ParserDriver.h"
    #define YY_DECL yy::parser::symbol_type yylex(souffle::ParserDriver& driver, yyscan_t yyscanner)
    YY_DECL;

#line 52 "/home/lun/workspace/souffle/build/src/parser/parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

namespace yy {
#line 144 "/home/lun/workspace/souffle/build/src/parser/parser.cc"

  /// Build a parser object.
  parser::parser (ParserDriver &driver_yyarg, yyscan_t yyscanner_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg),
      yyscanner (yyscanner_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_kind_type
  parser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.YY_MOVE_OR_COPY< AggregateOp > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg: // arg
        value.YY_MOVE_OR_COPY< Own<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_atom: // atom
        value.YY_MOVE_OR_COPY< Own<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.YY_MOVE_OR_COPY< Own<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.YY_MOVE_OR_COPY< Own<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_fact: // fact
        value.YY_MOVE_OR_COPY< Own<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.YY_MOVE_OR_COPY< Own<ast::Component> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_init: // component_init
        value.YY_MOVE_OR_COPY< Own<ast::ComponentInit> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_type: // component_type
        value.YY_MOVE_OR_COPY< Own<ast::ComponentType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_constraint: // constraint
        value.YY_MOVE_OR_COPY< Own<ast::Constraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.YY_MOVE_OR_COPY< Own<ast::ExecutionOrder> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.YY_MOVE_OR_COPY< Own<ast::ExecutionPlan> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency: // dependency
        value.YY_MOVE_OR_COPY< Own<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.YY_MOVE_OR_COPY< Own<ast::FunctorDeclaration> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.YY_MOVE_OR_COPY< Own<ast::Lattice> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_pragma: // pragma
        value.YY_MOVE_OR_COPY< Own<ast::Pragma> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.YY_MOVE_OR_COPY< Own<ast::Type> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.YY_MOVE_OR_COPY< RuleBody > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.YY_MOVE_OR_COPY< VecOwn<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_head: // head
        value.YY_MOVE_OR_COPY< VecOwn<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.YY_MOVE_OR_COPY< VecOwn<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.YY_MOVE_OR_COPY< VecOwn<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.YY_MOVE_OR_COPY< VecOwn<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.YY_MOVE_OR_COPY< VecOwn<ast::Directive> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.YY_MOVE_OR_COPY< VecOwn<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.YY_MOVE_OR_COPY< VecOwn<ast::Relation> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.YY_MOVE_OR_COPY< ast::Annotation > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.YY_MOVE_OR_COPY< ast::AnnotationList > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.YY_MOVE_OR_COPY< ast::DirectiveType > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.YY_MOVE_OR_COPY< ast::ExecutionOrder::ExecOrder > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.YY_MOVE_OR_COPY< ast::QualifiedName > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.YY_MOVE_OR_COPY< ast::TokenStream > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.YY_MOVE_OR_COPY< ast::TokenTree > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.YY_MOVE_OR_COPY< std::map<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.YY_MOVE_OR_COPY< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.YY_MOVE_OR_COPY< std::set<RelationTag> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.YY_MOVE_OR_COPY< std::vector<ast::QualifiedName> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.YY_MOVE_OR_COPY< std::vector<std::pair<std::string, std::string>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.YY_MOVE_OR_COPY< std::vector<std::string> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.move< AggregateOp > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg: // arg
        value.move< Own<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_atom: // atom
        value.move< Own<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.move< Own<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.move< Own<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_fact: // fact
        value.move< Own<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.move< Own<ast::Component> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_init: // component_init
        value.move< Own<ast::ComponentInit> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_type: // component_type
        value.move< Own<ast::ComponentType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_constraint: // constraint
        value.move< Own<ast::Constraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.move< Own<ast::ExecutionOrder> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.move< Own<ast::ExecutionPlan> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency: // dependency
        value.move< Own<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.move< Own<ast::FunctorDeclaration> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.move< Own<ast::Lattice> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_pragma: // pragma
        value.move< Own<ast::Pragma> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.move< Own<ast::Type> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.move< RuleBody > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.move< VecOwn<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_head: // head
        value.move< VecOwn<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.move< VecOwn<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.move< VecOwn<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.move< VecOwn<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.move< VecOwn<ast::Directive> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.move< VecOwn<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.move< VecOwn<ast::Relation> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.move< ast::Annotation > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.move< ast::AnnotationList > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.move< ast::DirectiveType > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.move< ast::ExecutionOrder::ExecOrder > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.move< ast::QualifiedName > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.move< ast::TokenStream > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.move< ast::TokenTree > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.move< std::map<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.move< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.move< std::set<RelationTag> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.move< std::vector<ast::QualifiedName> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.move< std::vector<std::pair<std::string, std::string>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.move< std::vector<std::string> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.copy< AggregateOp > (that.value);
        break;

      case symbol_kind::S_arg: // arg
        value.copy< Own<ast::Argument> > (that.value);
        break;

      case symbol_kind::S_atom: // atom
        value.copy< Own<ast::Atom> > (that.value);
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.copy< Own<ast::Attribute> > (that.value);
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.copy< Own<ast::BranchType> > (that.value);
        break;

      case symbol_kind::S_fact: // fact
        value.copy< Own<ast::Clause> > (that.value);
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.copy< Own<ast::Component> > (that.value);
        break;

      case symbol_kind::S_component_init: // component_init
        value.copy< Own<ast::ComponentInit> > (that.value);
        break;

      case symbol_kind::S_component_type: // component_type
        value.copy< Own<ast::ComponentType> > (that.value);
        break;

      case symbol_kind::S_constraint: // constraint
        value.copy< Own<ast::Constraint> > (that.value);
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.copy< Own<ast::ExecutionOrder> > (that.value);
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.copy< Own<ast::ExecutionPlan> > (that.value);
        break;

      case symbol_kind::S_dependency: // dependency
        value.copy< Own<ast::FunctionalConstraint> > (that.value);
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.copy< Own<ast::FunctorDeclaration> > (that.value);
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.copy< Own<ast::Lattice> > (that.value);
        break;

      case symbol_kind::S_pragma: // pragma
        value.copy< Own<ast::Pragma> > (that.value);
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.copy< Own<ast::Type> > (that.value);
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.copy< RuleBody > (that.value);
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.copy< VecOwn<ast::Argument> > (that.value);
        break;

      case symbol_kind::S_head: // head
        value.copy< VecOwn<ast::Atom> > (that.value);
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.copy< VecOwn<ast::Attribute> > (that.value);
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.copy< VecOwn<ast::BranchType> > (that.value);
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.copy< VecOwn<ast::Clause> > (that.value);
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.copy< VecOwn<ast::Directive> > (that.value);
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.copy< VecOwn<ast::FunctionalConstraint> > (that.value);
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.copy< VecOwn<ast::Relation> > (that.value);
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.copy< ast::Annotation > (that.value);
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.copy< ast::AnnotationList > (that.value);
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.copy< ast::DirectiveType > (that.value);
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.copy< ast::ExecutionOrder::ExecOrder > (that.value);
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.copy< ast::QualifiedName > (that.value);
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.copy< ast::TokenStream > (that.value);
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.copy< ast::TokenTree > (that.value);
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.copy< std::map<ast::LatticeOperator, Own<ast::Argument>> > (that.value);
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.copy< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (that.value);
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.copy< std::set<RelationTag> > (that.value);
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.copy< std::vector<ast::QualifiedName> > (that.value);
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.copy< std::vector<std::pair<std::string, std::string>> > (that.value);
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.copy< std::vector<std::string> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.move< AggregateOp > (that.value);
        break;

      case symbol_kind::S_arg: // arg
        value.move< Own<ast::Argument> > (that.value);
        break;

      case symbol_kind::S_atom: // atom
        value.move< Own<ast::Atom> > (that.value);
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.move< Own<ast::Attribute> > (that.value);
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.move< Own<ast::BranchType> > (that.value);
        break;

      case symbol_kind::S_fact: // fact
        value.move< Own<ast::Clause> > (that.value);
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.move< Own<ast::Component> > (that.value);
        break;

      case symbol_kind::S_component_init: // component_init
        value.move< Own<ast::ComponentInit> > (that.value);
        break;

      case symbol_kind::S_component_type: // component_type
        value.move< Own<ast::ComponentType> > (that.value);
        break;

      case symbol_kind::S_constraint: // constraint
        value.move< Own<ast::Constraint> > (that.value);
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.move< Own<ast::ExecutionOrder> > (that.value);
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.move< Own<ast::ExecutionPlan> > (that.value);
        break;

      case symbol_kind::S_dependency: // dependency
        value.move< Own<ast::FunctionalConstraint> > (that.value);
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.move< Own<ast::FunctorDeclaration> > (that.value);
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.move< Own<ast::Lattice> > (that.value);
        break;

      case symbol_kind::S_pragma: // pragma
        value.move< Own<ast::Pragma> > (that.value);
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.move< Own<ast::Type> > (that.value);
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.move< RuleBody > (that.value);
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.move< VecOwn<ast::Argument> > (that.value);
        break;

      case symbol_kind::S_head: // head
        value.move< VecOwn<ast::Atom> > (that.value);
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.move< VecOwn<ast::Attribute> > (that.value);
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.move< VecOwn<ast::BranchType> > (that.value);
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.move< VecOwn<ast::Clause> > (that.value);
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.move< VecOwn<ast::Directive> > (that.value);
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.move< VecOwn<ast::FunctionalConstraint> > (that.value);
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.move< VecOwn<ast::Relation> > (that.value);
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.move< ast::Annotation > (that.value);
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.move< ast::AnnotationList > (that.value);
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.move< ast::DirectiveType > (that.value);
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.move< ast::ExecutionOrder::ExecOrder > (that.value);
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.move< ast::QualifiedName > (that.value);
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.move< ast::TokenStream > (that.value);
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.move< ast::TokenTree > (that.value);
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.move< std::map<ast::LatticeOperator, Own<ast::Argument>> > (that.value);
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.move< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (that.value);
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.move< std::set<RelationTag> > (that.value);
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.move< std::vector<ast::QualifiedName> > (that.value);
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.move< std::vector<std::pair<std::string, std::string>> > (that.value);
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.move< std::vector<std::string> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        YY_USE (yykind);
        yyo << ')';
      }
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver, yyscanner));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        yylhs.value.emplace< AggregateOp > ();
        break;

      case symbol_kind::S_arg: // arg
        yylhs.value.emplace< Own<ast::Argument> > ();
        break;

      case symbol_kind::S_atom: // atom
        yylhs.value.emplace< Own<ast::Atom> > ();
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        yylhs.value.emplace< Own<ast::Attribute> > ();
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        yylhs.value.emplace< Own<ast::BranchType> > ();
        break;

      case symbol_kind::S_fact: // fact
        yylhs.value.emplace< Own<ast::Clause> > ();
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        yylhs.value.emplace< Own<ast::Component> > ();
        break;

      case symbol_kind::S_component_init: // component_init
        yylhs.value.emplace< Own<ast::ComponentInit> > ();
        break;

      case symbol_kind::S_component_type: // component_type
        yylhs.value.emplace< Own<ast::ComponentType> > ();
        break;

      case symbol_kind::S_constraint: // constraint
        yylhs.value.emplace< Own<ast::Constraint> > ();
        break;

      case symbol_kind::S_plan_order: // plan_order
        yylhs.value.emplace< Own<ast::ExecutionOrder> > ();
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        yylhs.value.emplace< Own<ast::ExecutionPlan> > ();
        break;

      case symbol_kind::S_dependency: // dependency
        yylhs.value.emplace< Own<ast::FunctionalConstraint> > ();
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        yylhs.value.emplace< Own<ast::FunctorDeclaration> > ();
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        yylhs.value.emplace< Own<ast::Lattice> > ();
        break;

      case symbol_kind::S_pragma: // pragma
        yylhs.value.emplace< Own<ast::Pragma> > ();
        break;

      case symbol_kind::S_type_decl: // type_decl
        yylhs.value.emplace< Own<ast::Type> > ();
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        yylhs.value.emplace< RuleBody > ();
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        yylhs.value.emplace< VecOwn<ast::Argument> > ();
        break;

      case symbol_kind::S_head: // head
        yylhs.value.emplace< VecOwn<ast::Atom> > ();
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        yylhs.value.emplace< VecOwn<ast::Attribute> > ();
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        yylhs.value.emplace< VecOwn<ast::BranchType> > ();
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        yylhs.value.emplace< VecOwn<ast::Clause> > ();
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        yylhs.value.emplace< VecOwn<ast::Directive> > ();
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        yylhs.value.emplace< VecOwn<ast::FunctionalConstraint> > ();
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        yylhs.value.emplace< VecOwn<ast::Relation> > ();
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        yylhs.value.emplace< ast::Annotation > ();
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        yylhs.value.emplace< ast::AnnotationList > ();
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        yylhs.value.emplace< ast::DirectiveType > ();
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        yylhs.value.emplace< ast::ExecutionOrder::ExecOrder > ();
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        yylhs.value.emplace< ast::QualifiedName > ();
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        yylhs.value.emplace< ast::TokenStream > ();
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        yylhs.value.emplace< ast::TokenTree > ();
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        yylhs.value.emplace< std::map<ast::LatticeOperator, Own<ast::Argument>> > ();
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        yylhs.value.emplace< std::pair<ast::LatticeOperator, Own<ast::Argument>> > ();
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        yylhs.value.emplace< std::set<RelationTag> > ();
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        yylhs.value.emplace< std::vector<ast::QualifiedName> > ();
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        yylhs.value.emplace< std::vector<std::pair<std::string, std::string>> > ();
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        yylhs.value.emplace< std::vector<std::string> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // unit: %empty
#line 340 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { }
#line 1509 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 4: // unit: unit annotations "start of included file"
#line 342 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // the ENTER token helps resynchronizing current source location
      // when an included file is entered
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
        driver.uselessAnnotations(annotations, "before '.include'");
      }
    }
#line 1521 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 5: // unit: unit annotations "end of included file"
#line 350 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // the LEAVE token helps resynchronizing current source location
      // when an included file is left
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "at end of included file");
      }
    }
#line 1533 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 6: // unit: unit annotations "end of file"
#line 358 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "at end of file");
      }
    }
#line 1544 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 7: // unit: unit annotations directive_head
#line 365 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      for (auto&& cur : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Directive> > ())) {
        cur->setAnnotations(annotations);
        driver.addDirective(std::move(cur));
      }
    }
#line 1556 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 8: // unit: unit rule
#line 373 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      for (auto&& cur : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Clause> > ())) {
        driver.addClause(std::move(cur));
      }
    }
#line 1566 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 9: // unit: unit fact
#line 379 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto fact = YY_MOVE (yystack_[0].value.as < Own<ast::Clause> > ());
      driver.addClause(std::move(fact));
    }
#line 1575 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 10: // unit: unit annotations component_decl
#line 384 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto component_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Component> > ());
      component_decl->prependAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addComponent(std::move(component_decl));
    }
#line 1585 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 11: // unit: unit annotations component_init
#line 390 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto component_init = YY_MOVE (yystack_[0].value.as < Own<ast::ComponentInit> > ());
      component_init->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addInstantiation(std::move(component_init));
    }
#line 1595 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 12: // unit: unit annotations pragma
#line 396 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto pragma = YY_MOVE (yystack_[0].value.as < Own<ast::Pragma> > ());
      pragma->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addPragma(std::move(pragma));
    }
#line 1605 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 13: // unit: unit annotations type_decl
#line 402 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto type_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Type> > ());
      type_decl->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addType(std::move(type_decl));
    }
#line 1615 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 14: // unit: unit annotations lattice_decl
#line 408 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto lattice_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Lattice> > ());
      lattice_decl->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addLattice(std::move(lattice_decl));
    }
#line 1625 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 15: // unit: unit annotations functor_decl
#line 414 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto functor_decl = YY_MOVE (yystack_[0].value.as < Own<ast::FunctorDeclaration> > ());
      functor_decl->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      driver.addFunctorDeclaration(std::move(functor_decl));
    }
#line 1635 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 16: // unit: unit annotations relation_decl
#line 420 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      for (auto&& rel : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Relation> > ())) {
        // Note: we duplicate annotations on every relation of the declaration.
        //
        // An alternative would be to allow distinct annotations before each
        // relation name.
        rel->setAnnotations(annotations);
        driver.addIoFromDeprecatedTag(*rel);
        driver.addRelation(std::move(rel));
      }
    }
#line 1652 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 17: // qualified_name: "identifier"
#line 440 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::QualifiedName > () = driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ()));
    }
#line 1660 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 18: // qualified_name: qualified_name "." "identifier"
#line 444 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::QualifiedName > () = YY_MOVE (yystack_[2].value.as < ast::QualifiedName > ()); yylhs.value.as < ast::QualifiedName > ().append(YY_MOVE (yystack_[0].value.as < std::string > ()));
    }
#line 1668 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 19: // type_decl: "type declaration" "identifier" "<:" qualified_name
#line 454 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = mk<ast::SubsetType>(driver.mkQN(YY_MOVE (yystack_[2].value.as < std::string > ())), YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yylhs.location);
    }
#line 1676 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 20: // type_decl: "type declaration" "identifier" "=" union_type_list
#line 458 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto utl = YY_MOVE (yystack_[0].value.as < std::vector<ast::QualifiedName> > ());
      auto id = YY_MOVE (yystack_[2].value.as < std::string > ());
      if (utl.size() > 1) {
        yylhs.value.as < Own<ast::Type> > () = mk<ast::UnionType>(driver.mkQN(id), utl, yylhs.location);
      } else {
        yylhs.value.as < Own<ast::Type> > () = mk<ast::AliasType>(driver.mkQN(id), utl[0], yylhs.location);
      }
    }
#line 1690 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 21: // type_decl: "type declaration" "identifier" "=" record_type_list
#line 468 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = mk<ast::RecordType>(driver.mkQN(YY_MOVE (yystack_[2].value.as < std::string > ())), YY_MOVE (yystack_[0].value.as < VecOwn<ast::Attribute> > ()), yylhs.location);
    }
#line 1698 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 22: // type_decl: "type declaration" "identifier" "=" annotation annotations adt_branch_list
#line 472 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // special case to avoid conflict in grammar with `annotations`

      // insert outer annotations before inner annotations of the first branch
      auto branches = YY_MOVE (yystack_[0].value.as < VecOwn<ast::BranchType> > ());
      branches.front()->prependAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      branches.front()->prependAnnotation(YY_MOVE (yystack_[2].value.as < ast::Annotation > ()));
      yylhs.value.as < Own<ast::Type> > () = mk<ast::AlgebraicDataType>(driver.mkQN(YY_MOVE (yystack_[4].value.as < std::string > ())), std::move(branches), yylhs.location);
    }
#line 1711 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 23: // type_decl: "type declaration" "identifier" "=" adt_branch_list
#line 481 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = mk<ast::AlgebraicDataType>(driver.mkQN(YY_MOVE (yystack_[2].value.as < std::string > ())), YY_MOVE (yystack_[0].value.as < VecOwn<ast::BranchType> > ()), yylhs.location);
    }
#line 1719 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 24: // type_decl: "numeric type declaration" "identifier"
#line 486 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = driver.mkDeprecatedSubType(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())), driver.mkQN("number"), yylhs.location);
    }
#line 1727 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 25: // type_decl: "symbolic type declaration" "identifier"
#line 490 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = driver.mkDeprecatedSubType(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())), driver.mkQN("symbol"), yylhs.location);
    }
#line 1735 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 26: // type_decl: "type declaration" "identifier"
#line 494 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Type> > () = driver.mkDeprecatedSubType(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())), driver.mkQN("symbol"), yylhs.location);
    }
#line 1743 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 27: // record_type_list: "[" "]"
#line 503 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { }
#line 1749 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 28: // record_type_list: "[" non_empty_attributes "]"
#line 505 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > () = YY_MOVE (yystack_[1].value.as < VecOwn<ast::Attribute> > ());
    }
#line 1757 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 29: // union_type_list: qualified_name
#line 513 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<ast::QualifiedName> > ().push_back(YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()));
    }
#line 1765 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 30: // union_type_list: union_type_list "|" qualified_name
#line 517 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<ast::QualifiedName> > () = YY_MOVE (yystack_[2].value.as < std::vector<ast::QualifiedName> > ());
      yylhs.value.as < std::vector<ast::QualifiedName> > ().push_back(YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()));
    }
#line 1774 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 31: // adt_branch_list: adt_branch
#line 525 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::BranchType> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::BranchType> > ()));
    }
#line 1782 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 32: // adt_branch_list: adt_branch_list "|" annotations adt_branch
#line 529 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::BranchType> > () = YY_MOVE (yystack_[3].value.as < VecOwn<ast::BranchType> > ());
      auto adt_branch = YY_MOVE (yystack_[0].value.as < Own<ast::BranchType> > ());
      adt_branch->addAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < VecOwn<ast::BranchType> > ().emplace_back(std::move(adt_branch));
    }
#line 1793 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 33: // adt_branch: "identifier" "{" inner_annotations "}"
#line 539 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::BranchType> > () = mk<ast::BranchType>(driver.mkQN(YY_MOVE (yystack_[3].value.as < std::string > ())), VecOwn<ast::Attribute>{}, yylhs.location);
      yylhs.value.as < Own<ast::BranchType> > ()->addAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
    }
#line 1802 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 34: // adt_branch: "identifier" "{" inner_annotations non_empty_attributes "}"
#line 544 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::BranchType> > () = mk<ast::BranchType>(driver.mkQN(YY_MOVE (yystack_[4].value.as < std::string > ())), YY_MOVE (yystack_[1].value.as < VecOwn<ast::Attribute> > ()), yylhs.location);
      yylhs.value.as < Own<ast::BranchType> > ()->addAnnotations(YY_MOVE (yystack_[2].value.as < ast::AnnotationList > ()));
    }
#line 1811 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 35: // lattice_decl: "lattice declaration" "identifier" "<" ">" "{" lattice_operator_list "}"
#line 556 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Lattice> > () = mk<ast::Lattice>(driver.mkQN(YY_MOVE (yystack_[5].value.as < std::string > ())), std::move(YY_MOVE (yystack_[1].value.as < std::map<ast::LatticeOperator, Own<ast::Argument>> > ())), yylhs.location);
    }
#line 1819 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 36: // lattice_operator_list: lattice_operator "," lattice_operator_list
#line 562 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::map<ast::LatticeOperator, Own<ast::Argument>> > () = YY_MOVE (yystack_[0].value.as < std::map<ast::LatticeOperator, Own<ast::Argument>> > ());
      yylhs.value.as < std::map<ast::LatticeOperator, Own<ast::Argument>> > ().emplace(YY_MOVE (yystack_[2].value.as < std::pair<ast::LatticeOperator, Own<ast::Argument>> > ()));
    }
#line 1828 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 37: // lattice_operator_list: lattice_operator
#line 567 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::map<ast::LatticeOperator, Own<ast::Argument>> > ().emplace(YY_MOVE (yystack_[0].value.as < std::pair<ast::LatticeOperator, Own<ast::Argument>> > ()));
    }
#line 1836 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 38: // lattice_operator: "identifier" "->" arg
#line 573 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto op = ast::latticeOperatorFromString(YY_MOVE (yystack_[2].value.as < std::string > ()));
      if (!op.has_value()) {
        driver.error(yylhs.location, "Lattice operator not recognized");
      }
      yylhs.value.as < std::pair<ast::LatticeOperator, Own<ast::Argument>> > () = std::make_pair(op.value(), std::move(YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ())));
    }
#line 1848 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 39: // relation_decl: "relation declaration" relation_names attributes_list relation_tags dependency_list
#line 590 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto tags = YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ());
      auto attributes_list = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Attribute> > ());
      yylhs.value.as < VecOwn<ast::Relation> > () = YY_MOVE (yystack_[3].value.as < VecOwn<ast::Relation> > ());
      for (auto&& rel : yylhs.value.as < VecOwn<ast::Relation> > ()) {
        for (auto tag : tags) {
          if (isRelationQualifierTag(tag)) {
            rel->addQualifier(getRelationQualifierFromTag(tag));
          } else if (isRelationRepresentationTag(tag)) {
            rel->setRepresentation(getRelationRepresentationFromTag(tag));
          } else {
            assert(false && "unhandled tag");
          }
        }
        for (auto&& fd : YY_MOVE (yystack_[0].value.as < VecOwn<ast::FunctionalConstraint> > ())) {
          rel->addDependency(souffle::clone(fd));
        }
        rel->setAttributes(clone(attributes_list));
      }
    }
#line 1873 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 40: // relation_decl: "relation declaration" "identifier" "=" "debug_delta" "(" "identifier" ")" relation_tags
#line 611 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto tags = YY_MOVE (yystack_[0].value.as < std::set<RelationTag> > ());
      yylhs.value.as < VecOwn<ast::Relation> > ().push_back(mk<ast::Relation>(driver.mkQN(YY_MOVE (yystack_[6].value.as < std::string > ())), yystack_[6].location));
      for (auto&& rel : yylhs.value.as < VecOwn<ast::Relation> > ()) {
        rel->setIsDeltaDebug(driver.mkQN(YY_MOVE (yystack_[2].value.as < std::string > ())));
        for (auto tag : tags) {
          if (isRelationQualifierTag(tag)) {
            rel->addQualifier(getRelationQualifierFromTag(tag));
          } else if (isRelationRepresentationTag(tag)) {
            rel->setRepresentation(getRelationRepresentationFromTag(tag));
          } else {
            assert(false && "unhandled tag");
          }
        }
      }
    }
#line 1894 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 41: // relation_names: "identifier"
#line 634 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Relation> > ().push_back(mk<ast::Relation>(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())), yystack_[0].location));
    }
#line 1902 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 42: // relation_names: relation_names "," "identifier"
#line 638 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Relation> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Relation> > ());
      yylhs.value.as < VecOwn<ast::Relation> > ().push_back(mk<ast::Relation>(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())), yystack_[0].location));
    }
#line 1911 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 43: // attributes_list: "(" ")"
#line 649 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
    }
#line 1918 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 44: // attributes_list: "(" non_empty_attributes ")"
#line 652 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > () = YY_MOVE (yystack_[1].value.as < VecOwn<ast::Attribute> > ());
    }
#line 1926 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 45: // non_empty_attributes: attribute
#line 659 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Attribute> > ()));
    }
#line 1934 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 46: // non_empty_attributes: non_empty_attributes "," attribute
#line 663 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Attribute> > ());
      yylhs.value.as < VecOwn<ast::Attribute> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Attribute> > ()));
    }
#line 1943 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 47: // attribute: annotations "identifier" ":" qualified_name
#line 671 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[2].location);
      yylhs.value.as < Own<ast::Attribute> > () = mk<ast::Attribute>(YY_MOVE (yystack_[2].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location);
      yylhs.value.as < Own<ast::Attribute> > ()->setAnnotations(YY_MOVE (yystack_[3].value.as < ast::AnnotationList > ()));
    }
#line 1953 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 48: // attribute: annotations "identifier" ":" qualified_name "<" ">"
#line 677 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[4].location);
      yylhs.value.as < Own<ast::Attribute> > () = mk<ast::Attribute>(YY_MOVE (yystack_[4].value.as < std::string > ()), YY_MOVE (yystack_[2].value.as < ast::QualifiedName > ()), true, yystack_[2].location);
      yylhs.value.as < Own<ast::Attribute> > ()->setAnnotations(YY_MOVE (yystack_[5].value.as < ast::AnnotationList > ()));
    }
#line 1963 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 49: // relation_tags: %empty
#line 689 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { }
#line 1969 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 50: // relation_tags: relation_tags "relation qualifier overidable"
#line 691 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addTag(RelationTag::OVERRIDABLE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 1977 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 51: // relation_tags: relation_tags "relation qualifier inline"
#line 695 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addTag(RelationTag::INLINE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 1985 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 52: // relation_tags: relation_tags "relation qualifier no_inline"
#line 699 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addTag(RelationTag::NO_INLINE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 1993 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 53: // relation_tags: relation_tags "relation qualifier magic"
#line 703 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addTag(RelationTag::MAGIC, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2001 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 54: // relation_tags: relation_tags "relation qualifier no_magic"
#line 707 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addTag(RelationTag::NO_MAGIC, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2009 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 55: // relation_tags: relation_tags "BRIE datastructure qualifier"
#line 711 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addReprTag(RelationTag::BRIE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2017 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 56: // relation_tags: relation_tags "BTREE datastructure qualifier"
#line 715 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addReprTag(RelationTag::BTREE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2025 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 57: // relation_tags: relation_tags "BTREE_DELETE datastructure qualifier"
#line 719 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addReprTag(RelationTag::BTREE_DELETE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2033 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 58: // relation_tags: relation_tags "equivalence relation qualifier"
#line 723 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addReprTag(RelationTag::EQREL, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2041 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 59: // relation_tags: relation_tags "relation qualifier output"
#line 728 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addDeprecatedTag(RelationTag::OUTPUT, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2049 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 60: // relation_tags: relation_tags "relation qualifier input"
#line 732 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addDeprecatedTag(RelationTag::INPUT, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2057 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 61: // relation_tags: relation_tags "relation qualifier printsize"
#line 736 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::set<RelationTag> > () = driver.addDeprecatedTag(RelationTag::PRINTSIZE, yystack_[0].location, YY_MOVE (yystack_[1].value.as < std::set<RelationTag> > ()));
    }
#line 2065 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 62: // non_empty_attribute_names: "identifier"
#line 746 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<std::string> > ().push_back(YY_MOVE (yystack_[0].value.as < std::string > ()));
    }
#line 2073 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 63: // non_empty_attribute_names: non_empty_attribute_names "," "identifier"
#line 751 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<std::string> > () = YY_MOVE (yystack_[2].value.as < std::vector<std::string> > ());
      yylhs.value.as < std::vector<std::string> > ().push_back(YY_MOVE (yystack_[0].value.as < std::string > ()));
    }
#line 2082 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 64: // dependency: "identifier"
#line 762 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
        yylhs.value.as < Own<ast::FunctionalConstraint> > () = mk<ast::FunctionalConstraint>(mk<ast::Variable>(YY_MOVE (yystack_[0].value.as < std::string > ()), yylhs.location), yylhs.location);
    }
#line 2090 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 65: // dependency: "(" non_empty_attribute_names ")"
#line 766 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      VecOwn<ast::Variable> keys;
      for (std::string s : YY_MOVE (yystack_[1].value.as < std::vector<std::string> > ())) {
        keys.push_back(mk<ast::Variable>(s, yylhs.location));
      }
      yylhs.value.as < Own<ast::FunctionalConstraint> > () = mk<ast::FunctionalConstraint>(std::move(keys), yylhs.location);
    }
#line 2102 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 66: // dependency_list_aux: dependency
#line 777 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::FunctionalConstraint> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::FunctionalConstraint> > ()));
    }
#line 2110 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 67: // dependency_list_aux: dependency_list_aux "," dependency
#line 781 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::FunctionalConstraint> > () = std::move(YY_MOVE (yystack_[2].value.as < VecOwn<ast::FunctionalConstraint> > ()));
      yylhs.value.as < VecOwn<ast::FunctionalConstraint> > ().push_back(std::move(YY_MOVE (yystack_[0].value.as < Own<ast::FunctionalConstraint> > ())));
    }
#line 2119 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 68: // dependency_list: %empty
#line 789 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { }
#line 2125 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 69: // dependency_list: "choice-domain" dependency_list_aux
#line 791 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::FunctionalConstraint> > () = std::move(YY_MOVE (yystack_[0].value.as < VecOwn<ast::FunctionalConstraint> > ()));
    }
#line 2133 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 70: // fact: annotations atom "."
#line 805 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[1].location);
      yylhs.value.as < Own<ast::Clause> > () = mk<ast::Clause>(YY_MOVE (yystack_[1].value.as < Own<ast::Atom> > ()), VecOwn<ast::Literal> {}, nullptr, yylhs.location);
      yylhs.value.as < Own<ast::Clause> > ()->setAnnotations(YY_MOVE (yystack_[2].value.as < ast::AnnotationList > ()));
    }
#line 2143 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 71: // rule: rule_def
#line 817 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Clause> > () = YY_MOVE (yystack_[0].value.as < VecOwn<ast::Clause> > ());
    }
#line 2151 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 72: // rule: rule_def query_plan
#line 821 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Clause> > () = YY_MOVE (yystack_[1].value.as < VecOwn<ast::Clause> > ());
      auto query_plan = YY_MOVE (yystack_[0].value.as < Own<ast::ExecutionPlan> > ());
      for (auto&& rule : yylhs.value.as < VecOwn<ast::Clause> > ()) {
        rule->setExecutionPlan(clone(query_plan));
      }
    }
#line 2163 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 73: // rule: annotations atom "<=" atom ":-" inner_annotations body "."
#line 829 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[6].location);
      auto bodies = YY_MOVE (yystack_[1].value.as < RuleBody > ()).toClauseBodies();
      const auto annotations = YY_MOVE (yystack_[7].value.as < ast::AnnotationList > ());
      const auto inner_annotations = YY_MOVE (yystack_[2].value.as < ast::AnnotationList > ());
      Own<ast::Atom> lt = nameUnnamedVariables(std::move(YY_MOVE (yystack_[6].value.as < Own<ast::Atom> > ())));
      Own<ast::Atom> gt = std::move(YY_MOVE (yystack_[4].value.as < Own<ast::Atom> > ()));
      for (auto&& body : bodies) {
        auto cur = mk<ast::SubsumptiveClause>(clone(lt));
        cur->setBodyLiterals(clone(body->getBodyLiterals()));
        auto literals = cur->getBodyLiterals();
        cur->setHead(clone(lt));
        cur->addToBodyFront(clone(gt));
        cur->addToBodyFront(clone(lt));
        cur->setAnnotations(annotations);
        cur->addAnnotations(inner_annotations);
        cur->setSrcLoc(yylhs.location);
        yylhs.value.as < VecOwn<ast::Clause> > ().push_back(std::move(cur));
      }
    }
#line 2188 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 74: // rule: annotations atom "<=" atom ":-" inner_annotations body "." query_plan
#line 850 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[7].location);
      auto bodies = YY_MOVE (yystack_[2].value.as < RuleBody > ()).toClauseBodies();
      const auto annotations = YY_MOVE (yystack_[8].value.as < ast::AnnotationList > ());
      const auto inner_annotations = YY_MOVE (yystack_[3].value.as < ast::AnnotationList > ());
      Own<ast::Atom> lt = nameUnnamedVariables(std::move(YY_MOVE (yystack_[7].value.as < Own<ast::Atom> > ())));
      Own<ast::Atom> gt = std::move(YY_MOVE (yystack_[5].value.as < Own<ast::Atom> > ()));
      for (auto&& body : bodies) {
        auto cur = mk<ast::SubsumptiveClause>(clone(lt));
        cur->setBodyLiterals(clone(body->getBodyLiterals()));
        auto literals = cur->getBodyLiterals();
        cur->setHead(clone(lt));
        cur->addToBodyFront(clone(gt));
        cur->addToBodyFront(clone(lt));
        cur->setAnnotations(annotations);
        cur->addAnnotations(inner_annotations);
        cur->setSrcLoc(yylhs.location);
        cur->setExecutionPlan(clone(YY_MOVE (yystack_[0].value.as < Own<ast::ExecutionPlan> > ())));
        yylhs.value.as < VecOwn<ast::Clause> > ().push_back(std::move(cur));
      }
    }
#line 2214 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 75: // rule_def: head ":-" inner_annotations body "."
#line 878 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto inner_annotations = YY_MOVE (yystack_[2].value.as < ast::AnnotationList > ());
      auto bodies = YY_MOVE (yystack_[1].value.as < RuleBody > ()).toClauseBodies();
      for (auto&& head : YY_MOVE (yystack_[4].value.as < VecOwn<ast::Atom> > ())) {
        for (auto&& body : bodies) {
          auto cur = clone(body);
          std::unique_ptr<ast::Atom> curhead = clone(head);
          // move annotations from head to clause
          cur->stealAnnotationsFrom(*curhead);
          cur->addAnnotations(inner_annotations);
          cur->setHead(std::move(curhead));
          cur->setSrcLoc(yylhs.location);
          yylhs.value.as < VecOwn<ast::Clause> > ().emplace_back(std::move(cur));
        }
      }
    }
#line 2235 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 76: // head: annotations atom
#line 901 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.location = yylhs.location.from(yystack_[0].location);
      auto atom = YY_MOVE (yystack_[0].value.as < Own<ast::Atom> > ());
      atom->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < VecOwn<ast::Atom> > ().emplace_back(std::move(atom));
    }
#line 2246 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 77: // head: head "," annotations atom
#line 908 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Atom> > () = YY_MOVE (yystack_[3].value.as < VecOwn<ast::Atom> > ());
      auto atom = YY_MOVE (yystack_[0].value.as < Own<ast::Atom> > ());
      atom->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < VecOwn<ast::Atom> > ().emplace_back(std::move(atom));
    }
#line 2257 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 78: // body: disjunction
#line 921 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[0].value.as < RuleBody > ());
    }
#line 2265 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 79: // disjunction: conjunction
#line 928 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[0].value.as < RuleBody > ());
    }
#line 2273 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 80: // disjunction: disjunction ";" conjunction
#line 932 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[2].value.as < RuleBody > ());
      yylhs.value.as < RuleBody > ().disjunct(YY_MOVE (yystack_[0].value.as < RuleBody > ()));
    }
#line 2282 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 81: // conjunction: term
#line 940 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[0].value.as < RuleBody > ());
    }
#line 2290 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 82: // conjunction: conjunction "," term
#line 944 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[2].value.as < RuleBody > ());
      yylhs.value.as < RuleBody > ().conjunct(YY_MOVE (yystack_[0].value.as < RuleBody > ()));
    }
#line 2299 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 83: // term: atom
#line 955 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = RuleBody::atom(YY_MOVE (yystack_[0].value.as < Own<ast::Atom> > ()));
    }
#line 2307 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 84: // term: constraint
#line 959 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = RuleBody::constraint(YY_MOVE (yystack_[0].value.as < Own<ast::Constraint> > ()));
    }
#line 2315 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 85: // term: "(" disjunction ")"
#line 963 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[1].value.as < RuleBody > ());
    }
#line 2323 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 86: // term: "!" term
#line 967 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[0].value.as < RuleBody > ()).negated();
    }
#line 2331 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 87: // atom: qualified_name "(" arg_list ")"
#line 977 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Atom> > () = mk<ast::Atom>(YY_MOVE (yystack_[3].value.as < ast::QualifiedName > ()), YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ()), yylhs.location);
    }
#line 2339 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 88: // constraint: arg "<" arg
#line 988 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::LT, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2347 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 89: // constraint: arg ">" arg
#line 992 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::GT, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2355 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 90: // constraint: arg "<=" arg
#line 996 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::LE, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2363 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 91: // constraint: arg ">=" arg
#line 1000 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::GE, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2371 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 92: // constraint: arg "=" arg
#line 1004 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::EQ, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2379 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 93: // constraint: arg "!=" arg
#line 1008 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::NE, YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2387 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 94: // constraint: "match predicate" "(" arg "," arg ")"
#line 1014 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::MATCH, YY_MOVE (yystack_[3].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[1].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2395 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 95: // constraint: "checks whether substring is contained in a string" "(" arg "," arg ")"
#line 1018 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
       yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BinaryConstraint>(BinaryConstraintOp::CONTAINS, YY_MOVE (yystack_[3].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[1].value.as < Own<ast::Argument> > ()), yylhs.location);
    }
#line 2403 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 96: // constraint: "true literal constraint"
#line 1024 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BooleanConstraint>(true , yylhs.location);
    }
#line 2411 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 97: // constraint: "false literal constraint"
#line 1028 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Constraint> > () = mk<ast::BooleanConstraint>(false, yylhs.location);
    }
#line 2419 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 98: // arg_list: %empty
#line 1038 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
    }
#line 2426 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 99: // arg_list: non_empty_arg_list
#line 1041 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Argument> > () = YY_MOVE (yystack_[0].value.as < VecOwn<ast::Argument> > ());
    }
#line 2434 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 100: // non_empty_arg_list: arg
#line 1047 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Argument> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2442 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 101: // non_empty_arg_list: non_empty_arg_list "," arg
#line 1051 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Argument> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Argument> > ()); yylhs.value.as < VecOwn<ast::Argument> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2450 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 102: // arg: "symbol"
#line 1062 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::StringConstant>(YY_MOVE (yystack_[0].value.as < std::string > ()), yylhs.location);
    }
#line 2458 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 103: // arg: "float"
#line 1066 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::NumericConstant>(YY_MOVE (yystack_[0].value.as < std::string > ()), ast::NumericConstant::Type::Float, yylhs.location);
    }
#line 2466 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 104: // arg: "unsigned number"
#line 1070 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto&& n = YY_MOVE (yystack_[0].value.as < std::string > ()); // drop the last character (`u`)
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::NumericConstant>(n.substr(0, n.size() - 1), ast::NumericConstant::Type::Uint, yylhs.location);
    }
#line 2475 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 105: // arg: "number"
#line 1075 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::NumericConstant>(YY_MOVE (yystack_[0].value.as < std::string > ()), yylhs.location);
    }
#line 2483 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 106: // arg: "recursive iteration keyword" "(" ")"
#line 1079 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IterationCounter>(yylhs.location);
    }
#line 2491 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 107: // arg: "_"
#line 1083 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::UnnamedVariable>(yylhs.location);
    }
#line 2499 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 108: // arg: "$"
#line 1087 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = driver.addDeprecatedCounter(yylhs.location);
    }
#line 2507 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 109: // arg: "auto-increment functor" "(" ")"
#line 1091 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::Counter>(yylhs.location);
    }
#line 2515 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 110: // arg: "identifier"
#line 1095 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::Variable>(YY_MOVE (yystack_[0].value.as < std::string > ()), yylhs.location);
    }
#line 2523 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 111: // arg: "nil reference"
#line 1099 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::NilConstant>(yylhs.location);
    }
#line 2531 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 112: // arg: "[" arg_list "]"
#line 1103 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::RecordInit>(YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ()), yylhs.location);
    }
#line 2539 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 113: // arg: "$" qualified_name "(" arg_list ")"
#line 1107 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::BranchInit>(YY_MOVE (yystack_[3].value.as < ast::QualifiedName > ()), YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ()), yylhs.location);
    }
#line 2547 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 114: // arg: "(" arg ")"
#line 1111 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = YY_MOVE (yystack_[1].value.as < Own<ast::Argument> > ());
    }
#line 2555 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 115: // arg: "type cast" "(" arg "," qualified_name ")"
#line 1115 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::TypeCast>(YY_MOVE (yystack_[3].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[1].value.as < ast::QualifiedName > ()), yylhs.location);
    }
#line 2563 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 116: // arg: "@" "identifier" "(" arg_list ")"
#line 1119 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::UserDefinedFunctor>(YY_MOVE (yystack_[3].value.as < std::string > ()), YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ()), yylhs.location);
    }
#line 2571 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 117: // arg: functor_built_in "(" arg_list ")"
#line 1123 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(YY_MOVE (yystack_[3].value.as < std::string > ()), YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ()), yylhs.location);
    }
#line 2579 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 118: // arg: aggregate_func "(" arg "," non_empty_arg_list ")"
#line 1129 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      VecOwn<ast::Argument> arg_list = YY_MOVE (yystack_[1].value.as < VecOwn<ast::Argument> > ());
      arg_list.insert(arg_list.begin(), YY_MOVE (yystack_[3].value.as < Own<ast::Argument> > ()));
      auto agg_2_func = [](AggregateOp op) -> char const* {
        switch (op) {
          case AggregateOp::COUNT : return {};
          case AggregateOp::MAX   : return "max";
          case AggregateOp::MEAN  : return {};
          case AggregateOp::MIN   : return "min";
          case AggregateOp::SUM   : return {};
          default                 :
            fatal("missing base op handler, or got an overload op?");
        }
      };
      if (auto* func_op = agg_2_func(YY_MOVE (yystack_[5].value.as < AggregateOp > ()))) {
        yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(func_op, std::move(arg_list), yylhs.location);
      } else {
        driver.error(yylhs.location, "aggregate operation has no functor equivalent");
        yylhs.value.as < Own<ast::Argument> > () = mk<ast::UnnamedVariable>(yylhs.location);
      }
    }
#line 2605 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 119: // arg: "-" arg
#line 1154 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      // If we have a constant that is not already negated we just negate the constant value.
      auto nested_arg = YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ());
      const auto* asNumeric = as<ast::NumericConstant>(nested_arg);
      if (asNumeric && !isPrefix("-", asNumeric->getConstant())) {
        yylhs.value.as < Own<ast::Argument> > () = mk<ast::NumericConstant>("-" + asNumeric->getConstant(), asNumeric->getFixedType(), yystack_[0].location);
      } else { // Otherwise, create a functor.
        yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, FUNCTOR_INTRINSIC_PREFIX_NEGATE_NAME, std::move(nested_arg));
      }
    }
#line 2620 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 120: // arg: "bnot" arg
#line 1165 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "~", YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2628 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 121: // arg: "lnot" arg
#line 1169 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "!", YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2636 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 122: // arg: arg "+" arg
#line 1175 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "+"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2644 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 123: // arg: arg "-" arg
#line 1179 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "-"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2652 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 124: // arg: arg "*" arg
#line 1183 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "*"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2660 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 125: // arg: arg "/" arg
#line 1187 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "/"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2668 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 126: // arg: arg "%" arg
#line 1191 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "%"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2676 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 127: // arg: arg "^" arg
#line 1195 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "**" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2684 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 128: // arg: arg "land" arg
#line 1199 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "&&" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2692 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 129: // arg: arg "lor" arg
#line 1203 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "||" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2700 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 130: // arg: arg "lxor" arg
#line 1207 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "^^" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2708 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 131: // arg: arg "band" arg
#line 1211 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "&"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2716 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 132: // arg: arg "bor" arg
#line 1215 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "|"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2724 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 133: // arg: arg "bxor" arg
#line 1219 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "^"  , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2732 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 134: // arg: arg "bshl" arg
#line 1223 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, "<<" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2740 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 135: // arg: arg "bshr" arg
#line 1227 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, ">>" , YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2748 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 136: // arg: arg "bshru" arg
#line 1231 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicFunctor>(yylhs.location, ">>>", YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ()), YY_MOVE (yystack_[0].value.as < Own<ast::Argument> > ()));
    }
#line 2756 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 137: // arg: "@" "@" "identifier" arg_list ":" arg "," aggregate_body
#line 1236 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto bodies = YY_MOVE (yystack_[0].value.as < RuleBody > ()).toClauseBodies();
      if (bodies.size() != 1) {
        driver.error("ERROR: disjunctions in aggregation clauses are currently not supported");
      }
      auto rest = YY_MOVE (yystack_[4].value.as < VecOwn<ast::Argument> > ());
      auto expr = rest.empty() ? nullptr : std::move(rest[0]);
      auto body = (bodies.size() == 1) ? clone(bodies[0]->getBodyLiterals()) : VecOwn<ast::Literal> {};
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::UserDefinedAggregator>(YY_MOVE (yystack_[5].value.as < std::string > ()), std::move(YY_MOVE (yystack_[2].value.as < Own<ast::Argument> > ())), std::move(expr), std::move(body), yylhs.location);
    }
#line 2771 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 138: // arg: aggregate_func arg_list ":" aggregate_body
#line 1248 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto aggregate_func = YY_MOVE (yystack_[3].value.as < AggregateOp > ());
      auto arg_list = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Argument> > ());
      auto bodies = YY_MOVE (yystack_[0].value.as < RuleBody > ()).toClauseBodies();
      if (bodies.size() != 1) {
        driver.error("ERROR: disjunctions in aggregation clauses are currently not supported");
      }
      // TODO: move this to a semantic check when aggs are extended to multiple exprs
      auto given    = arg_list.size();
      auto required = aggregateArity(aggregate_func);
      if (given < required.first || required.second < given) {
        driver.error("ERROR: incorrect expression arity for given aggregate mode");
      }
      auto expr = arg_list.empty() ? nullptr : std::move(arg_list[0]);
      auto body = (bodies.size() == 1) ? clone(bodies[0]->getBodyLiterals()) : VecOwn<ast::Literal> {};
      yylhs.value.as < Own<ast::Argument> > () = mk<ast::IntrinsicAggregator>(aggregate_func, std::move(expr), std::move(body), yylhs.location);
    }
#line 2793 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 139: // functor_built_in: "concatenation of strings"
#line 1269 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "cat";
    }
#line 2801 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 140: // functor_built_in: "ordinal number of a string"
#line 1273 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "ord";
    }
#line 2809 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 141: // functor_built_in: "range"
#line 1277 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "range";
    }
#line 2817 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 142: // functor_built_in: "length of a string"
#line 1281 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "strlen";
    }
#line 2825 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 143: // functor_built_in: "sub-string of a string"
#line 1285 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "substr";
    }
#line 2833 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 144: // functor_built_in: "convert to float"
#line 1289 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "to_float";
    }
#line 2841 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 145: // functor_built_in: "convert to signed integer"
#line 1293 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "to_number";
    }
#line 2849 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 146: // functor_built_in: "convert to string"
#line 1297 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "to_string";
    }
#line 2857 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 147: // functor_built_in: "convert to unsigned integer"
#line 1301 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "to_unsigned";
    }
#line 2865 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 148: // aggregate_func: "count aggregator"
#line 1308 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < AggregateOp > () = AggregateOp::COUNT;
    }
#line 2873 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 149: // aggregate_func: "max aggregator"
#line 1312 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < AggregateOp > () = AggregateOp::MAX;
    }
#line 2881 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 150: // aggregate_func: "mean aggregator"
#line 1316 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < AggregateOp > () = AggregateOp::MEAN;
    }
#line 2889 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 151: // aggregate_func: "min aggregator"
#line 1320 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < AggregateOp > () = AggregateOp::MIN;
    }
#line 2897 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 152: // aggregate_func: "sum aggregator"
#line 1324 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < AggregateOp > () = AggregateOp::SUM;
    }
#line 2905 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 153: // aggregate_body: "{" body "}"
#line 1331 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = YY_MOVE (yystack_[1].value.as < RuleBody > ());
    }
#line 2913 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 154: // aggregate_body: atom
#line 1335 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < RuleBody > () = RuleBody::atom(YY_MOVE (yystack_[0].value.as < Own<ast::Atom> > ()));
    }
#line 2921 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 155: // query_plan: "plan keyword" query_plan_list
#line 1345 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ExecutionPlan> > () = YY_MOVE (yystack_[0].value.as < Own<ast::ExecutionPlan> > ());
    }
#line 2929 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 156: // query_plan_list: "number" ":" plan_order
#line 1351 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ExecutionPlan> > () = mk<ast::ExecutionPlan>(yylhs.location);
      yylhs.value.as < Own<ast::ExecutionPlan> > ()->setOrderFor(RamSignedFromString(YY_MOVE (yystack_[2].value.as < std::string > ())), Own<ast::ExecutionOrder>(YY_MOVE (yystack_[0].value.as < Own<ast::ExecutionOrder> > ())));
    }
#line 2938 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 157: // query_plan_list: query_plan_list "," "number" ":" plan_order
#line 1356 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ExecutionPlan> > () = YY_MOVE (yystack_[4].value.as < Own<ast::ExecutionPlan> > ());
      yylhs.value.as < Own<ast::ExecutionPlan> > ()->setOrderFor(RamSignedFromString(YY_MOVE (yystack_[2].value.as < std::string > ())), YY_MOVE (yystack_[0].value.as < Own<ast::ExecutionOrder> > ()));
    }
#line 2947 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 158: // plan_order: "(" ")"
#line 1364 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ExecutionOrder> > () = mk<ast::ExecutionOrder>(ast::ExecutionOrder::ExecOrder(), yylhs.location);
    }
#line 2955 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 159: // plan_order: "(" non_empty_plan_order_list ")"
#line 1368 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ExecutionOrder> > () = mk<ast::ExecutionOrder>(YY_MOVE (yystack_[1].value.as < ast::ExecutionOrder::ExecOrder > ()), yylhs.location);
    }
#line 2963 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 160: // non_empty_plan_order_list: "number"
#line 1375 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::ExecutionOrder::ExecOrder > ().push_back(RamUnsignedFromString(YY_MOVE (yystack_[0].value.as < std::string > ())));
    }
#line 2971 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 161: // non_empty_plan_order_list: non_empty_plan_order_list "," "number"
#line 1379 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::ExecutionOrder::ExecOrder > () = YY_MOVE (yystack_[2].value.as < ast::ExecutionOrder::ExecOrder > ()); yylhs.value.as < ast::ExecutionOrder::ExecOrder > ().push_back(RamUnsignedFromString(YY_MOVE (yystack_[0].value.as < std::string > ())));
    }
#line 2979 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 162: // component_decl: component_head "{" component_body annotations "}"
#line 1393 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto head = YY_MOVE (yystack_[4].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > ()->setComponentType(clone(head->getComponentType()));
      yylhs.value.as < Own<ast::Component> > ()->copyBaseComponents(*head);
      yylhs.value.as < Own<ast::Component> > ()->setSrcLoc(yylhs.location);
      auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "at end of the component");
      }
    }
#line 2995 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 163: // component_head: "component declaration" component_type
#line 1411 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = mk<ast::Component>();
      yylhs.value.as < Own<ast::Component> > ()->setComponentType(YY_MOVE (yystack_[0].value.as < Own<ast::ComponentType> > ()));
    }
#line 3004 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 164: // component_head: component_head ":" component_type
#line 1416 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > ()->addBaseComponent(YY_MOVE (yystack_[0].value.as < Own<ast::ComponentType> > ()));
    }
#line 3013 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 165: // component_head: component_head "," component_type
#line 1421 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > ()->addBaseComponent(YY_MOVE (yystack_[0].value.as < Own<ast::ComponentType> > ()));
    }
#line 3022 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 166: // component_type: "identifier" component_type_params
#line 1432 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ComponentType> > () = mk<ast::ComponentType>(YY_MOVE (yystack_[1].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < std::vector<ast::QualifiedName> > ()), yylhs.location);
    }
#line 3030 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 167: // component_type_params: %empty
#line 1441 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { }
#line 3036 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 168: // component_type_params: "<" component_param_list ">"
#line 1443 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<ast::QualifiedName> > () = YY_MOVE (yystack_[1].value.as < std::vector<ast::QualifiedName> > ());
    }
#line 3044 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 169: // component_param_list: "identifier"
#line 1453 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<ast::QualifiedName> > ().push_back(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())));
    }
#line 3052 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 170: // component_param_list: component_param_list "," "identifier"
#line 1457 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<ast::QualifiedName> > () = YY_MOVE (yystack_[2].value.as < std::vector<ast::QualifiedName> > ());
      yylhs.value.as < std::vector<ast::QualifiedName> > ().push_back(driver.mkQN(YY_MOVE (yystack_[0].value.as < std::string > ())));
    }
#line 3061 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 171: // component_body: inner_annotations
#line 1468 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = mk<ast::Component>();
      yylhs.value.as < Own<ast::Component> > ()->addAnnotations(YY_MOVE (yystack_[0].value.as < ast::AnnotationList > ()));
    }
#line 3070 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 172: // component_body: component_body annotations "start of included file"
#line 1473 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "before '.include'");
      }
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
    }
#line 3082 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 173: // component_body: component_body annotations "end of included file"
#line 1481 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "at end of included file");
      }
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
    }
#line 3094 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 174: // component_body: component_body annotations "end of file"
#line 1489 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (!annotations.empty()) {
          driver.uselessAnnotations(annotations, "at end of file");
      }
      // unterminated component
      error(yystack_[2].location, "unterminated component, missing '}'");
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
    }
#line 3108 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 175: // component_body: component_body annotations directive_head
#line 1499 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      for (auto&& x : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Directive> > ())) {
        x->setAnnotations(annotations);
        yylhs.value.as < Own<ast::Component> > ()->addDirective(std::move(x));
      }
    }
#line 3121 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 176: // component_body: component_body rule
#line 1508 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[1].value.as < Own<ast::Component> > ());
      for (auto&& rule : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Clause> > ())) {
        yylhs.value.as < Own<ast::Component> > ()->addClause(std::move(rule));
      }
    }
#line 3132 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 177: // component_body: component_body fact
#line 1515 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[1].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > ()->addClause(YY_MOVE (yystack_[0].value.as < Own<ast::Clause> > ()));
    }
#line 3141 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 178: // component_body: component_body annotations "override rules of super-component" "identifier"
#line 1520 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[3].value.as < Own<ast::Component> > ());
      yylhs.value.as < Own<ast::Component> > ()->addOverride(YY_MOVE (yystack_[0].value.as < std::string > ()));
    }
#line 3150 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 179: // component_body: component_body annotations component_init
#line 1525 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      auto component_init = YY_MOVE (yystack_[0].value.as < Own<ast::ComponentInit> > ());
      component_init->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < Own<ast::Component> > ()->addInstantiation(std::move(component_init));
    }
#line 3161 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 180: // component_body: component_body annotations component_decl
#line 1532 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      auto component_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Component> > ());
      component_decl->prependAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < Own<ast::Component> > ()->addComponent(std::move(component_decl));
    }
#line 3172 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 181: // component_body: component_body annotations type_decl
#line 1539 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      auto type_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Type> > ());
      type_decl->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < Own<ast::Component> > ()->addType(std::move(type_decl));
    }
#line 3183 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 182: // component_body: component_body annotations lattice_decl
#line 1546 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      auto lattice_decl = YY_MOVE (yystack_[0].value.as < Own<ast::Lattice> > ());
      lattice_decl->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
      yylhs.value.as < Own<ast::Component> > ()->addLattice(std::move(lattice_decl));
    }
#line 3194 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 183: // component_body: component_body annotations relation_decl
#line 1553 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Component> > () = YY_MOVE (yystack_[2].value.as < Own<ast::Component> > ());
      const auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      for (auto&& rel : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Relation> > ())) {
        driver.addIoFromDeprecatedTag(*rel);
        // Note: we duplicate annotations on every relation of the declaration.
        //
        // An alternative would be to allow distinct annotations before each
        // relation name.
        rel->setAnnotations(annotations);
        yylhs.value.as < Own<ast::Component> > ()->addRelation(std::move(rel));
      }
    }
#line 3212 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 184: // component_init: "component instantiation" "identifier" "=" component_type
#line 1573 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::ComponentInit> > () = mk<ast::ComponentInit>(YY_MOVE (yystack_[2].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < Own<ast::ComponentType> > ()), yylhs.location);
    }
#line 3220 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 185: // functor_decl: "functor declaration" "identifier" "(" functor_arg_type_list ")" ":" qualified_name
#line 1587 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::FunctorDeclaration> > () = mk<ast::FunctorDeclaration>(YY_MOVE (yystack_[5].value.as < std::string > ()), YY_MOVE (yystack_[3].value.as < VecOwn<ast::Attribute> > ()), mk<ast::Attribute>("return_type", YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location), false, yylhs.location);
    }
#line 3228 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 186: // functor_decl: "functor declaration" "identifier" "(" functor_arg_type_list ")" ":" qualified_name "stateful functor"
#line 1591 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::FunctorDeclaration> > () = mk<ast::FunctorDeclaration>(YY_MOVE (yystack_[6].value.as < std::string > ()), YY_MOVE (yystack_[4].value.as < VecOwn<ast::Attribute> > ()), mk<ast::Attribute>("return_type", YY_MOVE (yystack_[1].value.as < ast::QualifiedName > ()), yystack_[1].location), true, yylhs.location);
    }
#line 3236 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 187: // functor_arg_type_list: %empty
#line 1600 "/home/lun/workspace/souffle/src/parser/parser.yy"
           { }
#line 3242 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 188: // functor_arg_type_list: non_empty_functor_arg_type_list
#line 1602 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > () = YY_MOVE (yystack_[0].value.as < VecOwn<ast::Attribute> > ());
    }
#line 3250 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 189: // non_empty_functor_arg_type_list: functor_attribute
#line 1609 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Attribute> > ()));
    }
#line 3258 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 190: // non_empty_functor_arg_type_list: non_empty_functor_arg_type_list "," functor_attribute
#line 1613 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Attribute> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Attribute> > ()); yylhs.value.as < VecOwn<ast::Attribute> > ().push_back(YY_MOVE (yystack_[0].value.as < Own<ast::Attribute> > ()));
    }
#line 3266 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 191: // functor_attribute: annotations qualified_name
#line 1620 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Attribute> > () = mk<ast::Attribute>("", YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location);
      yylhs.value.as < Own<ast::Attribute> > ()->setAnnotations(YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ()));
    }
#line 3275 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 192: // functor_attribute: annotations "identifier" ":" qualified_name
#line 1625 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Attribute> > () = mk<ast::Attribute>(YY_MOVE (yystack_[2].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location);
      yylhs.value.as < Own<ast::Attribute> > ()->setAnnotations(YY_MOVE (yystack_[3].value.as < ast::AnnotationList > ()));
    }
#line 3284 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 193: // pragma: "pragma directive" "symbol" "symbol"
#line 1640 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Pragma> > () = mk<ast::Pragma>(YY_MOVE (yystack_[1].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < std::string > ()), yylhs.location);
    }
#line 3292 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 194: // pragma: "pragma directive" "symbol"
#line 1644 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < Own<ast::Pragma> > () = mk<ast::Pragma>(YY_MOVE (yystack_[0].value.as < std::string > ()), "", yylhs.location);
    }
#line 3300 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 195: // directive_head: directive_head_decl directive_list
#line 1654 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto directive_head_decl = YY_MOVE (yystack_[1].value.as < ast::DirectiveType > ());
      for (auto&& io : YY_MOVE (yystack_[0].value.as < VecOwn<ast::Directive> > ())) {
        io->setType(directive_head_decl);
        yylhs.value.as < VecOwn<ast::Directive> > ().push_back(std::move(io));
      }
    }
#line 3312 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 196: // directive_head_decl: "input directives declaration"
#line 1665 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::DirectiveType > () = ast::DirectiveType::input;
    }
#line 3320 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 197: // directive_head_decl: "output directives declaration"
#line 1669 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::DirectiveType > () = ast::DirectiveType::output;
    }
#line 3328 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 198: // directive_head_decl: "printsize directives declaration"
#line 1673 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::DirectiveType > () = ast::DirectiveType::printsize;
    }
#line 3336 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 199: // directive_head_decl: "limitsize directives declaration"
#line 1677 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::DirectiveType > () = ast::DirectiveType::limitsize;
    }
#line 3344 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 200: // directive_list: relation_directive_list
#line 1687 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Directive> > () = YY_MOVE (yystack_[0].value.as < VecOwn<ast::Directive> > ());
    }
#line 3352 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 201: // directive_list: relation_directive_list "(" ")"
#line 1691 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Directive> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Directive> > ());
    }
#line 3360 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 202: // directive_list: relation_directive_list "(" non_empty_key_value_pairs ")"
#line 1695 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Directive> > () = YY_MOVE (yystack_[3].value.as < VecOwn<ast::Directive> > ());
      for (auto&& kvp : YY_MOVE (yystack_[1].value.as < std::vector<std::pair<std::string, std::string>> > ())) {
        for (auto&& io : yylhs.value.as < VecOwn<ast::Directive> > ()) {
          io->addParameter(kvp.first, kvp.second);
        }
      }
    }
#line 3373 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 203: // relation_directive_list: qualified_name
#line 1710 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Directive> > ().push_back(mk<ast::Directive>(ast::DirectiveType::input, YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location));
    }
#line 3381 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 204: // relation_directive_list: relation_directive_list "," qualified_name
#line 1714 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < VecOwn<ast::Directive> > () = YY_MOVE (yystack_[2].value.as < VecOwn<ast::Directive> > ());
      yylhs.value.as < VecOwn<ast::Directive> > ().push_back(mk<ast::Directive>(ast::DirectiveType::input, YY_MOVE (yystack_[0].value.as < ast::QualifiedName > ()), yystack_[0].location));
    }
#line 3390 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 205: // non_empty_key_value_pairs: "identifier" "=" kvp_value
#line 1725 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<std::pair<std::string, std::string>> > ().push_back({YY_MOVE (yystack_[2].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < std::string > ())});
    }
#line 3398 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 206: // non_empty_key_value_pairs: non_empty_key_value_pairs "," "identifier" "=" kvp_value
#line 1729 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::vector<std::pair<std::string, std::string>> > () = YY_MOVE (yystack_[4].value.as < std::vector<std::pair<std::string, std::string>> > ());
      yylhs.value.as < std::vector<std::pair<std::string, std::string>> > ().push_back({YY_MOVE (yystack_[2].value.as < std::string > ()), YY_MOVE (yystack_[0].value.as < std::string > ())});
    }
#line 3407 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 207: // kvp_value: "symbol"
#line 1737 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = YY_MOVE (yystack_[0].value.as < std::string > ());
    }
#line 3415 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 208: // kvp_value: "identifier"
#line 1741 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = YY_MOVE (yystack_[0].value.as < std::string > ());
    }
#line 3423 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 209: // kvp_value: "number"
#line 1745 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = YY_MOVE (yystack_[0].value.as < std::string > ());
    }
#line 3431 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 210: // kvp_value: "true literal constraint"
#line 1749 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "true";
    }
#line 3439 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 211: // kvp_value: "false literal constraint"
#line 1753 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < std::string > () = "false";
    }
#line 3447 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 212: // annotations: %empty
#line 1764 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
    }
#line 3454 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 213: // annotations: annotations annotation
#line 1767 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      auto annotations = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      if (annotations.empty()) {
        yylhs.location = yystack_[0].location;
      }
      annotations.emplace_back(YY_MOVE (yystack_[0].value.as < ast::Annotation > ()));
      yylhs.value.as < ast::AnnotationList > () = std::move(annotations);
    }
#line 3467 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 214: // annotation: "@" "[" ident_token annotation_input "]"
#line 1779 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      ast::QualifiedName key = driver.mkQN(std::get<ast::Single>(YY_MOVE (yystack_[2].value.as < ast::TokenTree > ())).token.text);
      yylhs.value.as < ast::Annotation > () = ast::Annotation(
              ast::Annotation::Kind::Normal, ast::Annotation::Style::Outer, key, YY_MOVE (yystack_[1].value.as < ast::TokenStream > ()), yylhs.location);
    }
#line 3477 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 215: // annotation: "outer doc comment"
#line 1785 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // doc comment is a syntactic sugar for annotation `@[doc = "some doc"]`
      ast::TokenStream ts{makeTokenTree(ast::TokenKind::Eq, "="),
              ast::Single{ast::TokenKind::Symbol, YY_MOVE (yystack_[0].value.as < std::string > ())}};
      yylhs.value.as < ast::Annotation > () = ast::Annotation(ast::Annotation::Kind::DocComment, ast::Annotation::Style::Outer,
              ast::QualifiedName::fromString("doc"), std::move(ts), yylhs.location);
    }
#line 3488 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 216: // annotation_input: %empty
#line 1795 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
    }
#line 3495 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 217: // annotation_input: "=" token token_stream
#line 1798 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::TokenStream > () = YY_MOVE (yystack_[0].value.as < ast::TokenStream > ());
      yylhs.value.as < ast::TokenStream > ().insert(yylhs.value.as < ast::TokenStream > ().begin(), YY_MOVE (yystack_[1].value.as < ast::TokenTree > ()));
      yylhs.value.as < ast::TokenStream > ().insert(yylhs.value.as < ast::TokenStream > ().begin(), makeTokenTree(ast::TokenKind::Eq, "="));
    }
#line 3505 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 218: // annotation_input: "=" ident_token token_stream
#line 1804 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::TokenStream > () = YY_MOVE (yystack_[0].value.as < ast::TokenStream > ());
      yylhs.value.as < ast::TokenStream > ().insert(yylhs.value.as < ast::TokenStream > ().begin(), YY_MOVE (yystack_[1].value.as < ast::TokenTree > ()));
      yylhs.value.as < ast::TokenStream > ().insert(yylhs.value.as < ast::TokenStream > ().begin(), makeTokenTree(ast::TokenKind::Eq, "="));
    }
#line 3515 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 219: // annotation_input: "=" delim
#line 1810 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::TokenStream > () = {YY_MOVE (yystack_[0].value.as < ast::TokenTree > ())};
      yylhs.value.as < ast::TokenStream > ().insert(yylhs.value.as < ast::TokenStream > ().begin(), makeTokenTree(ast::TokenKind::Eq, "="));
    }
#line 3524 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 220: // annotation_input: delim
#line 1815 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::TokenStream > () = ast::TokenStream{YY_MOVE (yystack_[0].value.as < ast::TokenTree > ())};
    }
#line 3532 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 221: // inner_annotations: %empty
#line 1822 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
    }
#line 3539 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 222: // inner_annotations: non_empty_inner_annotations
#line 1825 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::AnnotationList > () = YY_MOVE (yystack_[0].value.as < ast::AnnotationList > ());
    }
#line 3547 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 223: // non_empty_inner_annotations: inner_annotation
#line 1832 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::AnnotationList > ().emplace_back(YY_MOVE (yystack_[0].value.as < ast::Annotation > ()));
    }
#line 3555 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 224: // non_empty_inner_annotations: non_empty_inner_annotations inner_annotation
#line 1836 "/home/lun/workspace/souffle/src/parser/parser.yy"
    {
      yylhs.value.as < ast::AnnotationList > () = YY_MOVE (yystack_[1].value.as < ast::AnnotationList > ());
      yylhs.value.as < ast::AnnotationList > ().emplace_back(YY_MOVE (yystack_[0].value.as < ast::Annotation > ()));
    }
#line 3564 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 225: // inner_annotation: "inner doc comment"
#line 1844 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // doc comment is a syntactic sugar for annotation `@[doc = "some doc"]`
      ast::TokenStream ts{makeTokenTree(ast::TokenKind::Eq, "="),
              ast::Single{ast::TokenKind::Symbol, YY_MOVE (yystack_[0].value.as < std::string > ())}};
      yylhs.value.as < ast::Annotation > () = ast::Annotation(ast::Annotation::Kind::DocComment, ast::Annotation::Style::Inner,
              ast::QualifiedName::fromString("doc"), std::move(ts), yystack_[0].location);
    }
#line 3575 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 226: // inner_annotation: "@!" "[" ident_token annotation_input "]"
#line 1851 "/home/lun/workspace/souffle/src/parser/parser.yy"
    { // we introduce ATNOT (`@!`) token because using just `@` followed by `!`
      // cause shift/reduce conflicts in the grammar when inner annotations are followed
      // by outter annotations of the next item:
      //
      // ```
      // .comp C {
      //   @![inner_for_C()]
      //   @[outter_for_D()]
      //   .decl D()
      // }
      // ```
      //
      // The parser generator (bison) is not able to lookahead for `!` after `@`. When it
      // sees the first `@` it has two choices:
      // - either consider empty inner_annotations and start outter_annotations
      //   (although it would fail because of the following `!`).
      // - or consider the start of an inner annotation.
      //
      // For these reason, we make the scanner detect `@!` as a single token.
      // The scanner does not detect any variant of `@` followed by `!`
      // if there is a whitespace or a comment in-between.
      // I believe it is a good enough tradeoff to keep the lexer simple.

      ast::QualifiedName key = driver.mkQN(std::get<ast::Single>(YY_MOVE (yystack_[2].value.as < ast::TokenTree > ())).token.text);
      yylhs.value.as < ast::Annotation > () = ast::Annotation(
              ast::Annotation::Kind::Normal, ast::Annotation::Style::Inner, key, YY_MOVE (yystack_[1].value.as < ast::TokenStream > ()), yylhs.location);
    }
#line 3607 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 227: // token_stream: %empty
#line 1880 "/home/lun/workspace/souffle/src/parser/parser.yy"
           { }
#line 3613 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 228: // token_stream: token_stream token
#line 1882 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenStream > () = YY_MOVE (yystack_[1].value.as < ast::TokenStream > ());
    yylhs.value.as < ast::TokenStream > ().emplace_back(YY_MOVE (yystack_[0].value.as < ast::TokenTree > ()));
  }
#line 3622 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 229: // token_stream: token_stream ident_token
#line 1887 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenStream > () = YY_MOVE (yystack_[1].value.as < ast::TokenStream > ());
    yylhs.value.as < ast::TokenStream > ().emplace_back(YY_MOVE (yystack_[0].value.as < ast::TokenTree > ()));
  }
#line 3631 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 230: // token_stream: token_stream delim
#line 1892 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenStream > () = YY_MOVE (yystack_[1].value.as < ast::TokenStream > ());
    yylhs.value.as < ast::TokenStream > ().emplace_back(YY_MOVE (yystack_[0].value.as < ast::TokenTree > ()));
  }
#line 3640 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 231: // delim: "(" token_stream ")"
#line 1900 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::Delimiter::Paren, std::move(YY_MOVE (yystack_[1].value.as < ast::TokenStream > ())));
  }
#line 3648 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 232: // delim: "{" token_stream "}"
#line 1904 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::Delimiter::Brace, std::move(YY_MOVE (yystack_[1].value.as < ast::TokenStream > ())));
  }
#line 3656 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 233: // delim: "[" token_stream "]"
#line 1908 "/home/lun/workspace/souffle/src/parser/parser.yy"
  {
    yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::Delimiter::Bracket, std::move(YY_MOVE (yystack_[1].value.as < ast::TokenStream > ())));
  }
#line 3664 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 234: // ident_token: "identifier"
#line 1915 "/home/lun/workspace/souffle/src/parser/parser.yy"
              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, YY_MOVE (yystack_[0].value.as < std::string > ())); }
#line 3670 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 235: // ident_token: "type cast"
#line 1916 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "as"); }
#line 3676 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 236: // ident_token: "auto-increment functor"
#line 1917 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "autoinc"); }
#line 3682 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 237: // ident_token: "BRIE datastructure qualifier"
#line 1918 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "brie"); }
#line 3688 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 238: // ident_token: "BTREE_DELETE datastructure qualifier"
#line 1919 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "btree_delete"); }
#line 3694 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 239: // ident_token: "BTREE datastructure qualifier"
#line 1920 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "btree"); }
#line 3700 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 240: // ident_token: "band"
#line 1921 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "band"); }
#line 3706 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 241: // ident_token: "bnot"
#line 1922 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bnot"); }
#line 3712 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 242: // ident_token: "bor"
#line 1923 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bor"); }
#line 3718 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 243: // ident_token: "bshl"
#line 1924 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bshl"); }
#line 3724 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 244: // ident_token: "bshr"
#line 1925 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bshr"); }
#line 3730 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 245: // ident_token: "bshru"
#line 1926 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bshru"); }
#line 3736 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 246: // ident_token: "bxor"
#line 1927 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "bxor"); }
#line 3742 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 247: // ident_token: "concatenation of strings"
#line 1928 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "cat"); }
#line 3748 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 248: // ident_token: "choice-domain"
#line 1929 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "choice-domain"); }
#line 3754 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 249: // ident_token: "count aggregator"
#line 1930 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "count"); }
#line 3760 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 250: // ident_token: "equivalence relation qualifier"
#line 1931 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "eqrel"); }
#line 3766 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 251: // ident_token: "false literal constraint"
#line 1932 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "false"); }
#line 3772 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 252: // ident_token: "relation qualifier inline"
#line 1933 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "inline"); }
#line 3778 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 253: // ident_token: "relation qualifier input"
#line 1934 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "input"); }
#line 3784 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 254: // ident_token: "land"
#line 1935 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "land"); }
#line 3790 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 255: // ident_token: "lnot"
#line 1936 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "lnot"); }
#line 3796 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 256: // ident_token: "lor"
#line 1937 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "lor"); }
#line 3802 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 257: // ident_token: "lxor"
#line 1938 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "lxor"); }
#line 3808 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 258: // ident_token: "relation qualifier magic"
#line 1939 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "magic"); }
#line 3814 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 259: // ident_token: "max aggregator"
#line 1940 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "max"); }
#line 3820 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 260: // ident_token: "mean aggregator"
#line 1941 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "mean"); }
#line 3826 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 261: // ident_token: "min aggregator"
#line 1942 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "min"); }
#line 3832 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 262: // ident_token: "nil reference"
#line 1943 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "nil"); }
#line 3838 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 263: // ident_token: "relation qualifier no_inline"
#line 1944 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "no_inline"); }
#line 3844 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 264: // ident_token: "relation qualifier no_magic"
#line 1945 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "no_magic"); }
#line 3850 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 265: // ident_token: "ordinal number of a string"
#line 1946 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "ord"); }
#line 3856 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 266: // ident_token: "relation qualifier output"
#line 1947 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "output"); }
#line 3862 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 267: // ident_token: "relation qualifier overidable"
#line 1948 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "overridable"); }
#line 3868 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 268: // ident_token: "relation qualifier printsize"
#line 1949 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "printsize"); }
#line 3874 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 269: // ident_token: "range"
#line 1950 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "range"); }
#line 3880 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 270: // ident_token: "stateful functor"
#line 1951 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "stateful"); }
#line 3886 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 271: // ident_token: "length of a string"
#line 1952 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "strlen"); }
#line 3892 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 272: // ident_token: "sub-string of a string"
#line 1953 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "substr"); }
#line 3898 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 273: // ident_token: "sum aggregator"
#line 1954 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "sum"); }
#line 3904 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 274: // ident_token: "checks whether substring is contained in a string"
#line 1955 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "contains"); }
#line 3910 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 275: // ident_token: "match predicate"
#line 1956 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "match"); }
#line 3916 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 276: // ident_token: "convert to float"
#line 1957 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "to_float"); }
#line 3922 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 277: // ident_token: "convert to signed integer"
#line 1958 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "to_number"); }
#line 3928 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 278: // ident_token: "convert to string"
#line 1959 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "to_string"); }
#line 3934 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 279: // ident_token: "convert to unsigned integer"
#line 1960 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "to_unsigned"); }
#line 3940 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 280: // ident_token: "true literal constraint"
#line 1961 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, "true"); }
#line 3946 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 281: // token: "float"
#line 1965 "/home/lun/workspace/souffle/src/parser/parser.yy"
              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Float, YY_MOVE (yystack_[0].value.as < std::string > ())); }
#line 3952 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 282: // token: "number"
#line 1966 "/home/lun/workspace/souffle/src/parser/parser.yy"
              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Number, YY_MOVE (yystack_[0].value.as < std::string > ())); }
#line 3958 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 283: // token: "unsigned number"
#line 1967 "/home/lun/workspace/souffle/src/parser/parser.yy"
              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Unsigned, YY_MOVE (yystack_[0].value.as < std::string > ())); }
#line 3964 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 284: // token: "symbol"
#line 1968 "/home/lun/workspace/souffle/src/parser/parser.yy"
              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Symbol, YY_MOVE (yystack_[0].value.as < std::string > ())); }
#line 3970 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 285: // token: "@"
#line 1970 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::At, "@"); }
#line 3976 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 286: // token: "@!"
#line 1971 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::AtNot, "@!"); }
#line 3982 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 287: // token: "^"
#line 1972 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Caret, "^"); }
#line 3988 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 288: // token: ":"
#line 1973 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Colon, ":"); }
#line 3994 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 289: // token: ","
#line 1974 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Comma, ","); }
#line 4000 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 290: // token: "$"
#line 1975 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Dollar, "$"); }
#line 4006 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 291: // token: "."
#line 1976 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Dot, "."); }
#line 4012 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 292: // token: "::"
#line 1977 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::DoubleColon, "::"); }
#line 4018 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 293: // token: "="
#line 1978 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Eq, "="); }
#line 4024 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 294: // token: "!"
#line 1979 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Exclamation, "!"); }
#line 4030 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 295: // token: ">="
#line 1980 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ge, ">="); }
#line 4036 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 296: // token: ">"
#line 1981 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Gt, ">"); }
#line 4042 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 297: // token: "inner doc comment"
#line 1982 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { /* ignore doc comments */ }
#line 4048 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 298: // token: ":-"
#line 1983 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::If, ":-"); }
#line 4054 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 299: // token: "<="
#line 1984 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Le, "<="); }
#line 4060 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 300: // token: "<"
#line 1985 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Lt, "<"); }
#line 4066 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 301: // token: "->"
#line 1986 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::MapsTo, "->"); }
#line 4072 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 302: // token: "-"
#line 1987 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Minus, "-"); }
#line 4078 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 303: // token: "!="
#line 1988 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ne, "!="); }
#line 4084 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 304: // token: "outer doc comment"
#line 1989 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { /* ignore doc comments */ }
#line 4090 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 305: // token: "%"
#line 1990 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Percent, "%"); }
#line 4096 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 306: // token: "|"
#line 1991 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Pipe, "|"); }
#line 4102 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 307: // token: "+"
#line 1992 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Plus, "+"); }
#line 4108 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 308: // token: ";"
#line 1993 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Semicolon, ";"); }
#line 4114 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 309: // token: "/"
#line 1994 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Slash, "/"); }
#line 4120 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 310: // token: "*"
#line 1995 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Star, "*"); }
#line 4126 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 311: // token: "<:"
#line 1996 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Subtype, "<:"); }
#line 4132 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 312: // token: "_"
#line 1997 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Underscore, "_"); }
#line 4138 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 313: // token: "component declaration"
#line 1999 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".comp"); }
#line 4144 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 314: // token: "relation declaration"
#line 2000 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".decl"); }
#line 4150 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 315: // token: "functor declaration"
#line 2001 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".functor"); }
#line 4156 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 316: // token: "input directives declaration"
#line 2002 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".input"); }
#line 4162 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 317: // token: "component instantiation"
#line 2003 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".init"); }
#line 4168 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 318: // token: "lattice declaration"
#line 2004 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".lattice"); }
#line 4174 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 319: // token: "limitsize directives declaration"
#line 2005 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".limitsize"); }
#line 4180 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 320: // token: "numeric type declaration"
#line 2006 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".number_type"); }
#line 4186 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 321: // token: "output directives declaration"
#line 2007 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".output"); }
#line 4192 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 322: // token: "override rules of super-component"
#line 2008 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".override"); }
#line 4198 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 323: // token: "plan keyword"
#line 2009 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".plan"); }
#line 4204 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 324: // token: "pragma directive"
#line 2010 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".pragma"); }
#line 4210 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 325: // token: "printsize directives declaration"
#line 2011 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".printsize"); }
#line 4216 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 326: // token: "symbolic type declaration"
#line 2012 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".symbol_type"); }
#line 4222 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;

  case 327: // token: "type declaration"
#line 2013 "/home/lun/workspace/souffle/src/parser/parser.yy"
                              { yylhs.value.as < ast::TokenTree > () = makeTokenTree(ast::TokenKind::Ident, ".type"); }
#line 4228 "/home/lun/workspace/souffle/build/src/parser/parser.cc"
    break;


#line 4232 "/home/lun/workspace/souffle/build/src/parser/parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        context yyctx (*this, yyla);
        std::string msg = yysyntax_error_ (yyctx);
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }

  std::string
  parser::symbol_name (symbol_kind_type yysymbol)
  {
    return yytnamerr_ (yytname_[yysymbol]);
  }



  // parser::context.
  parser::context::context (const parser& yyparser, const symbol_type& yyla)
    : yyparser_ (yyparser)
    , yyla_ (yyla)
  {}

  int
  parser::context::expected_tokens (symbol_kind_type yyarg[], int yyargn) const
  {
    // Actual number of expected tokens
    int yycount = 0;

    const int yyn = yypact_[+yyparser_.yystack_[0].state];
    if (!yy_pact_value_is_default_ (yyn))
      {
        /* Start YYX at -YYN if negative to avoid negative indexes in
           YYCHECK.  In other words, skip the first -YYN actions for
           this state because they are default actions.  */
        const int yyxbegin = yyn < 0 ? -yyn : 0;
        // Stay within bounds of both yycheck and yytname.
        const int yychecklim = yylast_ - yyn + 1;
        const int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
        for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
          if (yycheck_[yyx + yyn] == yyx && yyx != symbol_kind::S_YYerror
              && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
            {
              if (!yyarg)
                ++yycount;
              else if (yycount == yyargn)
                return 0;
              else
                yyarg[yycount++] = YY_CAST (symbol_kind_type, yyx);
            }
      }

    if (yyarg && yycount == 0 && 0 < yyargn)
      yyarg[0] = symbol_kind::S_YYEMPTY;
    return yycount;
  }






  int
  parser::yy_syntax_error_arguments_ (const context& yyctx,
                                                 symbol_kind_type yyarg[], int yyargn) const
  {
    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */

    if (!yyctx.lookahead ().empty ())
      {
        if (yyarg)
          yyarg[0] = yyctx.token ();
        int yyn = yyctx.expected_tokens (yyarg ? yyarg + 1 : yyarg, yyargn - 1);
        return yyn + 1;
      }
    return 0;
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (const context& yyctx) const
  {
    // Its maximum.
    enum { YYARGS_MAX = 5 };
    // Arguments of yyformat.
    symbol_kind_type yyarg[YYARGS_MAX];
    int yycount = yy_syntax_error_arguments_ (yyctx, yyarg, YYARGS_MAX);

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += symbol_name (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -394;

  const short parser::yytable_ninf_ = -188;

  const short
  parser::yypact_[] =
  {
    -394,    33,    76,  -394,  -394,  -394,    85,   -24,    25,    41,
    -394,   -54,  -394,  -394,  -394,  -394,  -394,   139,   155,   188,
    -394,  -394,  -394,  -394,   195,   197,   208,   224,   225,   226,
     161,  -394,    35,  -394,  -394,  -394,    44,  -394,    77,  -394,
    -394,  -394,  -394,   230,  -394,   167,   183,   193,  -394,   210,
     -54,  -394,     4,   261,   186,   -25,   194,    26,   180,   181,
    -394,   190,  -394,  -394,   977,   300,   275,  -394,   230,   208,
     208,   -54,   198,  -394,    32,   207,   295,   977,  -394,    68,
    -394,  -394,  -394,   233,   234,   235,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,   236,  -394,
    -394,  -394,  -394,   242,    39,  -394,   300,  -394,   230,   300,
     210,   210,   300,   300,   218,   220,   237,  -394,  -394,  -394,
     962,   243,   878,  -394,  -394,  -394,   276,   244,   319,  -394,
     246,    14,   230,   247,   331,  -394,   208,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,    37,  -394,   300,   258,   260,  1284,
    -394,   297,  -394,  -394,  -394,  -394,     8,   230,     9,  -394,
     262,    37,   263,   300,   300,   265,   300,   267,   342,   277,
     113,   264,  -394,   120,   337,   264,   264,  -394,   210,   210,
     300,   300,   300,   300,   300,   300,   300,   300,   300,   300,
     300,   300,   300,   300,   300,   300,   300,   300,   300,   300,
     300,   300,   300,   269,   270,  -394,   125,  -394,    15,  -394,
     278,   272,   274,  -394,    16,   271,   283,   198,  -394,   290,
     292,  -394,  -394,   198,   280,  -394,   -51,  -394,  -394,  -394,
     770,  -394,   293,  -394,  1046,  -394,   300,   -54,  -394,  -394,
      49,   279,  -394,   128,   198,  -394,  -394,   131,   207,   296,
    -394,  1080,  1114,  -394,  1148,   300,   300,  -394,   300,  -394,
    -394,   237,  -394,   134,   134,  1284,   264,   264,   264,   264,
    1284,  1284,  1284,  1284,  1284,  1055,   839,  1358,    45,    45,
      45,    62,  1318,  1352,   298,  1012,     5,   367,  -394,  -394,
     294,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,     6,  -394,   299,  -394,   303,   198,   -54,
    -394,   -31,   230,  -394,    19,   374,   376,  -394,   446,   554,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,  -394,
     662,  -394,  1284,   210,  -394,  -394,  -394,   380,  -394,  -394,
    -394,  -394,  -394,  -394,  -394,    28,  -394,   381,  -394,   382,
    -394,  -394,   300,   300,   230,   308,   310,   314,  -394,   300,
     210,  -394,  -394,   315,  -394,   230,  -394,   384,  -394,   316,
     230,  -394,   230,   304,  -394,   198,    19,   271,   292,   301,
     306,   318,  -394,  -394,  -394,  -394,  -394,  -394,   770,   770,
    -394,   317,  -394,  -394,  -394,  -394,  -394,  -394,  -394,   321,
    -394,  1182,  1216,    63,  -394,   300,  -394,   145,   309,  -394,
     -47,  -394,   148,     6,    23,   198,  -394,   -55,  -394,   300,
    -394,   374,    85,    28,  -394,  -394,  -394,  1250,  -394,  -394,
     239,   313,  -394,   397,  -394,  -394,  -394,  1284,  -394,  -394,
    -394,     5,  -394,  -394,  -394
  };

  const short
  parser::yydefact_[] =
  {
       3,     0,   212,     1,     9,     8,    71,     0,     0,     0,
      72,   221,   212,     5,     4,     6,    17,     0,     0,     0,
     196,   197,   198,   199,     0,     0,     0,     0,     0,     0,
       0,   215,     0,    13,    14,    16,    76,    10,     0,    11,
      15,    12,     7,     0,   213,     0,   155,     0,   225,     0,
     222,   223,     0,   194,    41,     0,     0,    26,     0,   167,
     163,     0,    24,    25,     0,    98,     0,    70,     0,     0,
       0,   221,   203,   195,   200,     0,     0,     0,   102,   110,
     105,   104,   103,     0,     0,     0,   139,   140,   141,   142,
     143,   150,   151,   149,   148,   152,    96,    97,     0,   144,
     145,   146,   147,     0,     0,   111,    98,   107,   108,     0,
       0,     0,     0,     0,     0,    78,    79,    81,    83,    84,
       0,     0,    98,   224,    77,   193,     0,   212,     0,    49,
     212,     0,     0,     0,     0,   166,     0,   234,   236,   266,
     253,   268,   237,   239,   238,   250,   267,   252,   263,   258,
     264,   275,   274,   270,   247,   265,   269,   271,   272,   260,
     261,   259,   249,   273,   280,   251,   248,   276,   277,   278,
     279,   235,   262,   240,   242,   246,   243,   244,   245,   241,
     254,   256,   257,   255,   216,   110,     0,     0,    99,   100,
      18,     0,   165,   164,   212,   171,     0,     0,     0,   156,
       0,   216,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   119,    86,     0,     0,   120,   121,    75,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    98,     0,     0,     0,    43,     0,    45,     0,    42,
      68,     0,   188,   189,     0,    17,   212,    29,    21,    20,
      23,    31,   212,    19,     0,   169,     0,   184,   227,   227,
       0,   227,     0,   220,     0,    87,     0,   221,   177,   176,
       0,     0,   201,     0,   204,   160,   158,     0,     0,     0,
     109,     0,     0,   106,     0,    98,    98,   112,    98,    85,
     114,    80,    82,   122,   123,    92,   124,   125,   127,   126,
      88,    89,    90,    91,    93,   131,   132,   133,   134,   135,
     136,   128,   129,   130,     0,     0,     0,     0,    44,   212,
       0,    59,    60,    61,    55,    56,    57,    58,    50,    51,
      52,    53,    54,     0,    39,     0,   212,    17,   191,   221,
      27,     0,     0,   212,     0,     0,     0,   168,     0,     0,
     284,   282,   283,   281,   324,   323,   298,   314,   315,   316,
     321,   325,   319,   322,   327,   318,   313,   317,   320,   326,
     285,   286,   306,   312,   290,   307,   302,   294,   289,   288,
     292,   308,   291,   293,   310,   309,   287,   305,   311,   300,
     296,   299,   295,   303,   301,   304,   297,   219,   227,   227,
       0,   214,   101,     0,   173,   172,   174,     0,   162,   181,
     182,   183,   180,   179,   175,     0,   202,     0,   159,     0,
     157,   226,     0,     0,     0,     0,     0,     0,   117,     0,
       0,   154,   138,     0,    46,     0,    64,     0,    66,    69,
       0,   190,     0,   212,    28,    30,     0,     0,    22,     0,
       0,    37,   170,   233,   230,   229,   228,   231,   218,   217,
     232,     0,   178,   207,   208,   209,   210,   211,   205,     0,
     161,     0,     0,     0,   116,     0,   113,     0,     0,    49,
      47,    62,     0,     0,   185,   192,    33,     0,    32,     0,
      35,     0,    73,     0,    94,    95,   115,     0,   118,   153,
      40,     0,    65,     0,    67,   186,    34,    38,    36,    74,
     206,     0,    48,    63,   137
  };

  const short
  parser::yypgoto_[] =
  {
    -394,  -394,  -394,   -40,   126,  -394,  -394,    59,   -39,   136,
     -82,  -394,   140,  -394,  -394,  -250,    92,   -67,  -394,   -70,
    -394,  -394,   250,   254,  -394,  -394,  -393,   320,   211,  -100,
      -8,  -394,   -98,    -9,   -48,  -394,  -394,   -72,   -52,  -394,
     199,  -394,   214,  -394,   -29,  -394,  -394,  -394,   228,  -394,
    -394,  -394,   163,  -394,   231,  -394,  -394,  -394,  -394,     7,
       2,   396,   311,   -69,  -394,   489,  -262,  -159,   -59,   325
  };

  const short
  parser::yydefgoto_[] =
  {
       0,     1,     2,    32,    33,   258,   259,   260,   261,    34,
     460,   461,    35,    55,   129,   246,   247,   250,   492,   448,
     449,   344,     4,     5,     6,     7,   114,   115,   116,   117,
     118,   119,   187,   188,   189,   121,   122,   442,    10,    46,
     199,   287,    37,    38,    60,   135,   266,   194,    39,    40,
     251,   252,   253,    41,    42,    43,    73,    74,   283,   478,
     248,    44,   272,    49,    50,    51,   358,   464,   465,   466
  };

  const short
  parser::yytable_[] =
  {
      36,   120,   195,    72,     8,   184,   351,   359,   209,   410,
     212,    16,    16,   446,    52,   281,    47,   285,   201,    11,
     471,   255,   330,   347,   243,   273,   457,   329,    13,    14,
      15,   356,    16,     3,   473,   474,   475,    17,   516,    66,
     192,   193,   273,   454,   124,   357,   207,   488,   511,    45,
     515,   329,   414,   415,   416,   127,    16,   128,    12,    48,
     191,   211,   120,   214,   215,   216,   476,   477,   210,    18,
      19,    20,    21,    30,    22,    23,    -2,    24,    25,    26,
      27,    28,    29,    30,    30,    30,   447,   256,    30,   282,
     286,   257,   263,    18,    30,    20,    21,   440,    22,    23,
     417,    24,    25,    26,    27,    28,    29,   267,   208,    66,
     268,   407,   196,   131,   197,    65,    31,   269,    30,   302,
     132,    66,   220,   221,   270,     9,    31,    31,    31,   271,
      67,    31,   254,   223,   224,   225,   226,    31,   274,   220,
     221,    68,   418,   324,   506,    53,   468,   469,   -17,    66,
     223,   224,   225,   226,   -17,   291,   292,   284,   294,    69,
      70,    31,    54,   232,   233,   234,   235,   236,   237,    71,
     120,   120,   303,   304,   305,   306,   307,   308,   309,   310,
     311,   312,   313,   314,   315,   316,   317,   318,   319,   320,
     321,   322,   323,   298,   325,    56,   280,   435,   436,    66,
     437,   299,    57,   497,    58,   218,   328,   329,   413,   426,
     427,   408,   428,   429,   348,    59,    78,    79,    80,    81,
      82,    83,   223,   224,   225,   226,   508,   276,   412,   512,
     513,    61,    62,    63,    64,    84,    85,    16,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
      75,    98,   331,   332,   333,   334,   335,   336,   337,   338,
     339,   340,   341,   342,   354,    76,    77,   125,    99,   100,
     101,   102,    36,   126,   130,   133,   134,   136,   103,   104,
     453,   105,   190,   106,    66,   107,   108,   198,   109,   110,
     111,   331,   332,   333,   334,   335,   336,   337,   338,   339,
     340,   341,   342,   200,   217,   218,    78,   185,    80,    81,
      82,    83,   455,   202,   203,   204,   205,   112,   441,   219,
     343,   113,   206,   241,   244,   245,   249,  -187,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,   265,   275,
     277,    98,   276,   264,   290,   288,   293,   295,   254,   296,
     327,   297,   326,   345,   225,   456,   346,   350,    99,   100,
     101,   102,   352,   349,   353,   120,   425,   411,   103,   104,
     431,   105,   355,   106,   443,   107,   108,   445,   109,   438,
     186,   459,   450,   462,   481,   482,   452,   472,   479,   484,
     480,   491,   120,   485,   483,   486,   489,   496,   493,   500,
     501,   499,   509,   502,   523,   490,   419,   112,   503,   522,
     494,   113,   495,   458,   220,   221,   420,   498,   300,   518,
     421,   444,   510,   514,   222,   223,   224,   225,   226,   301,
     487,   213,   227,   228,   229,   230,   231,   507,   232,   233,
     234,   235,   236,   237,   278,   238,   239,   240,   279,   524,
     519,   517,   360,   137,   361,   362,   363,   138,   364,   139,
     140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,   365,   430,   166,   366,
     367,   368,   369,   370,   422,   371,   372,   373,   374,   375,
     376,   377,   378,   379,   167,   168,   169,   170,   423,   451,
     520,   424,   289,   441,   171,   380,   381,   172,   382,   268,
     463,   383,   384,   385,   386,   387,   269,   262,   388,   389,
     390,   391,   392,   393,   394,   395,   396,   397,   271,   123,
     398,   399,   400,   401,   402,   403,   404,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   405,   406,
     360,   137,   361,   362,   363,   138,   364,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,   365,   409,   166,   366,   367,   368,
     369,   370,     0,   371,   372,   373,   374,   375,   376,   377,
     378,   379,   167,   168,   169,   170,     0,     0,     0,     0,
       0,     0,   171,   380,   381,   172,   382,   268,     0,   383,
     384,   385,   386,   387,   269,   467,   388,   389,   390,   391,
     392,   393,   394,   395,   396,   397,   271,     0,   398,   399,
     400,   401,   402,   403,   404,   173,   174,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   405,   406,   360,   137,
     361,   362,   363,   138,   364,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,   365,     0,   166,   366,   367,   368,   369,   370,
       0,   371,   372,   373,   374,   375,   376,   377,   378,   379,
     167,   168,   169,   170,     0,     0,     0,     0,     0,     0,
     171,   380,   381,   172,   382,   268,     0,   383,   384,   385,
     386,   387,   269,     0,   388,   389,   390,   391,   392,   393,
     394,   395,   396,   397,   271,   470,   398,   399,   400,   401,
     402,   403,   404,   173,   174,   175,   176,   177,   178,   179,
     180,   181,   182,   183,   405,   406,   360,   137,   361,   362,
     363,   138,   364,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     365,     0,   166,   366,   367,   368,   369,   370,     0,   371,
     372,   373,   374,   375,   376,   377,   378,   379,   167,   168,
     169,   170,     0,     0,     0,     0,     0,     0,   171,   380,
     381,   172,   382,   268,     0,   383,   384,   385,   386,   387,
     269,     0,   388,   389,   390,   391,   392,   393,   394,   395,
     396,   397,   271,     0,   398,   399,   400,   401,   402,   403,
     404,   173,   174,   175,   176,   177,   178,   179,   180,   181,
     182,   183,   405,   406,    78,   185,    80,    81,    82,    83,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,   220,   221,     0,    98,
       0,     0,     0,     0,     0,     0,     0,   223,   224,   225,
     226,     0,     0,     0,     0,     0,    99,   100,   101,   102,
     232,     0,   234,   235,   236,   237,   103,   104,     0,   105,
       0,   106,     0,   107,   108,     0,   109,     0,   242,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   137,   112,     0,     0,   138,   113,
     139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
     149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,     0,     0,   166,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   167,   168,   169,   170,   220,
     221,     0,     0,     0,     0,   171,     0,     0,   172,   222,
     223,   224,   225,   226,     0,     0,     0,   227,   228,   229,
     230,   231,     0,   232,   233,   234,   235,   236,   237,     0,
     238,   239,   240,     0,     0,     0,     0,     0,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   220,
     221,     0,     0,   300,   439,     0,     0,     0,     0,     0,
     223,   224,   225,   226,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   232,   233,   234,   235,   236,   237,     0,
     238,   239,   240,   220,   221,     0,     0,   300,     0,     0,
       0,     0,   220,   221,   223,   224,   225,   226,     0,     0,
       0,     0,     0,   223,   224,   225,   226,   232,   233,   234,
     235,   236,   237,     0,   238,   239,   240,   220,   221,   235,
     236,   237,   432,     0,     0,     0,     0,     0,   223,   224,
     225,   226,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   232,   233,   234,   235,   236,   237,     0,   238,   239,
     240,   220,   221,     0,     0,     0,   433,     0,     0,     0,
       0,     0,   223,   224,   225,   226,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   232,   233,   234,   235,   236,
     237,     0,   238,   239,   240,   220,   221,     0,     0,     0,
     434,     0,     0,     0,     0,     0,   223,   224,   225,   226,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   232,
     233,   234,   235,   236,   237,     0,   238,   239,   240,   220,
     221,     0,     0,   504,     0,     0,     0,     0,     0,     0,
     223,   224,   225,   226,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   232,   233,   234,   235,   236,   237,     0,
     238,   239,   240,   220,   221,     0,     0,   505,     0,     0,
       0,     0,     0,     0,   223,   224,   225,   226,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   232,   233,   234,
     235,   236,   237,     0,   238,   239,   240,   220,   221,     0,
       0,     0,   521,     0,     0,     0,     0,     0,   223,   224,
     225,   226,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   232,   233,   234,   235,   236,   237,     0,   238,   239,
     240,   220,   221,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   223,   224,   225,   226,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   232,   233,   234,   235,   236,
     237,     0,   238,   239,   240,   220,   221,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   223,   224,   225,   226,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   232,
     233,   234,   235,   236,   237,     0,   238,     0,   240,   220,
     221,     0,     0,     0,     0,   220,   221,     0,     0,     0,
     223,   224,   225,   226,     0,     0,   223,   224,   225,   226,
       0,     0,     0,   232,   233,   234,   235,   236,   237,   232,
     238,     0,   235,   236,   237
  };

  const short
  parser::yycheck_[] =
  {
       8,    49,    71,    43,     2,    64,   256,   269,   106,   271,
     110,     7,     7,     7,    12,     7,    70,     8,    77,    43,
     413,     7,     7,     7,   122,   184,     7,    82,     3,     4,
       5,    82,     7,     0,     6,     7,     8,    12,    93,    86,
      69,    70,   201,    74,    52,    96,     7,   440,    95,     8,
      27,    82,     3,     4,     5,    80,     7,    82,    82,   113,
      68,   109,   110,   111,   112,   113,    38,    39,   108,    44,
      45,    46,    47,    69,    49,    50,     0,    52,    53,    54,
      55,    56,    57,    69,    69,    69,    80,    73,    69,    81,
      81,   131,   132,    44,    69,    46,    47,    92,    49,    50,
      51,    52,    53,    54,    55,    56,    57,   136,    69,    86,
      73,   270,    80,    87,    82,    80,   112,    80,    69,   219,
      94,    86,    77,    78,    87,    40,   112,   112,   112,    92,
      86,   112,   130,    88,    89,    90,    91,   112,   186,    77,
      78,    97,    93,   241,    81,     6,   408,   409,    80,    86,
      88,    89,    90,    91,    86,   203,   204,   197,   206,    82,
      83,   112,     7,   101,   102,   103,   104,   105,   106,    92,
     218,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   237,
     238,   239,   240,    80,   242,     7,   194,   295,   296,    86,
     298,    81,     7,   453,     7,    85,    81,    82,   277,    81,
      82,   270,    81,    82,   254,     7,     6,     7,     8,     9,
      10,    11,    88,    89,    90,    91,    81,    82,   276,    81,
      82,     7,     7,     7,    73,    25,    26,     7,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      83,    41,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,   262,    82,    73,     6,    58,    59,
      60,    61,   280,    87,    80,    95,    95,    87,    68,    69,
     349,    71,     7,    73,    86,    75,    76,    80,    78,    79,
      80,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,     8,    86,    85,     6,     7,     8,     9,
      10,    11,   352,    80,    80,    80,    80,   107,   326,    82,
      42,   111,    80,    80,    48,    81,     7,    81,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,     7,    81,
      43,    41,    82,    96,    81,    83,    81,    80,   346,     7,
      80,    74,    83,    81,    90,   353,    82,    74,    58,    59,
      60,    61,    72,    92,    72,   413,    87,    74,    68,    69,
      74,    71,    92,    73,     7,    75,    76,    83,    78,    81,
      80,     7,    83,     7,   432,   433,    83,     7,     7,    81,
       8,     7,   440,    83,   434,    81,    81,    93,    82,    93,
      82,   100,    93,    86,     7,   445,   280,   107,    87,    96,
     450,   111,   452,   354,    77,    78,   280,   456,    81,   501,
     280,   329,   489,   493,    87,    88,    89,    90,    91,   218,
     439,   111,    95,    96,    97,    98,    99,   485,   101,   102,
     103,   104,   105,   106,   194,   108,   109,   110,   194,   521,
     502,   499,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,   288,    42,    43,
      44,    45,    46,    47,   280,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,   280,   346,
     503,   280,   201,   521,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,   131,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    50,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,   270,    42,    43,    44,    45,
      46,    47,    -1,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    68,    69,    70,    71,    72,    73,    -1,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    -1,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    47,
      -1,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    -1,    -1,    -1,    -1,    -1,    -1,
      68,    69,    70,    71,    72,    73,    -1,    75,    76,    77,
      78,    79,    80,    -1,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    47,    -1,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,
      70,    71,    72,    73,    -1,    75,    76,    77,    78,    79,
      80,    -1,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    -1,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   112,   113,     6,     7,     8,     9,    10,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    77,    78,    -1,    41,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    88,    89,    90,
      91,    -1,    -1,    -1,    -1,    -1,    58,    59,    60,    61,
     101,    -1,   103,   104,   105,   106,    68,    69,    -1,    71,
      -1,    73,    -1,    75,    76,    -1,    78,    -1,    80,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     7,   107,    -1,    -1,    11,   111,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    -1,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    58,    59,    60,    61,    77,
      78,    -1,    -1,    -1,    -1,    68,    -1,    -1,    71,    87,
      88,    89,    90,    91,    -1,    -1,    -1,    95,    96,    97,
      98,    99,    -1,   101,   102,   103,   104,   105,   106,    -1,
     108,   109,   110,    -1,    -1,    -1,    -1,    -1,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,    77,
      78,    -1,    -1,    81,    82,    -1,    -1,    -1,    -1,    -1,
      88,    89,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   101,   102,   103,   104,   105,   106,    -1,
     108,   109,   110,    77,    78,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    77,    78,    88,    89,    90,    91,    -1,    -1,
      -1,    -1,    -1,    88,    89,    90,    91,   101,   102,   103,
     104,   105,   106,    -1,   108,   109,   110,    77,    78,   104,
     105,   106,    82,    -1,    -1,    -1,    -1,    -1,    88,    89,
      90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   101,   102,   103,   104,   105,   106,    -1,   108,   109,
     110,    77,    78,    -1,    -1,    -1,    82,    -1,    -1,    -1,
      -1,    -1,    88,    89,    90,    91,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   101,   102,   103,   104,   105,
     106,    -1,   108,   109,   110,    77,    78,    -1,    -1,    -1,
      82,    -1,    -1,    -1,    -1,    -1,    88,    89,    90,    91,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   101,
     102,   103,   104,   105,   106,    -1,   108,   109,   110,    77,
      78,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      88,    89,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   101,   102,   103,   104,   105,   106,    -1,
     108,   109,   110,    77,    78,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    -1,    -1,    88,    89,    90,    91,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   101,   102,   103,
     104,   105,   106,    -1,   108,   109,   110,    77,    78,    -1,
      -1,    -1,    82,    -1,    -1,    -1,    -1,    -1,    88,    89,
      90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   101,   102,   103,   104,   105,   106,    -1,   108,   109,
     110,    77,    78,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    88,    89,    90,    91,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   101,   102,   103,   104,   105,
     106,    -1,   108,   109,   110,    77,    78,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    88,    89,    90,    91,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   101,
     102,   103,   104,   105,   106,    -1,   108,    -1,   110,    77,
      78,    -1,    -1,    -1,    -1,    77,    78,    -1,    -1,    -1,
      88,    89,    90,    91,    -1,    -1,    88,    89,    90,    91,
      -1,    -1,    -1,   101,   102,   103,   104,   105,   106,   101,
     108,    -1,   104,   105,   106
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,   116,   117,     0,   137,   138,   139,   140,   175,    40,
     153,    43,    82,     3,     4,     5,     7,    12,    44,    45,
      46,    47,    49,    50,    52,    53,    54,    55,    56,    57,
      69,   112,   118,   119,   124,   127,   145,   157,   158,   163,
     164,   168,   169,   170,   176,     8,   154,    70,   113,   178,
     179,   180,   175,     6,     7,   128,     7,     7,     7,     7,
     159,     7,     7,     7,    73,    80,    86,    86,    97,    82,
      83,    92,   118,   171,   172,    83,    82,    73,     6,     7,
       8,     9,    10,    11,    25,    26,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    41,    58,
      59,    60,    61,    68,    69,    71,    73,    75,    76,    78,
      79,    80,   107,   111,   141,   142,   143,   144,   145,   146,
     149,   150,   151,   180,   145,     6,    87,    80,    82,   129,
      80,    87,    94,    95,    95,   160,    87,     7,    11,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    42,    58,    59,    60,
      61,    68,    71,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   183,     7,    80,   147,   148,   149,
       7,   145,   159,   159,   162,   178,    80,    82,    80,   155,
       8,   183,    80,    80,    80,    80,    80,     7,    69,   147,
     118,   149,   144,   142,   149,   149,   149,    86,    85,    82,
      77,    78,    87,    88,    89,    90,    91,    95,    96,    97,
      98,    99,   101,   102,   103,   104,   105,   106,   108,   109,
     110,    80,    80,   147,    48,    81,   130,   131,   175,     7,
     132,   165,   166,   167,   175,     7,    73,   118,   120,   121,
     122,   123,   176,   118,    96,     7,   161,   159,    73,    80,
      87,    92,   177,   182,   149,    81,    82,    43,   137,   138,
     175,     7,    81,   173,   118,     8,    81,   156,    83,   177,
      81,   149,   149,    81,   149,    80,     7,    74,    80,    81,
      81,   143,   144,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   147,   149,    83,    80,    81,    82,
       7,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    42,   136,    81,    82,     7,   118,    92,
      74,   130,    72,    72,   175,    92,    82,    96,   181,   181,
       6,     8,     9,    10,    12,    40,    43,    44,    45,    46,
      47,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      69,    70,    72,    75,    76,    77,    78,    79,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    94,    95,
      96,    97,    98,    99,   100,   112,   113,   182,   183,   184,
     181,    74,   149,   178,     3,     4,     5,    51,    93,   119,
     124,   127,   157,   163,   169,    87,    81,    82,    81,    82,
     155,    74,    82,    82,    82,   147,   147,   147,    81,    82,
      92,   145,   152,     7,   131,    83,     7,    80,   134,   135,
      83,   167,    83,   178,    74,   118,   175,     7,   122,     7,
     125,   126,     7,    74,   182,   183,   184,    81,   181,   181,
      93,   141,     7,     6,     7,     8,    38,    39,   174,     7,
       8,   149,   149,   118,    81,    83,    81,   148,   141,    81,
     118,     7,   133,    82,   118,   118,    93,   130,   123,   100,
      93,    82,    86,    87,    81,    81,    81,   149,    81,    93,
     132,    95,    81,    82,   134,    27,    93,   149,   125,   153,
     174,    82,    96,     7,   152
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,   115,   116,   117,   117,   117,   117,   117,   117,   117,
     117,   117,   117,   117,   117,   117,   117,   118,   118,   119,
     119,   119,   119,   119,   119,   119,   119,   120,   120,   121,
     121,   122,   122,   123,   123,   124,   125,   125,   126,   127,
     127,   128,   128,   129,   129,   130,   130,   131,   131,   132,
     132,   132,   132,   132,   132,   132,   132,   132,   132,   132,
     132,   132,   133,   133,   134,   134,   135,   135,   136,   136,
     137,   138,   138,   138,   138,   139,   140,   140,   141,   142,
     142,   143,   143,   144,   144,   144,   144,   145,   146,   146,
     146,   146,   146,   146,   146,   146,   146,   146,   147,   147,
     148,   148,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   150,
     150,   150,   150,   150,   150,   150,   150,   150,   151,   151,
     151,   151,   151,   152,   152,   153,   154,   154,   155,   155,
     156,   156,   157,   158,   158,   158,   159,   160,   160,   161,
     161,   162,   162,   162,   162,   162,   162,   162,   162,   162,
     162,   162,   162,   162,   163,   164,   164,   165,   165,   166,
     166,   167,   167,   168,   168,   169,   170,   170,   170,   170,
     171,   171,   171,   172,   172,   173,   173,   174,   174,   174,
     174,   174,   175,   175,   176,   176,   177,   177,   177,   177,
     177,   178,   178,   179,   179,   180,   180,   181,   181,   181,
     181,   182,   182,   182,   183,   183,   183,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   183,   183,
     183,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     3,     3,     3,     3,     2,     2,
       3,     3,     3,     3,     3,     3,     3,     1,     3,     4,
       4,     4,     6,     4,     2,     2,     2,     2,     3,     1,
       3,     1,     4,     4,     5,     7,     3,     1,     3,     5,
       8,     1,     3,     2,     3,     1,     3,     4,     6,     0,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     1,     3,     1,     3,     1,     3,     0,     2,
       3,     1,     2,     8,     9,     5,     2,     4,     1,     1,
       3,     1,     3,     1,     1,     3,     2,     4,     3,     3,
       3,     3,     3,     3,     6,     6,     1,     1,     0,     1,
       1,     3,     1,     1,     1,     1,     3,     1,     1,     3,
       1,     1,     3,     5,     3,     6,     5,     4,     6,     2,
       2,     2,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     8,     4,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     1,     2,     3,     5,     2,     3,
       1,     3,     5,     2,     3,     3,     2,     0,     3,     1,
       3,     1,     3,     3,     3,     3,     2,     2,     4,     3,
       3,     3,     3,     3,     4,     7,     8,     0,     1,     1,
       3,     2,     4,     3,     2,     2,     1,     1,     1,     1,
       1,     3,     4,     1,     3,     3,     5,     1,     1,     1,
       1,     1,     0,     2,     5,     1,     0,     3,     3,     2,
       1,     0,     1,     1,     2,     1,     5,     0,     2,     2,
       2,     3,     3,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1
  };


#if YYDEBUG || 1
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a YYNTOKENS, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"end of input\"", "error", "\"invalid token\"",
  "\"end of included file\"", "\"start of included file\"",
  "\"end of file\"", "\"symbol\"", "\"identifier\"", "\"number\"",
  "\"unsigned number\"", "\"float\"", "\"auto-increment functor\"",
  "\"pragma directive\"", "\"relation qualifier output\"",
  "\"relation qualifier input\"", "\"relation qualifier printsize\"",
  "\"BRIE datastructure qualifier\"", "\"BTREE datastructure qualifier\"",
  "\"BTREE_DELETE datastructure qualifier\"",
  "\"equivalence relation qualifier\"",
  "\"relation qualifier overidable\"", "\"relation qualifier inline\"",
  "\"relation qualifier no_inline\"", "\"relation qualifier magic\"",
  "\"relation qualifier no_magic\"", "\"match predicate\"",
  "\"checks whether substring is contained in a string\"",
  "\"stateful functor\"", "\"concatenation of strings\"",
  "\"ordinal number of a string\"", "\"range\"", "\"length of a string\"",
  "\"sub-string of a string\"", "\"mean aggregator\"",
  "\"min aggregator\"", "\"max aggregator\"", "\"count aggregator\"",
  "\"sum aggregator\"", "\"true literal constraint\"",
  "\"false literal constraint\"", "\"plan keyword\"",
  "\"recursive iteration keyword\"", "\"choice-domain\"", "\":-\"",
  "\"relation declaration\"", "\"functor declaration\"",
  "\"input directives declaration\"", "\"output directives declaration\"",
  "\"debug_delta\"", "\"printsize directives declaration\"",
  "\"limitsize directives declaration\"",
  "\"override rules of super-component\"", "\"type declaration\"",
  "\"lattice declaration\"", "\"component declaration\"",
  "\"component instantiation\"", "\"numeric type declaration\"",
  "\"symbolic type declaration\"", "\"convert to float\"",
  "\"convert to signed integer\"", "\"convert to string\"",
  "\"convert to unsigned integer\"", "\"convert int to unsigned\"",
  "\"convert int to float\"", "\"convert unsigned to int\"",
  "\"convert unsigned to float\"", "\"convert float to int\"",
  "\"convert float to unsigned\"", "\"type cast\"", "\"@\"", "\"@!\"",
  "\"nil reference\"", "\"|\"", "\"[\"", "\"]\"", "\"_\"", "\"$\"",
  "\"+\"", "\"-\"", "\"!\"", "\"(\"", "\")\"", "\",\"", "\":\"", "\"::\"",
  "\";\"", "\".\"", "\"=\"", "\"*\"", "\"/\"", "\"^\"", "\"%\"", "\"{\"",
  "\"}\"", "\"<:\"", "\"<\"", "\">\"", "\"<=\"", "\">=\"", "\"!=\"",
  "\"->\"", "\"band\"", "\"bor\"", "\"bxor\"", "\"bshl\"", "\"bshr\"",
  "\"bshru\"", "\"bnot\"", "\"land\"", "\"lor\"", "\"lxor\"", "\"lnot\"",
  "\"outer doc comment\"", "\"inner doc comment\"", "NEG", "$accept",
  "program", "unit", "qualified_name", "type_decl", "record_type_list",
  "union_type_list", "adt_branch_list", "adt_branch", "lattice_decl",
  "lattice_operator_list", "lattice_operator", "relation_decl",
  "relation_names", "attributes_list", "non_empty_attributes", "attribute",
  "relation_tags", "non_empty_attribute_names", "dependency",
  "dependency_list_aux", "dependency_list", "fact", "rule", "rule_def",
  "head", "body", "disjunction", "conjunction", "term", "atom",
  "constraint", "arg_list", "non_empty_arg_list", "arg",
  "functor_built_in", "aggregate_func", "aggregate_body", "query_plan",
  "query_plan_list", "plan_order", "non_empty_plan_order_list",
  "component_decl", "component_head", "component_type",
  "component_type_params", "component_param_list", "component_body",
  "component_init", "functor_decl", "functor_arg_type_list",
  "non_empty_functor_arg_type_list", "functor_attribute", "pragma",
  "directive_head", "directive_head_decl", "directive_list",
  "relation_directive_list", "non_empty_key_value_pairs", "kvp_value",
  "annotations", "annotation", "annotation_input", "inner_annotations",
  "non_empty_inner_annotations", "inner_annotation", "token_stream",
  "delim", "ident_token", "token", YY_NULLPTR
  };
#endif


#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   332,   332,   339,   341,   349,   357,   364,   372,   378,
     383,   389,   395,   401,   407,   413,   419,   439,   443,   453,
     457,   467,   471,   480,   485,   489,   493,   502,   504,   512,
     516,   524,   528,   538,   543,   555,   561,   566,   572,   589,
     610,   633,   637,   648,   651,   658,   662,   670,   676,   688,
     690,   694,   698,   702,   706,   710,   714,   718,   722,   727,
     731,   735,   745,   750,   761,   765,   776,   780,   788,   790,
     804,   816,   820,   828,   849,   877,   900,   907,   920,   927,
     931,   939,   943,   954,   958,   962,   966,   976,   987,   991,
     995,   999,  1003,  1007,  1013,  1017,  1023,  1027,  1037,  1040,
    1046,  1050,  1061,  1065,  1069,  1074,  1078,  1082,  1086,  1090,
    1094,  1098,  1102,  1106,  1110,  1114,  1118,  1122,  1128,  1153,
    1164,  1168,  1174,  1178,  1182,  1186,  1190,  1194,  1198,  1202,
    1206,  1210,  1214,  1218,  1222,  1226,  1230,  1235,  1247,  1268,
    1272,  1276,  1280,  1284,  1288,  1292,  1296,  1300,  1307,  1311,
    1315,  1319,  1323,  1330,  1334,  1344,  1350,  1355,  1363,  1367,
    1374,  1378,  1392,  1410,  1415,  1420,  1431,  1440,  1442,  1452,
    1456,  1467,  1472,  1480,  1488,  1498,  1507,  1514,  1519,  1524,
    1531,  1538,  1545,  1552,  1572,  1586,  1590,  1600,  1601,  1608,
    1612,  1619,  1624,  1639,  1643,  1653,  1664,  1668,  1672,  1676,
    1686,  1690,  1694,  1709,  1713,  1724,  1728,  1736,  1740,  1744,
    1748,  1752,  1763,  1766,  1778,  1784,  1794,  1797,  1803,  1809,
    1814,  1821,  1824,  1831,  1835,  1843,  1850,  1880,  1881,  1886,
    1891,  1899,  1903,  1907,  1915,  1916,  1917,  1918,  1919,  1920,
    1921,  1922,  1923,  1924,  1925,  1926,  1927,  1928,  1929,  1930,
    1931,  1932,  1933,  1934,  1935,  1936,  1937,  1938,  1939,  1940,
    1941,  1942,  1943,  1944,  1945,  1946,  1947,  1948,  1949,  1950,
    1951,  1952,  1953,  1954,  1955,  1956,  1957,  1958,  1959,  1960,
    1961,  1965,  1966,  1967,  1968,  1970,  1971,  1972,  1973,  1974,
    1975,  1976,  1977,  1978,  1979,  1980,  1981,  1982,  1983,  1984,
    1985,  1986,  1987,  1988,  1989,  1990,  1991,  1992,  1993,  1994,
    1995,  1996,  1997,  1999,  2000,  2001,  2002,  2003,  2004,  2005,
    2006,  2007,  2008,  2009,  2010,  2011,  2012,  2013
  };

  void
  parser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  parser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


} // yy
#line 5304 "/home/lun/workspace/souffle/build/src/parser/parser.cc"

#line 2017 "/home/lun/workspace/souffle/src/parser/parser.yy"


void yy::parser::error(const location_type &l, const std::string &m)
{
  driver.error(l, m);
}

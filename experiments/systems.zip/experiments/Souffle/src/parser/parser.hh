// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton interface for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.


/**
 ** \file /home/lun/workspace/souffle/build/src/parser/parser.hh
 ** Define the yy::parser class.
 */

// C++ LALR(1) parser skeleton written by Akim Demaille.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.

#ifndef YY_YY_HOME_LUN_WORKSPACE_SOUFFLE_BUILD_SRC_PARSER_PARSER_HH_INCLUDED
# define YY_YY_HOME_LUN_WORKSPACE_SOUFFLE_BUILD_SRC_PARSER_PARSER_HH_INCLUDED
// "%code requires" blocks.
#line 32 "/home/lun/workspace/souffle/src/parser/parser.yy"

    #include "AggregateOp.h"
    #include "FunctorOps.h"
    #include "ast/Annotation.h"
    #include "ast/IntrinsicAggregator.h"
    #include "ast/UserDefinedAggregator.h"
    #include "ast/AliasType.h"
    #include "ast/AlgebraicDataType.h"
    #include "ast/Argument.h"
    #include "ast/Atom.h"
    #include "ast/Attribute.h"
    #include "ast/BinaryConstraint.h"
    #include "ast/BooleanConstraint.h"
    #include "ast/BranchType.h"
    #include "ast/BranchInit.h"
    #include "ast/Clause.h"
    #include "ast/Component.h"
    #include "ast/ComponentInit.h"
    #include "ast/ComponentType.h"
    #include "ast/Constraint.h"
    #include "ast/Counter.h"
    #include "ast/Directive.h"
    #include "ast/ExecutionOrder.h"
    #include "ast/ExecutionPlan.h"
    #include "ast/FunctionalConstraint.h"
    #include "ast/FunctorDeclaration.h"
    #include "ast/IntrinsicFunctor.h"
    #include "ast/IterationCounter.h"
    #include "ast/Lattice.h"
    #include "ast/Literal.h"
    #include "ast/NilConstant.h"
    #include "ast/NumericConstant.h"
    #include "ast/Pragma.h"
    #include "ast/QualifiedName.h"
    #include "ast/RecordInit.h"
    #include "ast/RecordType.h"
    #include "ast/Relation.h"
    #include "ast/StringConstant.h"
    #include "ast/SubsetType.h"
    #include "ast/SubsumptiveClause.h"
    #include "ast/TokenTree.h"
    #include "ast/Type.h"
    #include "ast/TypeCast.h"
    #include "ast/UnionType.h"
    #include "ast/UnnamedVariable.h"
    #include "ast/UserDefinedFunctor.h"
    #include "ast/Variable.h"
    #include "parser/ParserUtils.h"
    #include "souffle/RamTypes.h"
    #include "souffle/BinaryConstraintOps.h"
    #include "souffle/utility/ContainerUtil.h"
    #include "souffle/utility/StringUtil.h"

    #include <ostream>
    #include <string>
    #include <vector>
    #include <list>
    #include <map>

    using namespace souffle;

    namespace souffle {
        class ParserDriver;
        namespace parser {
        }
    }

    using yyscan_t = void*;


    #define YY_NULLPTR nullptr

    /* Macro to update locations as parsing proceeds */
#define YYLLOC_DEFAULT(Cur, Rhs, N)               \
    do {                                          \
        if (N) {                                  \
            (Cur).start = YYRHSLOC(Rhs, 1).start; \
            (Cur).end = YYRHSLOC(Rhs, N).end;     \
            (Cur).file = YYRHSLOC(Rhs, N).file;   \
        } else {                                  \
            (Cur).start = YYRHSLOC(Rhs, 0).end;   \
            (Cur).end = YYRHSLOC(Rhs, 0).end;     \
            (Cur).file = YYRHSLOC(Rhs, 0).file;   \
        }                                         \
    } while (0)

#line 136 "/home/lun/workspace/souffle/build/src/parser/parser.hh"

# include <cassert>
# include <cstdlib> // std::abort
# include <iostream>
# include <stdexcept>
# include <string>
# include <vector>

#if defined __cplusplus
# define YY_CPLUSPLUS __cplusplus
#else
# define YY_CPLUSPLUS 199711L
#endif

// Support move semantics when possible.
#if 201103L <= YY_CPLUSPLUS
# define YY_MOVE           std::move
# define YY_MOVE_OR_COPY   move
# define YY_MOVE_REF(Type) Type&&
# define YY_RVREF(Type)    Type&&
# define YY_COPY(Type)     Type
#else
# define YY_MOVE
# define YY_MOVE_OR_COPY   copy
# define YY_MOVE_REF(Type) Type&
# define YY_RVREF(Type)    const Type&
# define YY_COPY(Type)     const Type&
#endif

// Support noexcept when possible.
#if 201103L <= YY_CPLUSPLUS
# define YY_NOEXCEPT noexcept
# define YY_NOTHROW
#else
# define YY_NOEXCEPT
# define YY_NOTHROW throw ()
#endif

// Support constexpr when possible.
#if 201703 <= YY_CPLUSPLUS
# define YY_CONSTEXPR constexpr
#else
# define YY_CONSTEXPR
#endif

#include <typeinfo>
#ifndef YY_ASSERT
# include <cassert>
# define YY_ASSERT assert
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

namespace yy {
#line 276 "/home/lun/workspace/souffle/build/src/parser/parser.hh"




  /// A Bison parser.
  class parser
  {
  public:
#ifdef YYSTYPE
# ifdef __GNUC__
#  pragma GCC message "bison: do not #define YYSTYPE in C++, use %define api.value.type"
# endif
    typedef YYSTYPE value_type;
#else
  /// A buffer to store and retrieve objects.
  ///
  /// Sort of a variant, but does not keep track of the nature
  /// of the stored data, since that knowledge is available
  /// via the current parser state.
  class value_type
  {
  public:
    /// Type of *this.
    typedef value_type self_type;

    /// Empty construction.
    value_type () YY_NOEXCEPT
      : yyraw_ ()
      , yytypeid_ (YY_NULLPTR)
    {}

    /// Construct and fill.
    template <typename T>
    value_type (YY_RVREF (T) t)
      : yytypeid_ (&typeid (T))
    {
      YY_ASSERT (sizeof (T) <= size);
      new (yyas_<T> ()) T (YY_MOVE (t));
    }

#if 201103L <= YY_CPLUSPLUS
    /// Non copyable.
    value_type (const self_type&) = delete;
    /// Non copyable.
    self_type& operator= (const self_type&) = delete;
#endif

    /// Destruction, allowed only if empty.
    ~value_type () YY_NOEXCEPT
    {
      YY_ASSERT (!yytypeid_);
    }

# if 201103L <= YY_CPLUSPLUS
    /// Instantiate a \a T in here from \a t.
    template <typename T, typename... U>
    T&
    emplace (U&&... u)
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T (std::forward <U>(u)...);
    }
# else
    /// Instantiate an empty \a T in here.
    template <typename T>
    T&
    emplace ()
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T ();
    }

    /// Instantiate a \a T in here from \a t.
    template <typename T>
    T&
    emplace (const T& t)
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T (t);
    }
# endif

    /// Instantiate an empty \a T in here.
    /// Obsolete, use emplace.
    template <typename T>
    T&
    build ()
    {
      return emplace<T> ();
    }

    /// Instantiate a \a T in here from \a t.
    /// Obsolete, use emplace.
    template <typename T>
    T&
    build (const T& t)
    {
      return emplace<T> (t);
    }

    /// Accessor to a built \a T.
    template <typename T>
    T&
    as () YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == typeid (T));
      YY_ASSERT (sizeof (T) <= size);
      return *yyas_<T> ();
    }

    /// Const accessor to a built \a T (for %printer).
    template <typename T>
    const T&
    as () const YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == typeid (T));
      YY_ASSERT (sizeof (T) <= size);
      return *yyas_<T> ();
    }

    /// Swap the content with \a that, of same type.
    ///
    /// Both variants must be built beforehand, because swapping the actual
    /// data requires reading it (with as()), and this is not possible on
    /// unconstructed variants: it would require some dynamic testing, which
    /// should not be the variant's responsibility.
    /// Swapping between built and (possibly) non-built is done with
    /// self_type::move ().
    template <typename T>
    void
    swap (self_type& that) YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == *that.yytypeid_);
      std::swap (as<T> (), that.as<T> ());
    }

    /// Move the content of \a that to this.
    ///
    /// Destroys \a that.
    template <typename T>
    void
    move (self_type& that)
    {
# if 201103L <= YY_CPLUSPLUS
      emplace<T> (std::move (that.as<T> ()));
# else
      emplace<T> ();
      swap<T> (that);
# endif
      that.destroy<T> ();
    }

# if 201103L <= YY_CPLUSPLUS
    /// Move the content of \a that to this.
    template <typename T>
    void
    move (self_type&& that)
    {
      emplace<T> (std::move (that.as<T> ()));
      that.destroy<T> ();
    }
#endif

    /// Copy the content of \a that to this.
    template <typename T>
    void
    copy (const self_type& that)
    {
      emplace<T> (that.as<T> ());
    }

    /// Destroy the stored \a T.
    template <typename T>
    void
    destroy ()
    {
      as<T> ().~T ();
      yytypeid_ = YY_NULLPTR;
    }

  private:
#if YY_CPLUSPLUS < 201103L
    /// Non copyable.
    value_type (const self_type&);
    /// Non copyable.
    self_type& operator= (const self_type&);
#endif

    /// Accessor to raw memory as \a T.
    template <typename T>
    T*
    yyas_ () YY_NOEXCEPT
    {
      void *yyp = yyraw_;
      return static_cast<T*> (yyp);
     }

    /// Const accessor to raw memory as \a T.
    template <typename T>
    const T*
    yyas_ () const YY_NOEXCEPT
    {
      const void *yyp = yyraw_;
      return static_cast<const T*> (yyp);
     }

    /// An auxiliary type to compute the largest semantic type.
    union union_type
    {
      // aggregate_func
      char dummy1[sizeof (AggregateOp)];

      // arg
      char dummy2[sizeof (Own<ast::Argument>)];

      // atom
      char dummy3[sizeof (Own<ast::Atom>)];

      // attribute
      // functor_attribute
      char dummy4[sizeof (Own<ast::Attribute>)];

      // adt_branch
      char dummy5[sizeof (Own<ast::BranchType>)];

      // fact
      char dummy6[sizeof (Own<ast::Clause>)];

      // component_decl
      // component_head
      // component_body
      char dummy7[sizeof (Own<ast::Component>)];

      // component_init
      char dummy8[sizeof (Own<ast::ComponentInit>)];

      // component_type
      char dummy9[sizeof (Own<ast::ComponentType>)];

      // constraint
      char dummy10[sizeof (Own<ast::Constraint>)];

      // plan_order
      char dummy11[sizeof (Own<ast::ExecutionOrder>)];

      // query_plan
      // query_plan_list
      char dummy12[sizeof (Own<ast::ExecutionPlan>)];

      // dependency
      char dummy13[sizeof (Own<ast::FunctionalConstraint>)];

      // functor_decl
      char dummy14[sizeof (Own<ast::FunctorDeclaration>)];

      // lattice_decl
      char dummy15[sizeof (Own<ast::Lattice>)];

      // pragma
      char dummy16[sizeof (Own<ast::Pragma>)];

      // type_decl
      char dummy17[sizeof (Own<ast::Type>)];

      // body
      // disjunction
      // conjunction
      // term
      // aggregate_body
      char dummy18[sizeof (RuleBody)];

      // arg_list
      // non_empty_arg_list
      char dummy19[sizeof (VecOwn<ast::Argument>)];

      // head
      char dummy20[sizeof (VecOwn<ast::Atom>)];

      // record_type_list
      // attributes_list
      // non_empty_attributes
      // functor_arg_type_list
      // non_empty_functor_arg_type_list
      char dummy21[sizeof (VecOwn<ast::Attribute>)];

      // adt_branch_list
      char dummy22[sizeof (VecOwn<ast::BranchType>)];

      // rule
      // rule_def
      char dummy23[sizeof (VecOwn<ast::Clause>)];

      // directive_head
      // directive_list
      // relation_directive_list
      char dummy24[sizeof (VecOwn<ast::Directive>)];

      // dependency_list_aux
      // dependency_list
      char dummy25[sizeof (VecOwn<ast::FunctionalConstraint>)];

      // relation_decl
      // relation_names
      char dummy26[sizeof (VecOwn<ast::Relation>)];

      // annotation
      // inner_annotation
      char dummy27[sizeof (ast::Annotation)];

      // annotations
      // inner_annotations
      // non_empty_inner_annotations
      char dummy28[sizeof (ast::AnnotationList)];

      // directive_head_decl
      char dummy29[sizeof (ast::DirectiveType)];

      // non_empty_plan_order_list
      char dummy30[sizeof (ast::ExecutionOrder::ExecOrder)];

      // qualified_name
      char dummy31[sizeof (ast::QualifiedName)];

      // annotation_input
      // token_stream
      char dummy32[sizeof (ast::TokenStream)];

      // delim
      // ident_token
      // token
      char dummy33[sizeof (ast::TokenTree)];

      // lattice_operator_list
      char dummy34[sizeof (std::map<ast::LatticeOperator, Own<ast::Argument>>)];

      // lattice_operator
      char dummy35[sizeof (std::pair<ast::LatticeOperator, Own<ast::Argument>>)];

      // relation_tags
      char dummy36[sizeof (std::set<RelationTag>)];

      // "symbol"
      // "identifier"
      // "number"
      // "unsigned number"
      // "float"
      // "outer doc comment"
      // "inner doc comment"
      // functor_built_in
      // kvp_value
      char dummy37[sizeof (std::string)];

      // union_type_list
      // component_type_params
      // component_param_list
      char dummy38[sizeof (std::vector<ast::QualifiedName>)];

      // non_empty_key_value_pairs
      char dummy39[sizeof (std::vector<std::pair<std::string, std::string>>)];

      // non_empty_attribute_names
      char dummy40[sizeof (std::vector<std::string>)];
    };

    /// The size of the largest semantic type.
    enum { size = sizeof (union_type) };

    /// A buffer to store semantic values.
    union
    {
      /// Strongest alignment constraints.
      long double yyalign_me_;
      /// A buffer large enough to store any of the semantic values.
      char yyraw_[size];
    };

    /// Whether the content is built: if defined, the name of the stored type.
    const std::type_info *yytypeid_;
  };

#endif
    /// Backward compatibility (Bison 3.8).
    typedef value_type semantic_type;

    /// Symbol locations.
    typedef SrcLocation location_type;

    /// Syntax errors thrown from user actions.
    struct syntax_error : std::runtime_error
    {
      syntax_error (const location_type& l, const std::string& m)
        : std::runtime_error (m)
        , location (l)
      {}

      syntax_error (const syntax_error& s)
        : std::runtime_error (s.what ())
        , location (s.location)
      {}

      ~syntax_error () YY_NOEXCEPT YY_NOTHROW;

      location_type location;
    };

    /// Token kinds.
    struct token
    {
      enum token_kind_type
      {
        YYEMPTY = -2,
    END = 0,                       // "end of input"
    YYerror = 256,                 // error
    YYUNDEF = 257,                 // "invalid token"
    LEAVE = 258,                   // "end of included file"
    ENTER = 259,                   // "start of included file"
    ENDFILE = 260,                 // "end of file"
    STRING = 261,                  // "symbol"
    IDENT = 262,                   // "identifier"
    NUMBER = 263,                  // "number"
    UNSIGNED = 264,                // "unsigned number"
    FLOAT = 265,                   // "float"
    AUTOINC = 266,                 // "auto-increment functor"
    PRAGMA = 267,                  // "pragma directive"
    OUTPUT_QUALIFIER = 268,        // "relation qualifier output"
    INPUT_QUALIFIER = 269,         // "relation qualifier input"
    PRINTSIZE_QUALIFIER = 270,     // "relation qualifier printsize"
    BRIE_QUALIFIER = 271,          // "BRIE datastructure qualifier"
    BTREE_QUALIFIER = 272,         // "BTREE datastructure qualifier"
    BTREE_DELETE_QUALIFIER = 273,  // "BTREE_DELETE datastructure qualifier"
    EQREL_QUALIFIER = 274,         // "equivalence relation qualifier"
    OVERRIDABLE_QUALIFIER = 275,   // "relation qualifier overidable"
    INLINE_QUALIFIER = 276,        // "relation qualifier inline"
    NO_INLINE_QUALIFIER = 277,     // "relation qualifier no_inline"
    MAGIC_QUALIFIER = 278,         // "relation qualifier magic"
    NO_MAGIC_QUALIFIER = 279,      // "relation qualifier no_magic"
    TMATCH = 280,                  // "match predicate"
    TCONTAINS = 281,               // "checks whether substring is contained in a string"
    STATEFUL = 282,                // "stateful functor"
    CAT = 283,                     // "concatenation of strings"
    ORD = 284,                     // "ordinal number of a string"
    RANGE = 285,                   // "range"
    STRLEN = 286,                  // "length of a string"
    SUBSTR = 287,                  // "sub-string of a string"
    MEAN = 288,                    // "mean aggregator"
    MIN = 289,                     // "min aggregator"
    MAX = 290,                     // "max aggregator"
    COUNT = 291,                   // "count aggregator"
    SUM = 292,                     // "sum aggregator"
    TRUELIT = 293,                 // "true literal constraint"
    FALSELIT = 294,                // "false literal constraint"
    PLAN = 295,                    // "plan keyword"
    ITERATION = 296,               // "recursive iteration keyword"
    CHOICEDOMAIN = 297,            // "choice-domain"
    IF = 298,                      // ":-"
    DECL = 299,                    // "relation declaration"
    FUNCTOR = 300,                 // "functor declaration"
    INPUT_DECL = 301,              // "input directives declaration"
    OUTPUT_DECL = 302,             // "output directives declaration"
    DEBUG_DELTA = 303,             // "debug_delta"
    PRINTSIZE_DECL = 304,          // "printsize directives declaration"
    LIMITSIZE_DECL = 305,          // "limitsize directives declaration"
    OVERRIDE = 306,                // "override rules of super-component"
    TYPE = 307,                    // "type declaration"
    LATTICE = 308,                 // "lattice declaration"
    COMPONENT = 309,               // "component declaration"
    INSTANTIATE = 310,             // "component instantiation"
    NUMBER_TYPE = 311,             // "numeric type declaration"
    SYMBOL_TYPE = 312,             // "symbolic type declaration"
    TOFLOAT = 313,                 // "convert to float"
    TONUMBER = 314,                // "convert to signed integer"
    TOSTRING = 315,                // "convert to string"
    TOUNSIGNED = 316,              // "convert to unsigned integer"
    ITOU = 317,                    // "convert int to unsigned"
    ITOF = 318,                    // "convert int to float"
    UTOI = 319,                    // "convert unsigned to int"
    UTOF = 320,                    // "convert unsigned to float"
    FTOI = 321,                    // "convert float to int"
    FTOU = 322,                    // "convert float to unsigned"
    AS = 323,                      // "type cast"
    AT = 324,                      // "@"
    ATNOT = 325,                   // "@!"
    NIL = 326,                     // "nil reference"
    PIPE = 327,                    // "|"
    LBRACKET = 328,                // "["
    RBRACKET = 329,                // "]"
    UNDERSCORE = 330,              // "_"
    DOLLAR = 331,                  // "$"
    PLUS = 332,                    // "+"
    MINUS = 333,                   // "-"
    EXCLAMATION = 334,             // "!"
    LPAREN = 335,                  // "("
    RPAREN = 336,                  // ")"
    COMMA = 337,                   // ","
    COLON = 338,                   // ":"
    DOUBLECOLON = 339,             // "::"
    SEMICOLON = 340,               // ";"
    DOT = 341,                     // "."
    EQUALS = 342,                  // "="
    STAR = 343,                    // "*"
    SLASH = 344,                   // "/"
    CARET = 345,                   // "^"
    PERCENT = 346,                 // "%"
    LBRACE = 347,                  // "{"
    RBRACE = 348,                  // "}"
    SUBTYPE = 349,                 // "<:"
    LT = 350,                      // "<"
    GT = 351,                      // ">"
    LE = 352,                      // "<="
    GE = 353,                      // ">="
    NE = 354,                      // "!="
    MAPSTO = 355,                  // "->"
    BW_AND = 356,                  // "band"
    BW_OR = 357,                   // "bor"
    BW_XOR = 358,                  // "bxor"
    BW_SHIFT_L = 359,              // "bshl"
    BW_SHIFT_R = 360,              // "bshr"
    BW_SHIFT_R_UNSIGNED = 361,     // "bshru"
    BW_NOT = 362,                  // "bnot"
    L_AND = 363,                   // "land"
    L_OR = 364,                    // "lor"
    L_XOR = 365,                   // "lxor"
    L_NOT = 366,                   // "lnot"
    OUTER_DOC_COMMENT = 367,       // "outer doc comment"
    INNER_DOC_COMMENT = 368,       // "inner doc comment"
    NEG = 369                      // NEG
      };
      /// Backward compatibility alias (Bison 3.6).
      typedef token_kind_type yytokentype;
    };

    /// Token kind, as returned by yylex.
    typedef token::token_kind_type token_kind_type;

    /// Backward compatibility alias (Bison 3.6).
    typedef token_kind_type token_type;

    /// Symbol kinds.
    struct symbol_kind
    {
      enum symbol_kind_type
      {
        YYNTOKENS = 115, ///< Number of tokens.
        S_YYEMPTY = -2,
        S_YYEOF = 0,                             // "end of input"
        S_YYerror = 1,                           // error
        S_YYUNDEF = 2,                           // "invalid token"
        S_LEAVE = 3,                             // "end of included file"
        S_ENTER = 4,                             // "start of included file"
        S_ENDFILE = 5,                           // "end of file"
        S_STRING = 6,                            // "symbol"
        S_IDENT = 7,                             // "identifier"
        S_NUMBER = 8,                            // "number"
        S_UNSIGNED = 9,                          // "unsigned number"
        S_FLOAT = 10,                            // "float"
        S_AUTOINC = 11,                          // "auto-increment functor"
        S_PRAGMA = 12,                           // "pragma directive"
        S_OUTPUT_QUALIFIER = 13,                 // "relation qualifier output"
        S_INPUT_QUALIFIER = 14,                  // "relation qualifier input"
        S_PRINTSIZE_QUALIFIER = 15,              // "relation qualifier printsize"
        S_BRIE_QUALIFIER = 16,                   // "BRIE datastructure qualifier"
        S_BTREE_QUALIFIER = 17,                  // "BTREE datastructure qualifier"
        S_BTREE_DELETE_QUALIFIER = 18,           // "BTREE_DELETE datastructure qualifier"
        S_EQREL_QUALIFIER = 19,                  // "equivalence relation qualifier"
        S_OVERRIDABLE_QUALIFIER = 20,            // "relation qualifier overidable"
        S_INLINE_QUALIFIER = 21,                 // "relation qualifier inline"
        S_NO_INLINE_QUALIFIER = 22,              // "relation qualifier no_inline"
        S_MAGIC_QUALIFIER = 23,                  // "relation qualifier magic"
        S_NO_MAGIC_QUALIFIER = 24,               // "relation qualifier no_magic"
        S_TMATCH = 25,                           // "match predicate"
        S_TCONTAINS = 26,                        // "checks whether substring is contained in a string"
        S_STATEFUL = 27,                         // "stateful functor"
        S_CAT = 28,                              // "concatenation of strings"
        S_ORD = 29,                              // "ordinal number of a string"
        S_RANGE = 30,                            // "range"
        S_STRLEN = 31,                           // "length of a string"
        S_SUBSTR = 32,                           // "sub-string of a string"
        S_MEAN = 33,                             // "mean aggregator"
        S_MIN = 34,                              // "min aggregator"
        S_MAX = 35,                              // "max aggregator"
        S_COUNT = 36,                            // "count aggregator"
        S_SUM = 37,                              // "sum aggregator"
        S_TRUELIT = 38,                          // "true literal constraint"
        S_FALSELIT = 39,                         // "false literal constraint"
        S_PLAN = 40,                             // "plan keyword"
        S_ITERATION = 41,                        // "recursive iteration keyword"
        S_CHOICEDOMAIN = 42,                     // "choice-domain"
        S_IF = 43,                               // ":-"
        S_DECL = 44,                             // "relation declaration"
        S_FUNCTOR = 45,                          // "functor declaration"
        S_INPUT_DECL = 46,                       // "input directives declaration"
        S_OUTPUT_DECL = 47,                      // "output directives declaration"
        S_DEBUG_DELTA = 48,                      // "debug_delta"
        S_PRINTSIZE_DECL = 49,                   // "printsize directives declaration"
        S_LIMITSIZE_DECL = 50,                   // "limitsize directives declaration"
        S_OVERRIDE = 51,                         // "override rules of super-component"
        S_TYPE = 52,                             // "type declaration"
        S_LATTICE = 53,                          // "lattice declaration"
        S_COMPONENT = 54,                        // "component declaration"
        S_INSTANTIATE = 55,                      // "component instantiation"
        S_NUMBER_TYPE = 56,                      // "numeric type declaration"
        S_SYMBOL_TYPE = 57,                      // "symbolic type declaration"
        S_TOFLOAT = 58,                          // "convert to float"
        S_TONUMBER = 59,                         // "convert to signed integer"
        S_TOSTRING = 60,                         // "convert to string"
        S_TOUNSIGNED = 61,                       // "convert to unsigned integer"
        S_ITOU = 62,                             // "convert int to unsigned"
        S_ITOF = 63,                             // "convert int to float"
        S_UTOI = 64,                             // "convert unsigned to int"
        S_UTOF = 65,                             // "convert unsigned to float"
        S_FTOI = 66,                             // "convert float to int"
        S_FTOU = 67,                             // "convert float to unsigned"
        S_AS = 68,                               // "type cast"
        S_AT = 69,                               // "@"
        S_ATNOT = 70,                            // "@!"
        S_NIL = 71,                              // "nil reference"
        S_PIPE = 72,                             // "|"
        S_LBRACKET = 73,                         // "["
        S_RBRACKET = 74,                         // "]"
        S_UNDERSCORE = 75,                       // "_"
        S_DOLLAR = 76,                           // "$"
        S_PLUS = 77,                             // "+"
        S_MINUS = 78,                            // "-"
        S_EXCLAMATION = 79,                      // "!"
        S_LPAREN = 80,                           // "("
        S_RPAREN = 81,                           // ")"
        S_COMMA = 82,                            // ","
        S_COLON = 83,                            // ":"
        S_DOUBLECOLON = 84,                      // "::"
        S_SEMICOLON = 85,                        // ";"
        S_DOT = 86,                              // "."
        S_EQUALS = 87,                           // "="
        S_STAR = 88,                             // "*"
        S_SLASH = 89,                            // "/"
        S_CARET = 90,                            // "^"
        S_PERCENT = 91,                          // "%"
        S_LBRACE = 92,                           // "{"
        S_RBRACE = 93,                           // "}"
        S_SUBTYPE = 94,                          // "<:"
        S_LT = 95,                               // "<"
        S_GT = 96,                               // ">"
        S_LE = 97,                               // "<="
        S_GE = 98,                               // ">="
        S_NE = 99,                               // "!="
        S_MAPSTO = 100,                          // "->"
        S_BW_AND = 101,                          // "band"
        S_BW_OR = 102,                           // "bor"
        S_BW_XOR = 103,                          // "bxor"
        S_BW_SHIFT_L = 104,                      // "bshl"
        S_BW_SHIFT_R = 105,                      // "bshr"
        S_BW_SHIFT_R_UNSIGNED = 106,             // "bshru"
        S_BW_NOT = 107,                          // "bnot"
        S_L_AND = 108,                           // "land"
        S_L_OR = 109,                            // "lor"
        S_L_XOR = 110,                           // "lxor"
        S_L_NOT = 111,                           // "lnot"
        S_OUTER_DOC_COMMENT = 112,               // "outer doc comment"
        S_INNER_DOC_COMMENT = 113,               // "inner doc comment"
        S_NEG = 114,                             // NEG
        S_YYACCEPT = 115,                        // $accept
        S_program = 116,                         // program
        S_unit = 117,                            // unit
        S_qualified_name = 118,                  // qualified_name
        S_type_decl = 119,                       // type_decl
        S_record_type_list = 120,                // record_type_list
        S_union_type_list = 121,                 // union_type_list
        S_adt_branch_list = 122,                 // adt_branch_list
        S_adt_branch = 123,                      // adt_branch
        S_lattice_decl = 124,                    // lattice_decl
        S_lattice_operator_list = 125,           // lattice_operator_list
        S_lattice_operator = 126,                // lattice_operator
        S_relation_decl = 127,                   // relation_decl
        S_relation_names = 128,                  // relation_names
        S_attributes_list = 129,                 // attributes_list
        S_non_empty_attributes = 130,            // non_empty_attributes
        S_attribute = 131,                       // attribute
        S_relation_tags = 132,                   // relation_tags
        S_non_empty_attribute_names = 133,       // non_empty_attribute_names
        S_dependency = 134,                      // dependency
        S_dependency_list_aux = 135,             // dependency_list_aux
        S_dependency_list = 136,                 // dependency_list
        S_fact = 137,                            // fact
        S_rule = 138,                            // rule
        S_rule_def = 139,                        // rule_def
        S_head = 140,                            // head
        S_body = 141,                            // body
        S_disjunction = 142,                     // disjunction
        S_conjunction = 143,                     // conjunction
        S_term = 144,                            // term
        S_atom = 145,                            // atom
        S_constraint = 146,                      // constraint
        S_arg_list = 147,                        // arg_list
        S_non_empty_arg_list = 148,              // non_empty_arg_list
        S_arg = 149,                             // arg
        S_functor_built_in = 150,                // functor_built_in
        S_aggregate_func = 151,                  // aggregate_func
        S_aggregate_body = 152,                  // aggregate_body
        S_query_plan = 153,                      // query_plan
        S_query_plan_list = 154,                 // query_plan_list
        S_plan_order = 155,                      // plan_order
        S_non_empty_plan_order_list = 156,       // non_empty_plan_order_list
        S_component_decl = 157,                  // component_decl
        S_component_head = 158,                  // component_head
        S_component_type = 159,                  // component_type
        S_component_type_params = 160,           // component_type_params
        S_component_param_list = 161,            // component_param_list
        S_component_body = 162,                  // component_body
        S_component_init = 163,                  // component_init
        S_functor_decl = 164,                    // functor_decl
        S_functor_arg_type_list = 165,           // functor_arg_type_list
        S_non_empty_functor_arg_type_list = 166, // non_empty_functor_arg_type_list
        S_functor_attribute = 167,               // functor_attribute
        S_pragma = 168,                          // pragma
        S_directive_head = 169,                  // directive_head
        S_directive_head_decl = 170,             // directive_head_decl
        S_directive_list = 171,                  // directive_list
        S_relation_directive_list = 172,         // relation_directive_list
        S_non_empty_key_value_pairs = 173,       // non_empty_key_value_pairs
        S_kvp_value = 174,                       // kvp_value
        S_annotations = 175,                     // annotations
        S_annotation = 176,                      // annotation
        S_annotation_input = 177,                // annotation_input
        S_inner_annotations = 178,               // inner_annotations
        S_non_empty_inner_annotations = 179,     // non_empty_inner_annotations
        S_inner_annotation = 180,                // inner_annotation
        S_token_stream = 181,                    // token_stream
        S_delim = 182,                           // delim
        S_ident_token = 183,                     // ident_token
        S_token = 184                            // token
      };
    };

    /// (Internal) symbol kind.
    typedef symbol_kind::symbol_kind_type symbol_kind_type;

    /// The number of tokens.
    static const symbol_kind_type YYNTOKENS = symbol_kind::YYNTOKENS;

    /// A complete symbol.
    ///
    /// Expects its Base type to provide access to the symbol kind
    /// via kind ().
    ///
    /// Provide access to semantic value and location.
    template <typename Base>
    struct basic_symbol : Base
    {
      /// Alias to Base.
      typedef Base super_type;

      /// Default constructor.
      basic_symbol () YY_NOEXCEPT
        : value ()
        , location ()
      {}

#if 201103L <= YY_CPLUSPLUS
      /// Move constructor.
      basic_symbol (basic_symbol&& that)
        : Base (std::move (that))
        , value ()
        , location (std::move (that.location))
      {
        switch (this->kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.move< AggregateOp > (std::move (that.value));
        break;

      case symbol_kind::S_arg: // arg
        value.move< Own<ast::Argument> > (std::move (that.value));
        break;

      case symbol_kind::S_atom: // atom
        value.move< Own<ast::Atom> > (std::move (that.value));
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.move< Own<ast::Attribute> > (std::move (that.value));
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.move< Own<ast::BranchType> > (std::move (that.value));
        break;

      case symbol_kind::S_fact: // fact
        value.move< Own<ast::Clause> > (std::move (that.value));
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.move< Own<ast::Component> > (std::move (that.value));
        break;

      case symbol_kind::S_component_init: // component_init
        value.move< Own<ast::ComponentInit> > (std::move (that.value));
        break;

      case symbol_kind::S_component_type: // component_type
        value.move< Own<ast::ComponentType> > (std::move (that.value));
        break;

      case symbol_kind::S_constraint: // constraint
        value.move< Own<ast::Constraint> > (std::move (that.value));
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.move< Own<ast::ExecutionOrder> > (std::move (that.value));
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.move< Own<ast::ExecutionPlan> > (std::move (that.value));
        break;

      case symbol_kind::S_dependency: // dependency
        value.move< Own<ast::FunctionalConstraint> > (std::move (that.value));
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.move< Own<ast::FunctorDeclaration> > (std::move (that.value));
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.move< Own<ast::Lattice> > (std::move (that.value));
        break;

      case symbol_kind::S_pragma: // pragma
        value.move< Own<ast::Pragma> > (std::move (that.value));
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.move< Own<ast::Type> > (std::move (that.value));
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.move< RuleBody > (std::move (that.value));
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.move< VecOwn<ast::Argument> > (std::move (that.value));
        break;

      case symbol_kind::S_head: // head
        value.move< VecOwn<ast::Atom> > (std::move (that.value));
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.move< VecOwn<ast::Attribute> > (std::move (that.value));
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.move< VecOwn<ast::BranchType> > (std::move (that.value));
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.move< VecOwn<ast::Clause> > (std::move (that.value));
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.move< VecOwn<ast::Directive> > (std::move (that.value));
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.move< VecOwn<ast::FunctionalConstraint> > (std::move (that.value));
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.move< VecOwn<ast::Relation> > (std::move (that.value));
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.move< ast::Annotation > (std::move (that.value));
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.move< ast::AnnotationList > (std::move (that.value));
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.move< ast::DirectiveType > (std::move (that.value));
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.move< ast::ExecutionOrder::ExecOrder > (std::move (that.value));
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.move< ast::QualifiedName > (std::move (that.value));
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.move< ast::TokenStream > (std::move (that.value));
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.move< ast::TokenTree > (std::move (that.value));
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.move< std::map<ast::LatticeOperator, Own<ast::Argument>> > (std::move (that.value));
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.move< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (std::move (that.value));
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.move< std::set<RelationTag> > (std::move (that.value));
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.move< std::string > (std::move (that.value));
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.move< std::vector<ast::QualifiedName> > (std::move (that.value));
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.move< std::vector<std::pair<std::string, std::string>> > (std::move (that.value));
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.move< std::vector<std::string> > (std::move (that.value));
        break;

      default:
        break;
    }

      }
#endif

      /// Copy constructor.
      basic_symbol (const basic_symbol& that);

      /// Constructors for typed symbols.
#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, location_type&& l)
        : Base (t)
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const location_type& l)
        : Base (t)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, AggregateOp&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const AggregateOp& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Argument>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Argument>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Atom>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Atom>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Attribute>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Attribute>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::BranchType>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::BranchType>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Clause>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Clause>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Component>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Component>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::ComponentInit>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::ComponentInit>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::ComponentType>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::ComponentType>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Constraint>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Constraint>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::ExecutionOrder>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::ExecutionOrder>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::ExecutionPlan>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::ExecutionPlan>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::FunctionalConstraint>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::FunctionalConstraint>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::FunctorDeclaration>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::FunctorDeclaration>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Lattice>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Lattice>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Pragma>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Pragma>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, Own<ast::Type>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const Own<ast::Type>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, RuleBody&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const RuleBody& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Argument>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Argument>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Atom>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Atom>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Attribute>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Attribute>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::BranchType>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::BranchType>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Clause>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Clause>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Directive>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Directive>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::FunctionalConstraint>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::FunctionalConstraint>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, VecOwn<ast::Relation>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const VecOwn<ast::Relation>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::Annotation&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::Annotation& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::AnnotationList&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::AnnotationList& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::DirectiveType&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::DirectiveType& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::ExecutionOrder::ExecOrder&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::ExecutionOrder::ExecOrder& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::QualifiedName&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::QualifiedName& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::TokenStream&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::TokenStream& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, ast::TokenTree&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const ast::TokenTree& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::map<ast::LatticeOperator, Own<ast::Argument>>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::map<ast::LatticeOperator, Own<ast::Argument>>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::pair<ast::LatticeOperator, Own<ast::Argument>>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::pair<ast::LatticeOperator, Own<ast::Argument>>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::set<RelationTag>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::set<RelationTag>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::string&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::string& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::vector<ast::QualifiedName>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::vector<ast::QualifiedName>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::vector<std::pair<std::string, std::string>>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::vector<std::pair<std::string, std::string>>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::vector<std::string>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::vector<std::string>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

      /// Destroy the symbol.
      ~basic_symbol ()
      {
        clear ();
      }



      /// Destroy contents, and record that is empty.
      void clear () YY_NOEXCEPT
      {
        // User destructor.
        symbol_kind_type yykind = this->kind ();
        basic_symbol<Base>& yysym = *this;
        (void) yysym;
        switch (yykind)
        {
       default:
          break;
        }

        // Value type destructor.
switch (yykind)
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.template destroy< AggregateOp > ();
        break;

      case symbol_kind::S_arg: // arg
        value.template destroy< Own<ast::Argument> > ();
        break;

      case symbol_kind::S_atom: // atom
        value.template destroy< Own<ast::Atom> > ();
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.template destroy< Own<ast::Attribute> > ();
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.template destroy< Own<ast::BranchType> > ();
        break;

      case symbol_kind::S_fact: // fact
        value.template destroy< Own<ast::Clause> > ();
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.template destroy< Own<ast::Component> > ();
        break;

      case symbol_kind::S_component_init: // component_init
        value.template destroy< Own<ast::ComponentInit> > ();
        break;

      case symbol_kind::S_component_type: // component_type
        value.template destroy< Own<ast::ComponentType> > ();
        break;

      case symbol_kind::S_constraint: // constraint
        value.template destroy< Own<ast::Constraint> > ();
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.template destroy< Own<ast::ExecutionOrder> > ();
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.template destroy< Own<ast::ExecutionPlan> > ();
        break;

      case symbol_kind::S_dependency: // dependency
        value.template destroy< Own<ast::FunctionalConstraint> > ();
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.template destroy< Own<ast::FunctorDeclaration> > ();
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.template destroy< Own<ast::Lattice> > ();
        break;

      case symbol_kind::S_pragma: // pragma
        value.template destroy< Own<ast::Pragma> > ();
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.template destroy< Own<ast::Type> > ();
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.template destroy< RuleBody > ();
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.template destroy< VecOwn<ast::Argument> > ();
        break;

      case symbol_kind::S_head: // head
        value.template destroy< VecOwn<ast::Atom> > ();
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.template destroy< VecOwn<ast::Attribute> > ();
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.template destroy< VecOwn<ast::BranchType> > ();
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.template destroy< VecOwn<ast::Clause> > ();
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.template destroy< VecOwn<ast::Directive> > ();
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.template destroy< VecOwn<ast::FunctionalConstraint> > ();
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.template destroy< VecOwn<ast::Relation> > ();
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.template destroy< ast::Annotation > ();
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.template destroy< ast::AnnotationList > ();
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.template destroy< ast::DirectiveType > ();
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.template destroy< ast::ExecutionOrder::ExecOrder > ();
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.template destroy< ast::QualifiedName > ();
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.template destroy< ast::TokenStream > ();
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.template destroy< ast::TokenTree > ();
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.template destroy< std::map<ast::LatticeOperator, Own<ast::Argument>> > ();
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.template destroy< std::pair<ast::LatticeOperator, Own<ast::Argument>> > ();
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.template destroy< std::set<RelationTag> > ();
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.template destroy< std::string > ();
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.template destroy< std::vector<ast::QualifiedName> > ();
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.template destroy< std::vector<std::pair<std::string, std::string>> > ();
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.template destroy< std::vector<std::string> > ();
        break;

      default:
        break;
    }

        Base::clear ();
      }

      /// The user-facing name of this symbol.
      std::string name () const YY_NOEXCEPT
      {
        return parser::symbol_name (this->kind ());
      }

      /// Backward compatibility (Bison 3.6).
      symbol_kind_type type_get () const YY_NOEXCEPT;

      /// Whether empty.
      bool empty () const YY_NOEXCEPT;

      /// Destructive move, \a s is emptied into this.
      void move (basic_symbol& s);

      /// The semantic value.
      value_type value;

      /// The location.
      location_type location;

    private:
#if YY_CPLUSPLUS < 201103L
      /// Assignment operator.
      basic_symbol& operator= (const basic_symbol& that);
#endif
    };

    /// Type access provider for token (enum) based symbols.
    struct by_kind
    {
      /// The symbol kind as needed by the constructor.
      typedef token_kind_type kind_type;

      /// Default constructor.
      by_kind () YY_NOEXCEPT;

#if 201103L <= YY_CPLUSPLUS
      /// Move constructor.
      by_kind (by_kind&& that) YY_NOEXCEPT;
#endif

      /// Copy constructor.
      by_kind (const by_kind& that) YY_NOEXCEPT;

      /// Constructor from (external) token numbers.
      by_kind (kind_type t) YY_NOEXCEPT;



      /// Record that this symbol is empty.
      void clear () YY_NOEXCEPT;

      /// Steal the symbol kind from \a that.
      void move (by_kind& that);

      /// The (internal) type number (corresponding to \a type).
      /// \a empty when empty.
      symbol_kind_type kind () const YY_NOEXCEPT;

      /// Backward compatibility (Bison 3.6).
      symbol_kind_type type_get () const YY_NOEXCEPT;

      /// The symbol kind.
      /// \a S_YYEMPTY when empty.
      symbol_kind_type kind_;
    };

    /// Backward compatibility for a private implementation detail (Bison 3.6).
    typedef by_kind by_type;

    /// "External" symbols: returned by the scanner.
    struct symbol_type : basic_symbol<by_kind>
    {
      /// Superclass.
      typedef basic_symbol<by_kind> super_type;

      /// Empty symbol.
      symbol_type () YY_NOEXCEPT {}

      /// Constructor for valueless symbols, and symbols from each type.
#if 201103L <= YY_CPLUSPLUS
      symbol_type (int tok, location_type l)
        : super_type (token_kind_type (tok), std::move (l))
#else
      symbol_type (int tok, const location_type& l)
        : super_type (token_kind_type (tok), l)
#endif
      {
#if !defined _MSC_VER || defined __clang__
        YY_ASSERT (tok == token::END
                   || (token::YYerror <= tok && tok <= token::ENDFILE)
                   || (token::AUTOINC <= tok && tok <= token::L_NOT)
                   || tok == token::NEG);
#endif
      }
#if 201103L <= YY_CPLUSPLUS
      symbol_type (int tok, std::string v, location_type l)
        : super_type (token_kind_type (tok), std::move (v), std::move (l))
#else
      symbol_type (int tok, const std::string& v, const location_type& l)
        : super_type (token_kind_type (tok), v, l)
#endif
      {
#if !defined _MSC_VER || defined __clang__
        YY_ASSERT ((token::STRING <= tok && tok <= token::FLOAT)
                   || (token::OUTER_DOC_COMMENT <= tok && tok <= token::INNER_DOC_COMMENT));
#endif
      }
    };

    /// Build a parser object.
    parser (ParserDriver &driver_yyarg, yyscan_t yyscanner_yyarg);
    virtual ~parser ();

#if 201103L <= YY_CPLUSPLUS
    /// Non copyable.
    parser (const parser&) = delete;
    /// Non copyable.
    parser& operator= (const parser&) = delete;
#endif

    /// Parse.  An alias for parse ().
    /// \returns  0 iff parsing succeeded.
    int operator() ();

    /// Parse.
    /// \returns  0 iff parsing succeeded.
    virtual int parse ();

#if YYDEBUG
    /// The current debugging stream.
    std::ostream& debug_stream () const YY_ATTRIBUTE_PURE;
    /// Set the current debugging stream.
    void set_debug_stream (std::ostream &);

    /// Type for debugging levels.
    typedef int debug_level_type;
    /// The current debugging level.
    debug_level_type debug_level () const YY_ATTRIBUTE_PURE;
    /// Set the current debugging level.
    void set_debug_level (debug_level_type l);
#endif

    /// Report a syntax error.
    /// \param loc    where the syntax error is found.
    /// \param msg    a description of the syntax error.
    virtual void error (const location_type& loc, const std::string& msg);

    /// Report a syntax error.
    void error (const syntax_error& err);

    /// The user-facing name of the symbol whose (internal) number is
    /// YYSYMBOL.  No bounds checking.
    static std::string symbol_name (symbol_kind_type yysymbol);

    // Implementation of make_symbol for each token kind.
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_END (location_type l)
      {
        return symbol_type (token::END, std::move (l));
      }
#else
      static
      symbol_type
      make_END (const location_type& l)
      {
        return symbol_type (token::END, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_YYerror (location_type l)
      {
        return symbol_type (token::YYerror, std::move (l));
      }
#else
      static
      symbol_type
      make_YYerror (const location_type& l)
      {
        return symbol_type (token::YYerror, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_YYUNDEF (location_type l)
      {
        return symbol_type (token::YYUNDEF, std::move (l));
      }
#else
      static
      symbol_type
      make_YYUNDEF (const location_type& l)
      {
        return symbol_type (token::YYUNDEF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LEAVE (location_type l)
      {
        return symbol_type (token::LEAVE, std::move (l));
      }
#else
      static
      symbol_type
      make_LEAVE (const location_type& l)
      {
        return symbol_type (token::LEAVE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ENTER (location_type l)
      {
        return symbol_type (token::ENTER, std::move (l));
      }
#else
      static
      symbol_type
      make_ENTER (const location_type& l)
      {
        return symbol_type (token::ENTER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ENDFILE (location_type l)
      {
        return symbol_type (token::ENDFILE, std::move (l));
      }
#else
      static
      symbol_type
      make_ENDFILE (const location_type& l)
      {
        return symbol_type (token::ENDFILE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_STRING (std::string v, location_type l)
      {
        return symbol_type (token::STRING, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_STRING (const std::string& v, const location_type& l)
      {
        return symbol_type (token::STRING, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_IDENT (std::string v, location_type l)
      {
        return symbol_type (token::IDENT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_IDENT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::IDENT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NUMBER (std::string v, location_type l)
      {
        return symbol_type (token::NUMBER, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_NUMBER (const std::string& v, const location_type& l)
      {
        return symbol_type (token::NUMBER, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_UNSIGNED (std::string v, location_type l)
      {
        return symbol_type (token::UNSIGNED, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_UNSIGNED (const std::string& v, const location_type& l)
      {
        return symbol_type (token::UNSIGNED, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FLOAT (std::string v, location_type l)
      {
        return symbol_type (token::FLOAT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_FLOAT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::FLOAT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_AUTOINC (location_type l)
      {
        return symbol_type (token::AUTOINC, std::move (l));
      }
#else
      static
      symbol_type
      make_AUTOINC (const location_type& l)
      {
        return symbol_type (token::AUTOINC, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PRAGMA (location_type l)
      {
        return symbol_type (token::PRAGMA, std::move (l));
      }
#else
      static
      symbol_type
      make_PRAGMA (const location_type& l)
      {
        return symbol_type (token::PRAGMA, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OUTPUT_QUALIFIER (location_type l)
      {
        return symbol_type (token::OUTPUT_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_OUTPUT_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::OUTPUT_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INPUT_QUALIFIER (location_type l)
      {
        return symbol_type (token::INPUT_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_INPUT_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::INPUT_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PRINTSIZE_QUALIFIER (location_type l)
      {
        return symbol_type (token::PRINTSIZE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_PRINTSIZE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::PRINTSIZE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BRIE_QUALIFIER (location_type l)
      {
        return symbol_type (token::BRIE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_BRIE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::BRIE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BTREE_QUALIFIER (location_type l)
      {
        return symbol_type (token::BTREE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_BTREE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::BTREE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BTREE_DELETE_QUALIFIER (location_type l)
      {
        return symbol_type (token::BTREE_DELETE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_BTREE_DELETE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::BTREE_DELETE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_EQREL_QUALIFIER (location_type l)
      {
        return symbol_type (token::EQREL_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_EQREL_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::EQREL_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OVERRIDABLE_QUALIFIER (location_type l)
      {
        return symbol_type (token::OVERRIDABLE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_OVERRIDABLE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::OVERRIDABLE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INLINE_QUALIFIER (location_type l)
      {
        return symbol_type (token::INLINE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_INLINE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::INLINE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NO_INLINE_QUALIFIER (location_type l)
      {
        return symbol_type (token::NO_INLINE_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_NO_INLINE_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::NO_INLINE_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MAGIC_QUALIFIER (location_type l)
      {
        return symbol_type (token::MAGIC_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_MAGIC_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::MAGIC_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NO_MAGIC_QUALIFIER (location_type l)
      {
        return symbol_type (token::NO_MAGIC_QUALIFIER, std::move (l));
      }
#else
      static
      symbol_type
      make_NO_MAGIC_QUALIFIER (const location_type& l)
      {
        return symbol_type (token::NO_MAGIC_QUALIFIER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TMATCH (location_type l)
      {
        return symbol_type (token::TMATCH, std::move (l));
      }
#else
      static
      symbol_type
      make_TMATCH (const location_type& l)
      {
        return symbol_type (token::TMATCH, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TCONTAINS (location_type l)
      {
        return symbol_type (token::TCONTAINS, std::move (l));
      }
#else
      static
      symbol_type
      make_TCONTAINS (const location_type& l)
      {
        return symbol_type (token::TCONTAINS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_STATEFUL (location_type l)
      {
        return symbol_type (token::STATEFUL, std::move (l));
      }
#else
      static
      symbol_type
      make_STATEFUL (const location_type& l)
      {
        return symbol_type (token::STATEFUL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CAT (location_type l)
      {
        return symbol_type (token::CAT, std::move (l));
      }
#else
      static
      symbol_type
      make_CAT (const location_type& l)
      {
        return symbol_type (token::CAT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ORD (location_type l)
      {
        return symbol_type (token::ORD, std::move (l));
      }
#else
      static
      symbol_type
      make_ORD (const location_type& l)
      {
        return symbol_type (token::ORD, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RANGE (location_type l)
      {
        return symbol_type (token::RANGE, std::move (l));
      }
#else
      static
      symbol_type
      make_RANGE (const location_type& l)
      {
        return symbol_type (token::RANGE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_STRLEN (location_type l)
      {
        return symbol_type (token::STRLEN, std::move (l));
      }
#else
      static
      symbol_type
      make_STRLEN (const location_type& l)
      {
        return symbol_type (token::STRLEN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SUBSTR (location_type l)
      {
        return symbol_type (token::SUBSTR, std::move (l));
      }
#else
      static
      symbol_type
      make_SUBSTR (const location_type& l)
      {
        return symbol_type (token::SUBSTR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MEAN (location_type l)
      {
        return symbol_type (token::MEAN, std::move (l));
      }
#else
      static
      symbol_type
      make_MEAN (const location_type& l)
      {
        return symbol_type (token::MEAN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MIN (location_type l)
      {
        return symbol_type (token::MIN, std::move (l));
      }
#else
      static
      symbol_type
      make_MIN (const location_type& l)
      {
        return symbol_type (token::MIN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MAX (location_type l)
      {
        return symbol_type (token::MAX, std::move (l));
      }
#else
      static
      symbol_type
      make_MAX (const location_type& l)
      {
        return symbol_type (token::MAX, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COUNT (location_type l)
      {
        return symbol_type (token::COUNT, std::move (l));
      }
#else
      static
      symbol_type
      make_COUNT (const location_type& l)
      {
        return symbol_type (token::COUNT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SUM (location_type l)
      {
        return symbol_type (token::SUM, std::move (l));
      }
#else
      static
      symbol_type
      make_SUM (const location_type& l)
      {
        return symbol_type (token::SUM, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TRUELIT (location_type l)
      {
        return symbol_type (token::TRUELIT, std::move (l));
      }
#else
      static
      symbol_type
      make_TRUELIT (const location_type& l)
      {
        return symbol_type (token::TRUELIT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FALSELIT (location_type l)
      {
        return symbol_type (token::FALSELIT, std::move (l));
      }
#else
      static
      symbol_type
      make_FALSELIT (const location_type& l)
      {
        return symbol_type (token::FALSELIT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PLAN (location_type l)
      {
        return symbol_type (token::PLAN, std::move (l));
      }
#else
      static
      symbol_type
      make_PLAN (const location_type& l)
      {
        return symbol_type (token::PLAN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ITERATION (location_type l)
      {
        return symbol_type (token::ITERATION, std::move (l));
      }
#else
      static
      symbol_type
      make_ITERATION (const location_type& l)
      {
        return symbol_type (token::ITERATION, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CHOICEDOMAIN (location_type l)
      {
        return symbol_type (token::CHOICEDOMAIN, std::move (l));
      }
#else
      static
      symbol_type
      make_CHOICEDOMAIN (const location_type& l)
      {
        return symbol_type (token::CHOICEDOMAIN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_IF (location_type l)
      {
        return symbol_type (token::IF, std::move (l));
      }
#else
      static
      symbol_type
      make_IF (const location_type& l)
      {
        return symbol_type (token::IF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DECL (location_type l)
      {
        return symbol_type (token::DECL, std::move (l));
      }
#else
      static
      symbol_type
      make_DECL (const location_type& l)
      {
        return symbol_type (token::DECL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FUNCTOR (location_type l)
      {
        return symbol_type (token::FUNCTOR, std::move (l));
      }
#else
      static
      symbol_type
      make_FUNCTOR (const location_type& l)
      {
        return symbol_type (token::FUNCTOR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INPUT_DECL (location_type l)
      {
        return symbol_type (token::INPUT_DECL, std::move (l));
      }
#else
      static
      symbol_type
      make_INPUT_DECL (const location_type& l)
      {
        return symbol_type (token::INPUT_DECL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OUTPUT_DECL (location_type l)
      {
        return symbol_type (token::OUTPUT_DECL, std::move (l));
      }
#else
      static
      symbol_type
      make_OUTPUT_DECL (const location_type& l)
      {
        return symbol_type (token::OUTPUT_DECL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DEBUG_DELTA (location_type l)
      {
        return symbol_type (token::DEBUG_DELTA, std::move (l));
      }
#else
      static
      symbol_type
      make_DEBUG_DELTA (const location_type& l)
      {
        return symbol_type (token::DEBUG_DELTA, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PRINTSIZE_DECL (location_type l)
      {
        return symbol_type (token::PRINTSIZE_DECL, std::move (l));
      }
#else
      static
      symbol_type
      make_PRINTSIZE_DECL (const location_type& l)
      {
        return symbol_type (token::PRINTSIZE_DECL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LIMITSIZE_DECL (location_type l)
      {
        return symbol_type (token::LIMITSIZE_DECL, std::move (l));
      }
#else
      static
      symbol_type
      make_LIMITSIZE_DECL (const location_type& l)
      {
        return symbol_type (token::LIMITSIZE_DECL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OVERRIDE (location_type l)
      {
        return symbol_type (token::OVERRIDE, std::move (l));
      }
#else
      static
      symbol_type
      make_OVERRIDE (const location_type& l)
      {
        return symbol_type (token::OVERRIDE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TYPE (location_type l)
      {
        return symbol_type (token::TYPE, std::move (l));
      }
#else
      static
      symbol_type
      make_TYPE (const location_type& l)
      {
        return symbol_type (token::TYPE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LATTICE (location_type l)
      {
        return symbol_type (token::LATTICE, std::move (l));
      }
#else
      static
      symbol_type
      make_LATTICE (const location_type& l)
      {
        return symbol_type (token::LATTICE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COMPONENT (location_type l)
      {
        return symbol_type (token::COMPONENT, std::move (l));
      }
#else
      static
      symbol_type
      make_COMPONENT (const location_type& l)
      {
        return symbol_type (token::COMPONENT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INSTANTIATE (location_type l)
      {
        return symbol_type (token::INSTANTIATE, std::move (l));
      }
#else
      static
      symbol_type
      make_INSTANTIATE (const location_type& l)
      {
        return symbol_type (token::INSTANTIATE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NUMBER_TYPE (location_type l)
      {
        return symbol_type (token::NUMBER_TYPE, std::move (l));
      }
#else
      static
      symbol_type
      make_NUMBER_TYPE (const location_type& l)
      {
        return symbol_type (token::NUMBER_TYPE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SYMBOL_TYPE (location_type l)
      {
        return symbol_type (token::SYMBOL_TYPE, std::move (l));
      }
#else
      static
      symbol_type
      make_SYMBOL_TYPE (const location_type& l)
      {
        return symbol_type (token::SYMBOL_TYPE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOFLOAT (location_type l)
      {
        return symbol_type (token::TOFLOAT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOFLOAT (const location_type& l)
      {
        return symbol_type (token::TOFLOAT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TONUMBER (location_type l)
      {
        return symbol_type (token::TONUMBER, std::move (l));
      }
#else
      static
      symbol_type
      make_TONUMBER (const location_type& l)
      {
        return symbol_type (token::TONUMBER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOSTRING (location_type l)
      {
        return symbol_type (token::TOSTRING, std::move (l));
      }
#else
      static
      symbol_type
      make_TOSTRING (const location_type& l)
      {
        return symbol_type (token::TOSTRING, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOUNSIGNED (location_type l)
      {
        return symbol_type (token::TOUNSIGNED, std::move (l));
      }
#else
      static
      symbol_type
      make_TOUNSIGNED (const location_type& l)
      {
        return symbol_type (token::TOUNSIGNED, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ITOU (location_type l)
      {
        return symbol_type (token::ITOU, std::move (l));
      }
#else
      static
      symbol_type
      make_ITOU (const location_type& l)
      {
        return symbol_type (token::ITOU, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ITOF (location_type l)
      {
        return symbol_type (token::ITOF, std::move (l));
      }
#else
      static
      symbol_type
      make_ITOF (const location_type& l)
      {
        return symbol_type (token::ITOF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_UTOI (location_type l)
      {
        return symbol_type (token::UTOI, std::move (l));
      }
#else
      static
      symbol_type
      make_UTOI (const location_type& l)
      {
        return symbol_type (token::UTOI, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_UTOF (location_type l)
      {
        return symbol_type (token::UTOF, std::move (l));
      }
#else
      static
      symbol_type
      make_UTOF (const location_type& l)
      {
        return symbol_type (token::UTOF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FTOI (location_type l)
      {
        return symbol_type (token::FTOI, std::move (l));
      }
#else
      static
      symbol_type
      make_FTOI (const location_type& l)
      {
        return symbol_type (token::FTOI, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FTOU (location_type l)
      {
        return symbol_type (token::FTOU, std::move (l));
      }
#else
      static
      symbol_type
      make_FTOU (const location_type& l)
      {
        return symbol_type (token::FTOU, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_AS (location_type l)
      {
        return symbol_type (token::AS, std::move (l));
      }
#else
      static
      symbol_type
      make_AS (const location_type& l)
      {
        return symbol_type (token::AS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_AT (location_type l)
      {
        return symbol_type (token::AT, std::move (l));
      }
#else
      static
      symbol_type
      make_AT (const location_type& l)
      {
        return symbol_type (token::AT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ATNOT (location_type l)
      {
        return symbol_type (token::ATNOT, std::move (l));
      }
#else
      static
      symbol_type
      make_ATNOT (const location_type& l)
      {
        return symbol_type (token::ATNOT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NIL (location_type l)
      {
        return symbol_type (token::NIL, std::move (l));
      }
#else
      static
      symbol_type
      make_NIL (const location_type& l)
      {
        return symbol_type (token::NIL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PIPE (location_type l)
      {
        return symbol_type (token::PIPE, std::move (l));
      }
#else
      static
      symbol_type
      make_PIPE (const location_type& l)
      {
        return symbol_type (token::PIPE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LBRACKET (location_type l)
      {
        return symbol_type (token::LBRACKET, std::move (l));
      }
#else
      static
      symbol_type
      make_LBRACKET (const location_type& l)
      {
        return symbol_type (token::LBRACKET, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RBRACKET (location_type l)
      {
        return symbol_type (token::RBRACKET, std::move (l));
      }
#else
      static
      symbol_type
      make_RBRACKET (const location_type& l)
      {
        return symbol_type (token::RBRACKET, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_UNDERSCORE (location_type l)
      {
        return symbol_type (token::UNDERSCORE, std::move (l));
      }
#else
      static
      symbol_type
      make_UNDERSCORE (const location_type& l)
      {
        return symbol_type (token::UNDERSCORE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DOLLAR (location_type l)
      {
        return symbol_type (token::DOLLAR, std::move (l));
      }
#else
      static
      symbol_type
      make_DOLLAR (const location_type& l)
      {
        return symbol_type (token::DOLLAR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PLUS (location_type l)
      {
        return symbol_type (token::PLUS, std::move (l));
      }
#else
      static
      symbol_type
      make_PLUS (const location_type& l)
      {
        return symbol_type (token::PLUS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MINUS (location_type l)
      {
        return symbol_type (token::MINUS, std::move (l));
      }
#else
      static
      symbol_type
      make_MINUS (const location_type& l)
      {
        return symbol_type (token::MINUS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_EXCLAMATION (location_type l)
      {
        return symbol_type (token::EXCLAMATION, std::move (l));
      }
#else
      static
      symbol_type
      make_EXCLAMATION (const location_type& l)
      {
        return symbol_type (token::EXCLAMATION, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LPAREN (location_type l)
      {
        return symbol_type (token::LPAREN, std::move (l));
      }
#else
      static
      symbol_type
      make_LPAREN (const location_type& l)
      {
        return symbol_type (token::LPAREN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RPAREN (location_type l)
      {
        return symbol_type (token::RPAREN, std::move (l));
      }
#else
      static
      symbol_type
      make_RPAREN (const location_type& l)
      {
        return symbol_type (token::RPAREN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COMMA (location_type l)
      {
        return symbol_type (token::COMMA, std::move (l));
      }
#else
      static
      symbol_type
      make_COMMA (const location_type& l)
      {
        return symbol_type (token::COMMA, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COLON (location_type l)
      {
        return symbol_type (token::COLON, std::move (l));
      }
#else
      static
      symbol_type
      make_COLON (const location_type& l)
      {
        return symbol_type (token::COLON, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DOUBLECOLON (location_type l)
      {
        return symbol_type (token::DOUBLECOLON, std::move (l));
      }
#else
      static
      symbol_type
      make_DOUBLECOLON (const location_type& l)
      {
        return symbol_type (token::DOUBLECOLON, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SEMICOLON (location_type l)
      {
        return symbol_type (token::SEMICOLON, std::move (l));
      }
#else
      static
      symbol_type
      make_SEMICOLON (const location_type& l)
      {
        return symbol_type (token::SEMICOLON, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DOT (location_type l)
      {
        return symbol_type (token::DOT, std::move (l));
      }
#else
      static
      symbol_type
      make_DOT (const location_type& l)
      {
        return symbol_type (token::DOT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_EQUALS (location_type l)
      {
        return symbol_type (token::EQUALS, std::move (l));
      }
#else
      static
      symbol_type
      make_EQUALS (const location_type& l)
      {
        return symbol_type (token::EQUALS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_STAR (location_type l)
      {
        return symbol_type (token::STAR, std::move (l));
      }
#else
      static
      symbol_type
      make_STAR (const location_type& l)
      {
        return symbol_type (token::STAR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SLASH (location_type l)
      {
        return symbol_type (token::SLASH, std::move (l));
      }
#else
      static
      symbol_type
      make_SLASH (const location_type& l)
      {
        return symbol_type (token::SLASH, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CARET (location_type l)
      {
        return symbol_type (token::CARET, std::move (l));
      }
#else
      static
      symbol_type
      make_CARET (const location_type& l)
      {
        return symbol_type (token::CARET, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PERCENT (location_type l)
      {
        return symbol_type (token::PERCENT, std::move (l));
      }
#else
      static
      symbol_type
      make_PERCENT (const location_type& l)
      {
        return symbol_type (token::PERCENT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LBRACE (location_type l)
      {
        return symbol_type (token::LBRACE, std::move (l));
      }
#else
      static
      symbol_type
      make_LBRACE (const location_type& l)
      {
        return symbol_type (token::LBRACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RBRACE (location_type l)
      {
        return symbol_type (token::RBRACE, std::move (l));
      }
#else
      static
      symbol_type
      make_RBRACE (const location_type& l)
      {
        return symbol_type (token::RBRACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SUBTYPE (location_type l)
      {
        return symbol_type (token::SUBTYPE, std::move (l));
      }
#else
      static
      symbol_type
      make_SUBTYPE (const location_type& l)
      {
        return symbol_type (token::SUBTYPE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LT (location_type l)
      {
        return symbol_type (token::LT, std::move (l));
      }
#else
      static
      symbol_type
      make_LT (const location_type& l)
      {
        return symbol_type (token::LT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_GT (location_type l)
      {
        return symbol_type (token::GT, std::move (l));
      }
#else
      static
      symbol_type
      make_GT (const location_type& l)
      {
        return symbol_type (token::GT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LE (location_type l)
      {
        return symbol_type (token::LE, std::move (l));
      }
#else
      static
      symbol_type
      make_LE (const location_type& l)
      {
        return symbol_type (token::LE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_GE (location_type l)
      {
        return symbol_type (token::GE, std::move (l));
      }
#else
      static
      symbol_type
      make_GE (const location_type& l)
      {
        return symbol_type (token::GE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NE (location_type l)
      {
        return symbol_type (token::NE, std::move (l));
      }
#else
      static
      symbol_type
      make_NE (const location_type& l)
      {
        return symbol_type (token::NE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MAPSTO (location_type l)
      {
        return symbol_type (token::MAPSTO, std::move (l));
      }
#else
      static
      symbol_type
      make_MAPSTO (const location_type& l)
      {
        return symbol_type (token::MAPSTO, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_AND (location_type l)
      {
        return symbol_type (token::BW_AND, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_AND (const location_type& l)
      {
        return symbol_type (token::BW_AND, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_OR (location_type l)
      {
        return symbol_type (token::BW_OR, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_OR (const location_type& l)
      {
        return symbol_type (token::BW_OR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_XOR (location_type l)
      {
        return symbol_type (token::BW_XOR, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_XOR (const location_type& l)
      {
        return symbol_type (token::BW_XOR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_SHIFT_L (location_type l)
      {
        return symbol_type (token::BW_SHIFT_L, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_SHIFT_L (const location_type& l)
      {
        return symbol_type (token::BW_SHIFT_L, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_SHIFT_R (location_type l)
      {
        return symbol_type (token::BW_SHIFT_R, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_SHIFT_R (const location_type& l)
      {
        return symbol_type (token::BW_SHIFT_R, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_SHIFT_R_UNSIGNED (location_type l)
      {
        return symbol_type (token::BW_SHIFT_R_UNSIGNED, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_SHIFT_R_UNSIGNED (const location_type& l)
      {
        return symbol_type (token::BW_SHIFT_R_UNSIGNED, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_BW_NOT (location_type l)
      {
        return symbol_type (token::BW_NOT, std::move (l));
      }
#else
      static
      symbol_type
      make_BW_NOT (const location_type& l)
      {
        return symbol_type (token::BW_NOT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_L_AND (location_type l)
      {
        return symbol_type (token::L_AND, std::move (l));
      }
#else
      static
      symbol_type
      make_L_AND (const location_type& l)
      {
        return symbol_type (token::L_AND, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_L_OR (location_type l)
      {
        return symbol_type (token::L_OR, std::move (l));
      }
#else
      static
      symbol_type
      make_L_OR (const location_type& l)
      {
        return symbol_type (token::L_OR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_L_XOR (location_type l)
      {
        return symbol_type (token::L_XOR, std::move (l));
      }
#else
      static
      symbol_type
      make_L_XOR (const location_type& l)
      {
        return symbol_type (token::L_XOR, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_L_NOT (location_type l)
      {
        return symbol_type (token::L_NOT, std::move (l));
      }
#else
      static
      symbol_type
      make_L_NOT (const location_type& l)
      {
        return symbol_type (token::L_NOT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OUTER_DOC_COMMENT (std::string v, location_type l)
      {
        return symbol_type (token::OUTER_DOC_COMMENT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_OUTER_DOC_COMMENT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::OUTER_DOC_COMMENT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INNER_DOC_COMMENT (std::string v, location_type l)
      {
        return symbol_type (token::INNER_DOC_COMMENT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_INNER_DOC_COMMENT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::INNER_DOC_COMMENT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NEG (location_type l)
      {
        return symbol_type (token::NEG, std::move (l));
      }
#else
      static
      symbol_type
      make_NEG (const location_type& l)
      {
        return symbol_type (token::NEG, l);
      }
#endif


    class context
    {
    public:
      context (const parser& yyparser, const symbol_type& yyla);
      const symbol_type& lookahead () const YY_NOEXCEPT { return yyla_; }
      symbol_kind_type token () const YY_NOEXCEPT { return yyla_.kind (); }
      const location_type& location () const YY_NOEXCEPT { return yyla_.location; }

      /// Put in YYARG at most YYARGN of the expected tokens, and return the
      /// number of tokens stored in YYARG.  If YYARG is null, return the
      /// number of expected tokens (guaranteed to be less than YYNTOKENS).
      int expected_tokens (symbol_kind_type yyarg[], int yyargn) const;

    private:
      const parser& yyparser_;
      const symbol_type& yyla_;
    };

  private:
#if YY_CPLUSPLUS < 201103L
    /// Non copyable.
    parser (const parser&);
    /// Non copyable.
    parser& operator= (const parser&);
#endif


    /// Stored state numbers (used for stacks).
    typedef short state_type;

    /// The arguments of the error message.
    int yy_syntax_error_arguments_ (const context& yyctx,
                                    symbol_kind_type yyarg[], int yyargn) const;

    /// Generate an error message.
    /// \param yyctx     the context in which the error occurred.
    virtual std::string yysyntax_error_ (const context& yyctx) const;
    /// Compute post-reduction state.
    /// \param yystate   the current state
    /// \param yysym     the nonterminal to push on the stack
    static state_type yy_lr_goto_state_ (state_type yystate, int yysym);

    /// Whether the given \c yypact_ value indicates a defaulted state.
    /// \param yyvalue   the value to check
    static bool yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT;

    /// Whether the given \c yytable_ value indicates a syntax error.
    /// \param yyvalue   the value to check
    static bool yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT;

    static const short yypact_ninf_;
    static const short yytable_ninf_;

    /// Convert a scanner token kind \a t to a symbol kind.
    /// In theory \a t should be a token_kind_type, but character literals
    /// are valid, yet not members of the token_kind_type enum.
    static symbol_kind_type yytranslate_ (int t) YY_NOEXCEPT;

    /// Convert the symbol name \a n to a form suitable for a diagnostic.
    static std::string yytnamerr_ (const char *yystr);

    /// For a symbol, its name in clear.
    static const char* const yytname_[];


    // Tables.
    // YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
    // STATE-NUM.
    static const short yypact_[];

    // YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
    // Performed when YYTABLE does not specify something else to do.  Zero
    // means the default is an error.
    static const short yydefact_[];

    // YYPGOTO[NTERM-NUM].
    static const short yypgoto_[];

    // YYDEFGOTO[NTERM-NUM].
    static const short yydefgoto_[];

    // YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
    // positive, shift that token.  If negative, reduce the rule whose
    // number is the opposite.  If YYTABLE_NINF, syntax error.
    static const short yytable_[];

    static const short yycheck_[];

    // YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
    // state STATE-NUM.
    static const unsigned char yystos_[];

    // YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.
    static const unsigned char yyr1_[];

    // YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.
    static const signed char yyr2_[];


#if YYDEBUG
    // YYRLINE[YYN] -- Source line where rule number YYN was defined.
    static const short yyrline_[];
    /// Report on the debug stream that the rule \a r is going to be reduced.
    virtual void yy_reduce_print_ (int r) const;
    /// Print the state stack on the debug stream.
    virtual void yy_stack_print_ () const;

    /// Debugging level.
    int yydebug_;
    /// Debug stream.
    std::ostream* yycdebug_;

    /// \brief Display a symbol kind, value and location.
    /// \param yyo    The output stream.
    /// \param yysym  The symbol.
    template <typename Base>
    void yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const;
#endif

    /// \brief Reclaim the memory associated to a symbol.
    /// \param yymsg     Why this token is reclaimed.
    ///                  If null, print nothing.
    /// \param yysym     The symbol.
    template <typename Base>
    void yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const;

  private:
    /// Type access provider for state based symbols.
    struct by_state
    {
      /// Default constructor.
      by_state () YY_NOEXCEPT;

      /// The symbol kind as needed by the constructor.
      typedef state_type kind_type;

      /// Constructor.
      by_state (kind_type s) YY_NOEXCEPT;

      /// Copy constructor.
      by_state (const by_state& that) YY_NOEXCEPT;

      /// Record that this symbol is empty.
      void clear () YY_NOEXCEPT;

      /// Steal the symbol kind from \a that.
      void move (by_state& that);

      /// The symbol kind (corresponding to \a state).
      /// \a symbol_kind::S_YYEMPTY when empty.
      symbol_kind_type kind () const YY_NOEXCEPT;

      /// The state number used to denote an empty symbol.
      /// We use the initial state, as it does not have a value.
      enum { empty_state = 0 };

      /// The state.
      /// \a empty when empty.
      state_type state;
    };

    /// "Internal" symbol: element of the stack.
    struct stack_symbol_type : basic_symbol<by_state>
    {
      /// Superclass.
      typedef basic_symbol<by_state> super_type;
      /// Construct an empty symbol.
      stack_symbol_type ();
      /// Move or copy construction.
      stack_symbol_type (YY_RVREF (stack_symbol_type) that);
      /// Steal the contents from \a sym to build this.
      stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) sym);
#if YY_CPLUSPLUS < 201103L
      /// Assignment, needed by push_back by some old implementations.
      /// Moves the contents of that.
      stack_symbol_type& operator= (stack_symbol_type& that);

      /// Assignment, needed by push_back by other implementations.
      /// Needed by some other old implementations.
      stack_symbol_type& operator= (const stack_symbol_type& that);
#endif
    };

    /// A stack with random access from its top.
    template <typename T, typename S = std::vector<T> >
    class stack
    {
    public:
      // Hide our reversed order.
      typedef typename S::iterator iterator;
      typedef typename S::const_iterator const_iterator;
      typedef typename S::size_type size_type;
      typedef typename std::ptrdiff_t index_type;

      stack (size_type n = 200) YY_NOEXCEPT
        : seq_ (n)
      {}

#if 201103L <= YY_CPLUSPLUS
      /// Non copyable.
      stack (const stack&) = delete;
      /// Non copyable.
      stack& operator= (const stack&) = delete;
#endif

      /// Random access.
      ///
      /// Index 0 returns the topmost element.
      const T&
      operator[] (index_type i) const
      {
        return seq_[size_type (size () - 1 - i)];
      }

      /// Random access.
      ///
      /// Index 0 returns the topmost element.
      T&
      operator[] (index_type i)
      {
        return seq_[size_type (size () - 1 - i)];
      }

      /// Steal the contents of \a t.
      ///
      /// Close to move-semantics.
      void
      push (YY_MOVE_REF (T) t)
      {
        seq_.push_back (T ());
        operator[] (0).move (t);
      }

      /// Pop elements from the stack.
      void
      pop (std::ptrdiff_t n = 1) YY_NOEXCEPT
      {
        for (; 0 < n; --n)
          seq_.pop_back ();
      }

      /// Pop all elements from the stack.
      void
      clear () YY_NOEXCEPT
      {
        seq_.clear ();
      }

      /// Number of elements on the stack.
      index_type
      size () const YY_NOEXCEPT
      {
        return index_type (seq_.size ());
      }

      /// Iterator on top of the stack (going downwards).
      const_iterator
      begin () const YY_NOEXCEPT
      {
        return seq_.begin ();
      }

      /// Bottom of the stack.
      const_iterator
      end () const YY_NOEXCEPT
      {
        return seq_.end ();
      }

      /// Present a slice of the top of a stack.
      class slice
      {
      public:
        slice (const stack& stack, index_type range) YY_NOEXCEPT
          : stack_ (stack)
          , range_ (range)
        {}

        const T&
        operator[] (index_type i) const
        {
          return stack_[range_ - i];
        }

      private:
        const stack& stack_;
        index_type range_;
      };

    private:
#if YY_CPLUSPLUS < 201103L
      /// Non copyable.
      stack (const stack&);
      /// Non copyable.
      stack& operator= (const stack&);
#endif
      /// The wrapped container.
      S seq_;
    };


    /// Stack type.
    typedef stack<stack_symbol_type> stack_type;

    /// The stack.
    stack_type yystack_;

    /// Push a new state on the stack.
    /// \param m    a debug message to display
    ///             if null, no trace is output.
    /// \param sym  the symbol
    /// \warning the contents of \a s.value is stolen.
    void yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym);

    /// Push a new look ahead token on the state on the stack.
    /// \param m    a debug message to display
    ///             if null, no trace is output.
    /// \param s    the state
    /// \param sym  the symbol (for its value and location).
    /// \warning the contents of \a sym.value is stolen.
    void yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym);

    /// Pop \a n symbols from the stack.
    void yypop_ (int n = 1) YY_NOEXCEPT;

    /// Constants.
    enum
    {
      yylast_ = 1464,     ///< Last index in yytable_.
      yynnts_ = 70,  ///< Number of nonterminal symbols.
      yyfinal_ = 3 ///< Termination state number.
    };


    // User arguments.
    ParserDriver &driver;
    yyscan_t yyscanner;

  };

  inline
  parser::symbol_kind_type
  parser::yytranslate_ (int t) YY_NOEXCEPT
  {
    // YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to
    // TOKEN-NUM as returned by yylex.
    static
    const signed char
    translate_table[] =
    {
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114
    };
    // Last valid token kind.
    const int code_max = 369;

    if (t <= 0)
      return symbol_kind::S_YYEOF;
    else if (t <= code_max)
      return static_cast <symbol_kind_type> (translate_table[t]);
    else
      return symbol_kind::S_YYUNDEF;
  }

  // basic_symbol.
  template <typename Base>
  parser::basic_symbol<Base>::basic_symbol (const basic_symbol& that)
    : Base (that)
    , value ()
    , location (that.location)
  {
    switch (this->kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.copy< AggregateOp > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg: // arg
        value.copy< Own<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_atom: // atom
        value.copy< Own<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.copy< Own<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.copy< Own<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_fact: // fact
        value.copy< Own<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.copy< Own<ast::Component> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_init: // component_init
        value.copy< Own<ast::ComponentInit> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_component_type: // component_type
        value.copy< Own<ast::ComponentType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_constraint: // constraint
        value.copy< Own<ast::Constraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.copy< Own<ast::ExecutionOrder> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.copy< Own<ast::ExecutionPlan> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency: // dependency
        value.copy< Own<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.copy< Own<ast::FunctorDeclaration> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.copy< Own<ast::Lattice> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_pragma: // pragma
        value.copy< Own<ast::Pragma> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.copy< Own<ast::Type> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.copy< RuleBody > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.copy< VecOwn<ast::Argument> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_head: // head
        value.copy< VecOwn<ast::Atom> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.copy< VecOwn<ast::Attribute> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.copy< VecOwn<ast::BranchType> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.copy< VecOwn<ast::Clause> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.copy< VecOwn<ast::Directive> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.copy< VecOwn<ast::FunctionalConstraint> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.copy< VecOwn<ast::Relation> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.copy< ast::Annotation > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.copy< ast::AnnotationList > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.copy< ast::DirectiveType > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.copy< ast::ExecutionOrder::ExecOrder > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.copy< ast::QualifiedName > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.copy< ast::TokenStream > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.copy< ast::TokenTree > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.copy< std::map<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.copy< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.copy< std::set<RelationTag> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.copy< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.copy< std::vector<ast::QualifiedName> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.copy< std::vector<std::pair<std::string, std::string>> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.copy< std::vector<std::string> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

  }




  template <typename Base>
  parser::symbol_kind_type
  parser::basic_symbol<Base>::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }


  template <typename Base>
  bool
  parser::basic_symbol<Base>::empty () const YY_NOEXCEPT
  {
    return this->kind () == symbol_kind::S_YYEMPTY;
  }

  template <typename Base>
  void
  parser::basic_symbol<Base>::move (basic_symbol& s)
  {
    super_type::move (s);
    switch (this->kind ())
    {
      case symbol_kind::S_aggregate_func: // aggregate_func
        value.move< AggregateOp > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_arg: // arg
        value.move< Own<ast::Argument> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_atom: // atom
        value.move< Own<ast::Atom> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_attribute: // attribute
      case symbol_kind::S_functor_attribute: // functor_attribute
        value.move< Own<ast::Attribute> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_adt_branch: // adt_branch
        value.move< Own<ast::BranchType> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_fact: // fact
        value.move< Own<ast::Clause> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_component_decl: // component_decl
      case symbol_kind::S_component_head: // component_head
      case symbol_kind::S_component_body: // component_body
        value.move< Own<ast::Component> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_component_init: // component_init
        value.move< Own<ast::ComponentInit> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_component_type: // component_type
        value.move< Own<ast::ComponentType> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_constraint: // constraint
        value.move< Own<ast::Constraint> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_plan_order: // plan_order
        value.move< Own<ast::ExecutionOrder> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_query_plan: // query_plan
      case symbol_kind::S_query_plan_list: // query_plan_list
        value.move< Own<ast::ExecutionPlan> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_dependency: // dependency
        value.move< Own<ast::FunctionalConstraint> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_functor_decl: // functor_decl
        value.move< Own<ast::FunctorDeclaration> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_lattice_decl: // lattice_decl
        value.move< Own<ast::Lattice> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_pragma: // pragma
        value.move< Own<ast::Pragma> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_type_decl: // type_decl
        value.move< Own<ast::Type> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_body: // body
      case symbol_kind::S_disjunction: // disjunction
      case symbol_kind::S_conjunction: // conjunction
      case symbol_kind::S_term: // term
      case symbol_kind::S_aggregate_body: // aggregate_body
        value.move< RuleBody > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_arg_list: // arg_list
      case symbol_kind::S_non_empty_arg_list: // non_empty_arg_list
        value.move< VecOwn<ast::Argument> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_head: // head
        value.move< VecOwn<ast::Atom> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_record_type_list: // record_type_list
      case symbol_kind::S_attributes_list: // attributes_list
      case symbol_kind::S_non_empty_attributes: // non_empty_attributes
      case symbol_kind::S_functor_arg_type_list: // functor_arg_type_list
      case symbol_kind::S_non_empty_functor_arg_type_list: // non_empty_functor_arg_type_list
        value.move< VecOwn<ast::Attribute> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_adt_branch_list: // adt_branch_list
        value.move< VecOwn<ast::BranchType> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_rule: // rule
      case symbol_kind::S_rule_def: // rule_def
        value.move< VecOwn<ast::Clause> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_directive_head: // directive_head
      case symbol_kind::S_directive_list: // directive_list
      case symbol_kind::S_relation_directive_list: // relation_directive_list
        value.move< VecOwn<ast::Directive> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_dependency_list_aux: // dependency_list_aux
      case symbol_kind::S_dependency_list: // dependency_list
        value.move< VecOwn<ast::FunctionalConstraint> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_relation_decl: // relation_decl
      case symbol_kind::S_relation_names: // relation_names
        value.move< VecOwn<ast::Relation> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_annotation: // annotation
      case symbol_kind::S_inner_annotation: // inner_annotation
        value.move< ast::Annotation > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_annotations: // annotations
      case symbol_kind::S_inner_annotations: // inner_annotations
      case symbol_kind::S_non_empty_inner_annotations: // non_empty_inner_annotations
        value.move< ast::AnnotationList > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_directive_head_decl: // directive_head_decl
        value.move< ast::DirectiveType > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_non_empty_plan_order_list: // non_empty_plan_order_list
        value.move< ast::ExecutionOrder::ExecOrder > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_qualified_name: // qualified_name
        value.move< ast::QualifiedName > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_annotation_input: // annotation_input
      case symbol_kind::S_token_stream: // token_stream
        value.move< ast::TokenStream > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_delim: // delim
      case symbol_kind::S_ident_token: // ident_token
      case symbol_kind::S_token: // token
        value.move< ast::TokenTree > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_lattice_operator_list: // lattice_operator_list
        value.move< std::map<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_lattice_operator: // lattice_operator
        value.move< std::pair<ast::LatticeOperator, Own<ast::Argument>> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_relation_tags: // relation_tags
        value.move< std::set<RelationTag> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_STRING: // "symbol"
      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_UNSIGNED: // "unsigned number"
      case symbol_kind::S_FLOAT: // "float"
      case symbol_kind::S_OUTER_DOC_COMMENT: // "outer doc comment"
      case symbol_kind::S_INNER_DOC_COMMENT: // "inner doc comment"
      case symbol_kind::S_functor_built_in: // functor_built_in
      case symbol_kind::S_kvp_value: // kvp_value
        value.move< std::string > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_union_type_list: // union_type_list
      case symbol_kind::S_component_type_params: // component_type_params
      case symbol_kind::S_component_param_list: // component_param_list
        value.move< std::vector<ast::QualifiedName> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_non_empty_key_value_pairs: // non_empty_key_value_pairs
        value.move< std::vector<std::pair<std::string, std::string>> > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_non_empty_attribute_names: // non_empty_attribute_names
        value.move< std::vector<std::string> > (YY_MOVE (s.value));
        break;

      default:
        break;
    }

    location = YY_MOVE (s.location);
  }

  // by_kind.
  inline
  parser::by_kind::by_kind () YY_NOEXCEPT
    : kind_ (symbol_kind::S_YYEMPTY)
  {}

#if 201103L <= YY_CPLUSPLUS
  inline
  parser::by_kind::by_kind (by_kind&& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {
    that.clear ();
  }
#endif

  inline
  parser::by_kind::by_kind (const by_kind& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {}

  inline
  parser::by_kind::by_kind (token_kind_type t) YY_NOEXCEPT
    : kind_ (yytranslate_ (t))
  {}



  inline
  void
  parser::by_kind::clear () YY_NOEXCEPT
  {
    kind_ = symbol_kind::S_YYEMPTY;
  }

  inline
  void
  parser::by_kind::move (by_kind& that)
  {
    kind_ = that.kind_;
    that.clear ();
  }

  inline
  parser::symbol_kind_type
  parser::by_kind::kind () const YY_NOEXCEPT
  {
    return kind_;
  }


  inline
  parser::symbol_kind_type
  parser::by_kind::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }


} // yy
#line 4830 "/home/lun/workspace/souffle/build/src/parser/parser.hh"




#endif // !YY_YY_HOME_LUN_WORKSPACE_SOUFFLE_BUILD_SRC_PARSER_PARSER_HH_INCLUDED

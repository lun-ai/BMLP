#pragma once

namespace souffle {
constexpr char const* PACKAGE_VERSION = "2.4.1-50-ge6cc66820";
}
